
# How to properly use the Global Settings section in the Dynatrace tenant

The new tenant global settings allow you to:
- Define SLOs
- Configure alerting profiles
- Configure problem notifications
- Configure maintenance windows

Under the tenant global settings, you will only see SLOs or maintenance windows defined via UI settings since they are not linked to a management zone.

Under the tenant global settings, you will see alerting profiles and problem notifications both defined via CaC or via the UI settings since they are linked to a management zone.

The elements defined via UI will not be visible in your CaC GitHub repository.

Elements defined via CaC or defined using the settings in the tenant UI will operate the same way.

*** It is not recommended to modify via the UI the configuration elements that were created via CaC, as the CaC will change them back to the initially declared status, or configure a new element.

*** It is recommended to not follow the same naming convention for manually created elements and for the CaC elements - this won't generate a problem, but it will be easier to differentiate in the future if different naming conventions are used.

These are the different sections found under the tenant global settings:

<p align="left">
  <img size="50%" src="images/1-settings.png" width="30%" height="30%" /></div>
</p>

### Why is it recommended to use CaC?
- Keep track of your changes - Transparent
- Roll back available
- Automation

