# Dynatrace Sandbox: Prepare and export from Sandbox to Production

![disclaimner](images/disclaimer.png)
# When to use?

-   use of settings that are not in the YAML template, but can still be
    used - when documentations indicates use of all API functionality is
    allowed

-   some values that are required as input for the YAML cannot be
    gathered from API documentation

-   a configuration for the AzTech automat does cannot be applied due to
    some failure and troubleshooting is required



# How to use?
  - [Example Prepare and Export](#example-prepare-and-export)
    - [The sample Task](#the-sample-task)
    - [Step 1: Prepare the evaluation environment](#step-1-prepare-the-evaluation-environment)
    - [Step 2: Configure an alert setting](#step-2-configure-an-alert-setting)
    - [Step 3: Export your configs and add it to yaml templates](#step-3-export-your-configs-and-add-it-to-yaml-templates)
    - [Step 4: cleanup](#step-4-cleanup)

## Example Prepare and Export

You want to set up a specific configuration and you are not sure how to
do this directly in the YAML file. You could configure the various
settings according to your requirements and export the configurations as
JSON. This JSON can easily be translated into YAML files - as you would
normally do.

To unterstand the general steps required to set up a proper alerting
please see

-   general information for requirement gathering **[Alarmierung und
    Benachrichtigung
    beauftragen](https://cmp.allianz.net/display/AAD0ATC/Alarmierung+und+Benachrichtigung+beauftragen)**
    (german version)

    -   there is also a link to a detailed description **[DT
        Alarmierung](https://wiki.allianz.de/display/azdcloudops/DT+-+Alarmierung)**

    -   and a [Webinar: Alarmierung und
        Benachrichtigung](https://wiki.allianz.de/display/azdcloudops/DT+-+Webinare#DT-Webinare-AlarmierungundBenachrichtigung)
        (does not include explanation of custom events)


### The sample Task

We want to configure a custom threshold for disk usage on a group of
servers that belong to the same hostgroup - so that an alert is raised
if the remaining available storage is less than 20%

### Step 1: Prepare the evaluation environment

<!-- -->

1.  onboard a host that can be used for test

    -   configure the agent for the host to appear in the sandbox
        environment (copy from linux documentation and replace values)  
        in order to add a machine temporarily to the Sandbox you need to
        follow the regular instructions for PRE-PROD and PROD e.g [EC2:
        Linux Installation Instructions Dynatrace
        SaaS](https://cmp.allianz.net/display/AAD0ATC/EC2%3A+Linux+Installation+Instructions+Dynatrace+SaaS)  
        you will have to replace the values for  

        <div class="tablewrap">

        <table class="wrapped confluenceTable">
        <thead>
        <tr class="header">
        <th class="confluenceTh"></th>
        <th class="confluenceTh"><p>Az Tech Sandbox Environment</p></th>
        </tr>
        </thead>
        <tbody>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>SERVERURL</code></pre></td>
        <td class="confluenceTd"><p><em>via AWS Service Endpoint (direct path between AzDe AWS VPC and AzTech AWS VPC)</em></p>
        <p><strong>dt-eag.ec1.e2e-mon-allianz.com</strong> <em>(please check in advance if this path is available from your VPC)</em></p>
        <p>or alternative</p>
        <p>https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>NETWORKZONE</code></pre></td>
        <td class="confluenceTd"><p>az.aws.ec1 ( see description and up-to-date link in STEP 5 (<a href="https://cmp.allianz.net/display/AAD0ATC/EC2%3A+Linux+Installation+Instructions+Dynatrace+SaaS">EC2: Linux Installation Instructions Dynatrace SaaS</a>))</p></td>
        </tr>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>ENVIRONMENT</code></pre></td>
        <td class="confluenceTd"><p>zqr77542</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>VERSION</code></pre></td>
        <td class="confluenceTd"><p>latest (replace with result of Step 0 for rollback)</p></td>
        </tr>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>APITOKEN</code></pre></td>
        <td class="confluenceTd"><p>dt0c01.KPFH5DK5S2ROYLL6WGTNM2PU.FDMHVXBNGGVHOLYK7J7JNGR7OH3SN5VEZ7ZBOIQLST2HQOWRST63SM3RZT6P33MF</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>HOSTGROUP</code></pre></td>
        <td class="confluenceTd"><p>my-hostgroup to-find-it</p></td>
        </tr>
        </tbody>
        </table>

        so the resulting URL for download and the installation might
        look like follows

        <div class="confbox programlisting"
        style="counter-reset: scroll-code-numbering 1">

        <div
        class="defaultnew syntaxhighlighter scroll-html-formatted-code"
        xmlns="http://www.w3.org/1999/xhtml" linenumbers="false"
        firstline="1">

        ```bash
        wget --no-check-certificate -O Dynatrace-OneAgent-Linux.sh "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/v1/deployment/installer/agent/unix/default/latest?Api-Token=dt0c01.KPFH5DK5S2ROYLL6WGTNM2PU.FDMHVXBNGGVHOLYK7J7JNGR7OH3SN5VEZ7ZBOIQLST2HQOWRST63SM3RZT6P33MF&arch=x86&flavor=default"
        /bin/sh Dynatrace-OneAgent-Linux.sh --set-app-log-content-access=true --set-infra-only=false --set-host-group=my-hostgroup-to-find-it --set-server=https://dt-eag.ec1.e2e-mon-allianz.com;9999 --set-network-zone=az.aws.ec1
        ```

2.  restart your host / process

3.  verify machine is available in [Dynatrace
    Sandbox](https://zqr77542.live.dynatrace.com/#newhosts;gtf=-2h;gf=all)

    ![](images//346944013/image2021-10-27_17-10-35.png)
   
### Step 2: Configure an alert setting

1.  tag target configure a automatically applied tag that will later be
    used with the alerting profile: see [Dynatrace Documentation "How to
    define
    tags"](https://www.dynatrace.com/support/help/how-to-use-dynatrace/tags-and-metadata/setup/how-to-define-tags/)
    for details

    <img src="images//348439542/image2021-10-28_14-51-46.png" height="250" alt="images//348439542/image2021-10-28_14-51-46.png" />

2.  configure a custom threshold: see [Dynatrace Documentation "Metric
    Events for
    Alerting"](https://www.dynatrace.com/support/help/how-to-use-dynatrace/problem-detection-and-analysis/problem-detection/metric-events-for-alerting/)
    for details  
    <img src="images//348439542/image2021-10-28_14-54-40.png" height="250" alt="images//348439542/image2021-10-28_14-54-40.png" />
    <img src="images//348439542/image2021-10-28_14-55-51.png" height="250" alt="images//348439542/image2021-10-28_14-55-51.png" />
    <img src="images//348439542/image2021-10-28_14-57-41.png" height="250" alt="images//348439542/image2021-10-28_14-57-41.png" />

3.  configure a alerting profile: see [Dynatrace Documentation "Alerting
    Profiles"](https://www.dynatrace.com/support/help/how-to-use-dynatrace/problem-detection-and-analysis/notifications-and-alerting/alerting-profiles/)
    for details

    <img src="images//348439542/image2021-10-28_15-28-15.png" height="250" alt="images//348439542/image2021-10-28_15-28-15.png" />

4.  configure a notification: see [Dynatrace Documentation
    "Third-Party-Integration:
    Notifications"](https://www.dynatrace.com/support/help/setup-and-configuration/integrations/third-party-integrations/)
    for details

    <img src="images//348439542/image2021-10-28_16-17-23.png" height="250" alt="images//348439542/image2021-10-28_16-17-23.png" />

5.  test your alert setting

    1.  copy data the the machine until the limit is exceeded

        <img src="images//348439542/image2021-10-29_11-5-31.png" height="250" alt="images//348439542/image2021-10-29_11-5-31.png" />

    2.  verify the result (screenshots for Problem, Open Notification,
        Close Notification  
        <img src="images//348439542/image2021-10-29_13-55-8.png" height="250" alt="images//348439542/image2021-10-29_13-55-8.png" />
        <img src="images//348439542/image2021-10-29_13-36-58.png" height="250" alt="images//348439542/image2021-10-29_13-36-58.png" />
        <img src="images//348439542/image2021-10-29_13-55-35.png" width="530" alt="images//348439542/image2021-10-29_13-55-35.png" />

### Step 3: Export your configs and add it to yaml templates

general steps how to use the api to extract data

1.  create a token **that exposes as little configuration items as
    possible**: see [Dynatrace Documentation: Dynatrace API
    Authentication](https://www.dynatrace.com/support/help/dynatrace-api/basics/dynatrace-api-authentication/)
    and the documentations for the required APIs  
      
    To find the required permissions - we can check the documentation
    for all elements

    -   Tag API (see [Dynatrace API: Automatically Applied
        Tags](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/automatically-applied-tags-api/get-all/))

        <img src="images//348439542/image2021-10-29_16-15-32.png" width="600" alt="images//348439542/image2021-10-29_16-15-32.png" />

    -   Custom Event API (see [Dynatrace API: Anomaly Detection
        API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/anomaly-detection-api/anomaly-detection-api-metric-events/post-event/))  
        " To execute this request, you need the **Read configuration** (
        ReadConfig ) permission assigned to your API token. To learn how
        to obtain and use it, see [Tokens and
        authentication](https://www.dynatrace.com/support/help/shortlink/api-authentication)
        . "

    -   Alerting Event API (see Dynatrace API: Alerting Profiling) "To
        execute this request, you need the Read configuration
        (ReadConfig) permission assigned to your API token. To learn how
        to obtain and use it, see Tokens and authentication."

    -   Notification API: (see Notifications) "To execute this request,
        you need the Read configuration (ReadConfig) permission assigned
        to your API token. To learn how to obtain and use it, see Tokens
        and authentication." 
        <img src="images//348439542/image2021-10-29_16-52-50.png" height="250" alt="images//348439542/image2021-10-29_16-52-50.png" />  
          

2.  export data as json using curl (just the curl operation)

    -   export custom tag config
        ```bash
        # export list of all custom tags that are automatically applied
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/autoTags" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" -o auto-tags.json
         
        # use JQ to export the id of your configuration
        cat auto-tags.json | jq '.[]|map(select (.name == "my-personal-service-tag-for-alerting"))'
         
        # will result in
        #[
        #  {
        #    "id": "72cb6e77-7187-48a5-8e5d-1715bddc1dee",
        #    "name": "my-personal-service-tag-for-alerting"
        #  }
        #]
         
         
        # export your config to file my-personal-service-tag-for-alerting.json (will be formatted by JQ)
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/autoTags/72cb6e77-7187-48a5-8e5d-1715bddc1dee" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" | jq . > my-personal-service-tag-for-alerting.json
        ```

    -   export custom anomaly event configuration

        ```bash
        # export list of all custom events for alerts configs to file anomaly-detection-rules.json
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/anomalyDetection/metricEvents" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" -o custom-event-for-alerts.json
         
        # use JQ to export the id of your configuration
        cat custom-event-for-alerts.json | jq '.[]|map(select (.name == "my-custom-alert-for-low-disk"))'
         
        # will result in
        #[
        #  {
        #    "id": "60278317-a2df-4859-b714-480c1002bc43",
        #    "name": "my-custom-alert-for-low-disk",
        #    "description": "Available disk space is below 20% for drive {dims:dt.entity.disk.name} on {dims:dt.entity.host.name} of {severity} was {alert_condition} your custom threshold of {threshold}."
        #  }
        #]
         
        # export your config to file my-custom-alert-for-low-disk.json (will be formatted by JQ)
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/anomalyDetection/metricEvents/60278317-a2df-4859-b714-480c1002bc43" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" | jq . > my-custom-alert-for-low-disk.json

        ```

    -   export alerting profile configuration

        ```bash
        # export list of all alerting profile configs to file alerting-profiles.json
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1//alertingProfiles" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" -o alerting-profiles.json
            
        # use JQ to export the id of your configuration
        cat alerting-profiles.json | jq '.[]|map(select (.name == "my-alerting-profile"))'
            
        # will result in
        #[
        #  {
        #    "id": "fa04477f-468f-3c01-8c2a-c8242534973f",
        #    "name": "my-alerting-profile"
        #  }
        #]
            
        # export your config to file my-alerting-profile.json (will be formatted by JQ)
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/alertingProfiles/fa04477f-468f-3c01-8c2a-c8242534973f" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" | jq . > my-alerting-profile.json
        ```
        
    -   export your notification setting
        ```bash
        # export list of all notification configs to file notifications.json
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1//notifications" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" -o notifications.json
        
        # use JQ to export the id of your configuration
        cat notifications.json | jq '.[]|map(select (.name == "notification-for-my-application-by-email-to-me"))'
        
        # will result in
        #[
        #  {
        #    "id": "db58dfe5-eceb-3cd9-bb52-3802f56f8e09",
        #    "name": "notification-for-my-application-by-email-to-me",
        #    "type": "EMAIL"
        #  }
        #]
        
        
        # export your config to file my-alerting-profile.json (will be formatted by JQ)
        curl -k --noproxy "*" -X GET "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/config/v1/notifications/db58dfe5-eceb-3cd9-bb52-3802f56f8e09" -H "accept: application/json; charset=utf-8" -H "Content-Type: application/json; charset=utf-8" -H "Authorization: Api-Token dt0c01.EZH6DCRCP7MDEZ73QPT3ET4U.3TQ2RJQ4GF5P5LHLZNMFQQ67UFERCILQFVDFOZECSSO6INFWV5METSWNHUXOVEMV" | jq . > notification-for-my-application-by-email-to-me.json
        ```
   
3.  convert data to YAML

    1.  automatically applied tag config to YAML  
        ![](images/348439542/tag-converstion.png)

    2.  custom threshold to YAML  
        ![](images/348439542/custom-event-converstion.png)

    3.  alerting profile  
        ![](images/348439542/alerting-profile.png)

    4.  notification  
        ![](images/348439542/notification.png)

### Step 4: cleanup

1.  **(mandatory)** disable token

    <img src="images//348439542/image2021-11-1_14-38-44.png" height="250" alt="images//348439542/image2021-11-1_14-38-44.png" />

2.  **(mandatory)** remove the machine from the environment

    -   either reimplement oneagent to point to the designated target
        environment again (PROD/PREPROD) following the installation
        instructions

    -   or remove the OneAgent by following the uninstall instructions
        e.g. [Uninstall OneAgent from
        Linux](https://cmp.allianz.net/display/AAD0ATC/Uninstall+OneAgent+from+Linux)

3.  (optional) manually remove configs (configs will be removed by a
    weekly sweeping task)






