# Dynatrace Sandbox: Seek and Peek - play with settings <!-- omit in toc -->

![disclaimner](images/disclaimer.png)

Seek and Peek: Play with the settings / options in Dynatrace to see what
is possible or may solve your problem

# When to use? <!-- omit in toc -->

-   Special service technology - which is not monitored correctly in
    PreProd / Prod to test out different Deep Monitoring settings,
    Feature Flags etc of the Dynatrace Settings section. Work together
    with Dynatrace One Support and figure the correct setting. After
    finalization request roll-out to pre-prod or prod

-   you want to test your service with a different oneagent version

-   you want to build and test a dynatrace Plugin

-   you want to create custom metrics

-   Model Synthetic webchecks with ClickPaths or as Browser Monitor

-   Model Business KPI in the User Experience view

# How to use?<!-- omit in toc -->

- [Example Seek and Peek: Build a plugin](#example-seek-and-peek-build-a-plugin)
  - [The sample task](#the-sample-task)
  - [Step 1: prepare evaluation environment](#step-1-prepare-evaluation-environment)
  - [Step 2: deploy a sample Java App](#step-2-deploy-a-sample-java-app)
  - [Step 3: create and export the plugin](#step-3-create-and-export-the-plugin)
  - [Step 4: stage your plugin](#step-4-stage-your-plugin)
  - [Step 5: cleanup](#step-5-cleanup)

# Example Seek and Peek: Build a plugin
## The sample task

We have a Java application that exposes a specific JMX value - which is
not available as standard metric. This data shall be ingested into
Dynatrace.

For this Demo the example from [Oracle MBean
Example](https://docs.oracle.com/javase/tutorial/jmx/mbeans/standard.html)
is used. The sample code can be downloaded from this page.
## Step 1: prepare evaluation environment

1.  onboard a host that can be used for test

    -   configure the agent for the host to appear in the sandbox
        environment (copy from linux documentation and replace values)  
        in order to add a machine temporarily to the Sandbox you need to
        follow the regular instructions for PRE-PROD and PROD e.g [EC2:
        Linux Installation Instructions Dynatrace
        SaaS](https://cmp.allianz.net/display/AAD0ATC/EC2%3A+Linux+Installation+Instructions+Dynatrace+SaaS)  
        you will have to replace the values for

        <table class="wrapped confluenceTable">
        <thead>
        <tr class="header">
        <th class="confluenceTh"></th>
        <th class="confluenceTh"><p>Az Tech Sandbox Environment</p></th>
        </tr>
        </thead>
        <tbody>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>SERVERURL</code></pre></td>
        <td class="confluenceTd"><p><em>via AWS Service Endpoint (direct path between AzDe AWS VPC and AzTech AWS VPC)</em></p>
        <p><strong>dt-eag.ec1.e2e-mon-allianz.com</strong> <em>(please check in advance if this path is available from your VPC)</em></p>
        <p>or alternative</p>
        <p>https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>NETWORKZONE</code></pre></td>
        <td class="confluenceTd"><p>az.aws.ec1 ( see description and up-to-date link in STEP 5 (<a href="https://cmp.allianz.net/display/AAD0ATC/EC2%3A+Linux+Installation+Instructions+Dynatrace+SaaS">EC2: Linux Installation Instructions Dynatrace SaaS</a>))</p></td>
        </tr>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>ENVIRONMENT</code></pre></td>
        <td class="confluenceTd"><p>zqr77542</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>VERSION</code></pre></td>
        <td class="confluenceTd"><p>latest (replace with result of Step 0 for rollback)</p></td>
        </tr>
        <tr class="odd">
        <td class="confluenceTd"><pre><code>APITOKEN</code></pre></td>
        <td class="confluenceTd"><p>dt0c01.KPFH5DK5S2ROYLL6WGTNM2PU.FDMHVXBNGGVHOLYK7J7JNGR7OH3SN5VEZ7ZBOIQLST2HQOWRST63SM3RZT6P33MF</p></td>
        </tr>
        <tr class="even">
        <td class="confluenceTd"><pre><code>HOSTGROUP</code></pre></td>
        <td class="confluenceTd"><p>my-hostgroup to-find-it</p></td>
        </tr>
        </tbody>
        </table>

        

        so the resulting URL for download and the installation might
        look like follows

        
        ```bash
        wget --no-check-certificate -O Dynatrace-OneAgent-Linux.sh "https://dt-eag.ec1.e2e-mon-allianz.com:9999/e/zqr77542/api/v1/deployment/installer/agent/unix/default/latest?Api-Token=dt0c01.KPFH5DK5S2ROYLL6WGTNM2PU.FDMHVXBNGGVHOLYK7J7JNGR7OH3SN5VEZ7ZBOIQLST2HQOWRST63SM3RZT6P33MF&arch=x86&flavor=default"
        /bin/sh Dynatrace-OneAgent-Linux.sh --set-app-log-content-access=true --set-infra-only=false --set-host-group=my-hostgroup-to-find-it --set-server=https://dt-eag.ec1.e2e-mon-allianz.com;9999 --set-network-zone=az.aws.ec1
        ```

2.  restart your host / process

3.  verify machine is available in [Dynatrace
    Sandbox](https://zqr77542.live.dynatrace.com/#newhosts;gtf=-2h;gf=all)

    ![](images//346944013/image2021-10-27_17-10-35.png)

## Step 2: deploy a sample Java App

1.  deploy your Java Application on the host - if not already done.  
    for this example the Java App was downloaded from the [Oracle MBean
    Example](https://docs.oracle.com/javase/tutorial/jmx/mbeans/standard.html)
    and started with the standard headless JVM

2.  check if the Java Process is available for your host

    <img src="images//346944013/image2021-11-1_15-53-0.png" height="250" alt="images//346944013/image2021-11-1_15-53-0.png" />

## Step 3: create and export the plugin

1.  use the JMX generator (see [Dynatrace Documentation: JMX
    Extensions](https://www.dynatrace.com/support/help/extend-dynatrace/extensions/jmx-extensions/jmx-extensions/))

    1.  start creation  
        <img src="images//346944013/image2021-11-1_16-1-23.png" height="250" alt="images//346944013/image2021-11-1_16-1-23.png" />
        <img src="images//346944013/image2021-11-1_16-2-9.png" width="480" alt="images//346944013/image2021-11-1_16-2-9.png" />

    2.  configure your plugin as required

        <img src="images//346944013/image2021-11-1_16-5-34.png" height="250" alt="images//346944013/image2021-11-1_16-5-34.png" />

    3.  and add the extension

        <img src="images//346944013/image2021-11-1_16-6-31.png" height="250" alt="images//346944013/image2021-11-1_16-6-31.png" />

2.  test your plugin in the process details (or by creating a
    chart/dashboard)

    <img src="images//346944013/image2021-11-1_16-11-27.png" height="250" alt="images//346944013/image2021-11-1_16-11-27.png" />

    <img src="images//346944013/image2021-11-1_16-12-30.png" height="250" alt="images//346944013/image2021-11-1_16-12-30.png" />

3.  in case of questions contact the Dynatrace Chat support

4.  (option) customize your plugin source code and upload it for testing
    until it is ready for staging  
      
    as example we change the chart color to light-green

    <img src="images//346944013/image2021-11-1_16-16-3.png" height="250" alt="images//346944013/image2021-11-1_16-16-3.png" />

    and upload the extension again

    <img src="images//346944013/image2021-11-1_16-18-36.png" height="250" alt="images//346944013/image2021-11-1_16-18-36.png" />

    <img src="images//346944013/image2021-11-1_16-19-39.png" height="250" alt="images//346944013/image2021-11-1_16-19-39.png" />

## Step 4: stage your plugin

1.  raise a service request to get your plugin staged to PreProd and
    Prod

2.  test your plugin after installation in PreProd and Prod

## Step 5: cleanup

1.  **(mandatory)** disable token

    <img src="images//346944013/image2021-11-1_14-38-44.png" height="250" alt="images//346944013/image2021-11-1_14-38-44.png" />

2.  **(mandatory)** remove the machine from the environment

    -   either reimplement oneagent to point to the designated target
        environment again (PROD/PREPROD) following the installation
        instructions

    -   or remove the OneAgent by following the uninstall instructions
        e.g. [Uninstall OneAgent from
        Linux](https://cmp.allianz.net/display/AAD0ATC/Uninstall+OneAgent+from+Linux)

3.  (optional) manually remove configs (configs will be removed by a
    weekly sweeping task)




