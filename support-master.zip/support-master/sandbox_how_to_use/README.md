# Dynatrace Sandbox <!-- omit in toc -->

This documentation is intended as an introduction to Dynatrace
Testlab.  

- [Motivation of providing a Sandbox](#motivation-of-providing-a-sandbox)  
- [General rules](#general-rules)  
- [Access to the Sandbox](#access-to-the-sandbox)  
- [Sample Use Cases](#sample-use-cases)  
  - [Prepare and export from Sandbox to Production](./dynatrace-sandbox-example-prepare-and-export.md)  
  - [Seek and Peek - play with settings](./dynatrace-sandbox-example-seek-and-peek.md)    
- [Official documentation and support](#official-documentation-and-support)  
- [Support channels](#support-channels)  

------------------------------------------------------------------------

## Motivation of providing a Sandbox

**Current state & Motivation:**  
Users do not see the full functionality, features, configurations
therefof and in generalmonitoring capabilities of Dynatrace (this is due
to necessary permission restrictions).  
Consequently users often know only a small range of the monitoring
possibilities with Dynatrace and do not know what specifications are
required to set up said monitoring.  
For example: clients do not fully comprehend that alerting is mostly
automatized by way of Davis, the automation system that automatically
spots irregularities in he monitored data. Similarly they do not know to
which extent that automated alerting can be customized.  
  
**This is why we introduced the Dynatrace Sandbox, which allows the user
to explore freely all functions and monitoring possibilities without
putting productive systems at risk. In other words: here you get to be
an admin
<img src="images/emoticons/wink.svg" class="emoticon emoticon-wink" alt="images/emoticons/wink.svg" />**
**Welcome to the Dynatrace Sandbox!**  
  
**Warning:** You will have to behave (as all admins must) though or we
might get cost-related issues, more on that later.  
  
**Further use of the Sandbox for making configuration files for prod:**  
Once a user has tried out a monitoring configuration in the Sandbox, he
might want to "copy-paste" said configuration into the prod or pre-prod
tenant. Makes sense!  
More concretely the user will want to convert what he has done in the
Dynatrace UI of the Sandbox into a yaml file he can have inserted or
insert directly into the productive repository in Github.  
This is also possible - further information here: [Dynatrace Sandbox:
Prepare and export from Sandbox to
Production](dynatrace-sandbox-example-prepare-and-export.md)

## General rules

By using the Sandbox, you agree to the information provided in this
document. Please read it carefully.

-   **With access to the Sandbox, you are granted tenant-wide admin
    rights.** This allows you to test functions in self-study and to
    find solutions for problems in restricted tenants.

-   **It is not allowed to test cost driving setups/scenarios.** You
    will be charged for any significant increases in costs! So avoid
    onboarding of machines or clusters with huge RAM size and run your
    tests with small instance types instead.

-   **The Sandbox is not intended to be used as a short-term monitoring
    solution for your systems.** It is used exclusively for temporary
    testing of settings and for problem and requirements analysis.

-   **Sandbox does not offer Configuration-as-Code (CaC), like Pre-Prod
    and Prod environments.** Instead, you can use the official Dynatrace
    API to transfer configurations to your environments if necessary.
    Please check the document "[Dynatrace Sandbox: Prepare and export
    from Sandbox to
    Production](dynatrace-sandbox-example-prepare-and-export.md)"
    and the official Dynatrace documentation if you want to do this.

### Automatic deletion of your data<!-- omit in toc -->

<img src="images/emoticons/warning.svg" class="emoticon emoticon-warning" alt="images/emoticons/warning.svg" /> Please **note that data and configurations are regularly deleted in 7-day intervals!**  
This is necessary to provide the same environment and possibilities
for all users. The removal of configurations and the deactivation of
monitored instances will be done every Saturday.

## Access to the Sandbox

**The Sandbox is located at <https://zqr77542.live.dynatrace.com/>.**

<img src="images/emoticons/information.svg" class="emoticon emoticon-information" alt="images/emoticons/information.svg" /> To use this Sandbox you need a user account that can access this tenant.
Please read the following points to get access.

### Registration & Access<!-- omit in toc -->

To request Access open https://giam.web.allianz/GIAM/ and order the product "MZ-AZ-SANDBOX-ADMIN-USERS", please follow the steps shown in the 
screenshots:

Open GIAM and start a new request

![](images/giam-step01.png)

Find Service item "MZ-AZ-SANDBOX-ADMIN-USERS"

![](images/giam-step02.png)

**Important Notice**

Provide a good justification to your request, including your OE and the purpose of the things you are going to test, otherwise access cannot be granted.  
E.g. `For AzDE I need to do a PoC to evaluate monitoring scenarios for cloud databases` 

complete order form and submit your request.

![](images/giam-step03.png)

## Sample Use Cases

We prepared 2 examples use cases of the sandbox for you.
They will explain why and how we use it to complete the task

### Prepare and export from Sandbox to Production

You want to set up a specific configuration and you are not sure how to do this directly in the YAML file. You could configure the various settings according to your requirements and export the configurations as JSON. This JSON can easily be translated into YAML files - as you would normally do.

[Prepare and export from Sandbox to Production](./dynatrace-sandbox-example-prepare-and-export.md)  

### Seek and Peek - play with settings

We have a Java application that exposes a specific JMX value - which is not available as standard metric. This data shall be ingested into Dynatrace.

[Seek and Peek - play with settings](./dynatrace-sandbox-example-seek-and-peek.md)

## Official documentation and support

Dynatrace offers a wide range of supportive information. Please check
the following links:

-   [Support Center](https://support.dynatrace.com/)

-   [Documentation](https://www.dynatrace.com/support/help/) (with
    information about supported technologies and about setup and
    configuration)

-   [Community](https://community.dynatrace.com/)

-   [Release
    notes](https://www.dynatrace.com/support/help/whats-new/release-notes/)

### Dynatrace documentation <!-- omit in toc -->

The official [documentation](https://www.dynatrace.com/support/help/)
includes valuable information about

-   [how to get started with
    Dynatrace](https://www.dynatrace.com/support/help/get-started/)

-   [which technologies are supported by
    Dynatrace](https://www.dynatrace.com/support/help/technology-support/)

-   [how setup and configuration is done in different
    environments](https://www.dynatrace.com/support/help/setup-and-configuration/)

-   [how Dynatrace can be extended with additional
    functionality](https://www.dynatrace.com/support/help/extend-dynatrace/)

-   [how to use
    Dynatrace](https://www.dynatrace.com/support/help/how-to-use-dynatrace/)

-   [how you can use the official
    API](https://www.dynatrace.com/support/help/dynatrace-api/)

-   [and monitoring
    consumption.](https://www.dynatrace.com/support/help/monitoring-consumption/)

Please check out the documentation before raising a support request.

## Support channels

**For Dynatrace related questions you can and should use the available
chat function!** This is a paid service that can be used.  
Use this service! Dynatrace support can help you in a timely manner and
provide faster help than we could ever do internally.

<img src="images/341736868/image2021-10-18_14-7-24.png" height="250" alt="images/341736868/image2021-10-18_14-7-24.png" />

For all questions regarding allianz-internal applications and systems,
please contact the responsible teams.  

If you need further help, please contact the globalmonitoring team.  
You have to create an Github Issue: [pick your topic from the available
issue
types!](https://github.developer.allianz.io/globalmonitoring/support/issues/new/choose)

<img src="images/inline/710397f740302829b3982f498a63a555ebacbfc4.png" class="drawio-diagram-image drawio-image-border" width="400" alt="images/inline/710397f740302829b3982f498a63a555ebacbfc4.png" />
