# Q&A

**Q: How do I find the Service Availability Monitoring in Dynatrace**

Open the **Service Availability Monitoring** dashboard in [Dynatrace production (https://grz73876.live.dynatrace.com/)](https://grz73876.live.dynatrace.com/) 
or use [this direct link](https://grz73876.live.dynatrace.com/#dashboard;gtf=-6h;gf=all;id=e8b07600-7dec-46d7-b9c7-4c320a3cdb47).

**Q: Do I need any specific permission?**

To get view access to the **Service Availability Monitoring** you need a specific ActiveDirectory group. Please use [GIAM](https://giam.web.allianz/) to request for it.
In GIAM use this path:
* **Active Directory Services**
* Select sub category **--Active Directory Security Groups**
* Filter for group name / Product **MZ-AZ-TECH-E2E-PROD-U**
* select and request this group

After the approval you will have access to Dynatrace and the **Service Availability Monitoring**.

**Q: How can I request for pause alerting (maintenance windows)?**

If a maintenance is planned for an application the alerting should be deactivated during this time. To schedule a one-time-maintenance please send an email to [AZTEC-E2E-MON@allianz.com](mailto:AZTEC-E2E-MON@allianz.com) with a **lead time of minimum 1 working day**. We need following data:
- Name of the monitor
- CI (like ```e2e_time_my_app```, you will find this in the tag list on the detail page of your synthetic monitor.)
- timeframe in German time (CET/CEST)

With this data our team will schedule the maintenance for you. 

If you manage multiple applications with a lot of maintenances we can onboard you to our ZIS-Maintenance-Tool. Then you will be able to manage the maintenances by yourselves. If you want to be onboarded please send an email to [AZTEC-E2E-MON@allianz.com](mailto:AZTEC-E2E-MON@allianz.com) with a list of user names and user ids.

