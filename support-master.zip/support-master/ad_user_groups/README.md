# Active Directory User Groups

The user management of your Management Zone can be easily managed in [GIAM via _Active Directory Groups_.](https://github.developer.allianz.io/globalmonitoring/starter-kit/blob/master/GIAM/Request-GIAM-group.md)

There are four different authority levels associated with your Management Zone (see below for a detailed list). For each of those levels, 
an associated user group in Dynatrace exists that is connected to an according Active Directory Security Group (if existent).

The required naming schema is
```
<Management Zone Name>-<Stage>-<Authority Level Key>
```
Example: If your Management Zone is `mz-az-tech-globalmonitoring` in the `prod` tenant, the associated group for `admin`
users is
```
mz-az-tech-globalmonitoring-prod-a
```

Users added to the respective AD groups automatically are granted the associated permissions in Dynatrace.



## Authority Levels

### View Users

_Key:_ `u`

_Permissions:_
- View Management Zone entities.
- [Session replay with content masking](https://www.dynatrace.com/support/help/how-to-use-dynatrace/real-user-monitoring/setup-and-configuration/web-applications/additional-configuration/configure-session-replay-for-personal-data-protection/#masking).

### Power Users

_Key:_ `pu`

_Permissions:_
- All of view users.
- Log view permissions.
- Permissions to view sensitive request data.
- Session replay without content masking.

### Admin Users

_Key:_ `a`

_Permissions:_ 
- All of view and power users.
- Permissions to change entity settings.

### Security Users

_Key:_ `sec`

_Permissions:_
- [Application Security access](https://www.dynatrace.com/support/help/how-to-use-dynatrace/application-security/monitor-application-security)
