---
name: Maintenance Request for Service Availability
about: 'you can use this template for requesting maintenance '
title: "[Maintenance] Request for <service_name >"
labels: Maintenance mode
assignees: ''

---

Please fill in this `yaml`-style template in order to put Maintenance mode on your service 

```yaml
service_name : <service name>                # required; example: sap_financial_services ,you can get it from area tag from your sythetic monitor
start_date: <DD/MM/YYYY>                     # required;Must be on CET
start_time: <HH:MM>                          # required; 24hr format and Must be on CET
end_date: <DD/MM/YYYY>                       # required; Must be on CET
end_time: <HH:MM>                            # required; 24hr format and Must be in CET
ci:                                          # required; example: e2e_time_sap_XXXXX_XXXXX_XXXX, you can get it from ci tag from your sythetic monitor
  - <ci_example1>                                
  - <ci_example2> 
type: <once/recurrence>                      # required; single time select once and if you want to repeat this slect Recurrence
days:                                        # optional ;Not required for type once; if you select the Recurrence then fill the days 
  - <sunday>
  - <Wednesday>
 reason: <CHG2345689>                        #required; Reason to put Maintenance 

```
***Note:*** Maintenance mode is a self-service tool now. You can use this tool to put maintenance on your own. Please contact us if you require more information.
