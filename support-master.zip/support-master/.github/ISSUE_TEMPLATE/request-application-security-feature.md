---
name: Request Application Security (AppSec) feature
about: request the usage of the new AppSec Dynatrace feature
title: Request Application Security (AppSec) feature
labels: onboard request
assignees: ''

---

Please fill in this `yaml`-style template in order to activate Application Security in your Management Zone:

```yaml
  oe: az-<your oe abbrevation>               # required; example: az-tech
  team: <your team name>                     # optional; you can enable it on a team or oe level
  stage: <stage>                             # prod or preprod
  application_security_enabled: True         # request the AppSec feature to be enabled for your management zone
  user-administration:                       # required 
    security-users:                             # required; please consider these users need to have been onbboarded to Dynatrace at least as viewer users previously 
      - <email address of user1>
      - <email address of user2>
# You can find more information about AppSec in https://www.dynatrace.com/platform/application-security/
```
