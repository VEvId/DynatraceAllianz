---
name: Onboard training users
about: collect users emails address who want to learn dynatrace
title: Onboard training users
labels: training
assignees: ''

---

Please fill in this `yaml`-style template in order to onboard your users in our Allianz Technology E2E Global Monitoring Dynatrace tool:

```yaml
  team-name: <your team name>                    # required
  cost-center: <your costcenter id>              # required; example: 1234567890
  debtor: <your debtor id>                       # required; example: 0987654321                   
  start-date: <training start date>              # required
  mode: <online or onsite>                       # required
  length: <half a day, one day or 2 days>        # required
  user:                                          # required 
    - <Email address1>
    - <Email address2>
```
