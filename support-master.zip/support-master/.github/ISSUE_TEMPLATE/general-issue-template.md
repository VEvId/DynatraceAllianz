---
name: General issue template
about: For all General issues use this template
title: "[Issue short Description]"
labels: ''
assignees: ''

---

Dear Team,

***Issue description:*** < Provide detailed  description of your issue >
***Management zone :*** < Affected Management zone name >
***Dynatrace  Link :*** <Copy paste the dynatrace link of afftected entity/dashboard/etc >
***Previous Issue:***  <In case if you have any previoud issue created with same requirement you can share reference number here like #1010>

Regards,
