---
name: Request a new Service Availability Monitor
about: Monitor the availability and performance of your services
title: Request Service Availability Monitor
labels: Service Availability
assignees: ''

---

To set up a new measurement for an application or IT service we need to collect some information which will be used for implementation.
Basic information about the monitored application and the ownership. 
Technical implmentation details like URL, credentials and criteria to decide on failing or succesfull transaction 
Description on how to process alerts created from the new monitoring setup (Alert to be handled by GCCC 24/7 team, automatic INC ticket creation ....).

Please fill in this `yaml`-style template in order to request a new Service Availability Monitor:

**General Information / Overview**

- name: `<application name>` *i.e. Service Now*                          
- description: `<what is the application used for>` *i.e. Central Tool for ITSM processes in AZ Technology*  
- owner: `<requester/application owner>` *i.e. Name req. / Name owner*
- type: `<new request or update>` *i.e. New request*
- stage: `<dev, int, prod>` *i.e. PROD*
- cost-center: `<your cost-center>` *i.e. 10000007*
- debtor: `<your debtor number>` *i.e. 10238487554*
- oe: `<allianz operational entity>` *i.e. Allianz Technology*
- group: `<responsible OPS team/assignment group>` *i.e. AZTEC.CIS.SERVICENOW*
- contact: `<technical contact>` *i.e. carlos.robles@allianz.de*

**Requested measurement**

- url: `<url to be checked>` *i.e. https://sim.srv.allianz:443*
- message: `<positive HTTP return code (200)>` *i.e. succesful login to homepage*
- tu: `<technical user which can be used for checking the application/service>` *i.e. ggdses*
- complex flow: `<If the monitor has to do multiple steps please describe here all the details>`
- performance threshold: `<Standard timeout is 60 sec. If the monitor has to run successful in less time fill in here>` *i.e. 30 sec*

**Dashboard configuration**

- update-group: `<should the new measurement be inserted/added into an already existing Dashboard panel group?  If yes please provide the name>`
- new-group: `<if a new Dashboard group is needed to display the new metric, please provide a name and the area where it should be locaed in Grafana>`
- responsible: `<the responsible assignment group and persons to be shown on the detail dashboard>
- responsible cpi: `<responsible CPI organisation or team>`

**Alerting**

In addition to the metric visualization in Dynatrace, it is possible to set up further notifications / alert handling in ZIS (central alert management system): 
* **Standard way** is alering to the 7x24 Operations team (GCCC). Operations team will take care of the alert out of a instruction. In addition you can choose e-mail notification.
* **Automatic alert** handling will create a incident ticket in SIM-ServiceNow. Additional to this you can select a SMS or voice alert. GCCC will not be involved.

Please fill one of the next sections:

**Standard alert handling**
- gccc: `<alert handling by GCCC>` *i.e. Yes/No*
- instruction link: `<The dynatrace team will create a Wiki page. You have to fill it with the runbook instructions. If a page already exist fill the URL here.>`
- additional email: `<group mail-box only>` *i.e. SERVICENOW-OPERATION@allianz.de*

**Automatic alert handling**
- snow-incident: `<automatic INC ticket creation in Service Now>` *i.e. Yes/No*
- incident-group: `<ServiceNow assignment group>` *i.e. AZTEC.CIS.SERVICENOW*
- voice-alert: `<if yes - please provide number>` *i.e. +498938000*
- sms: `<if yes - please provide mobile number>` *i.e. +4917200000000001*
- additional email: `<group mail-box only>` *i.e. SERVICENOW-OPERATION@allianz.de*
