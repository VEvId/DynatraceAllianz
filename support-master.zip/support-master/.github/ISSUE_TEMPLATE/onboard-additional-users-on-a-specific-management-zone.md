---
name: Onboard additional users on a specific Management Zone
about: collect users emails address who want to manage your dashboard in dynatrace
title: Onboard additional users
labels: user management
assignees: ''

---

Please fill in this `yaml`-style template in order to onboard your users in our Allianz Technology E2E Global Monitoring Dynatrace tool:

```yaml
  mz-name: <your management zone name>           # required
  stage: <environment name>                      # required; stages supported: prod & preprod
  
  user-administration:                           # required
    view-user:
      - <email address of user1>
      - <email address of user2>
    power-user:
      - <email address of user1>
      - <email address of user2>
    admin-user:
      - <email address of user1>
      - <email address of user2>
      
# Know more about user roles https://github.developer.allianz.io/globalmonitoring/support/blob/master/q&a.md
```
