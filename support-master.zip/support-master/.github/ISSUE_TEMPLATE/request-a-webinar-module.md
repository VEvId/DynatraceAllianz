---
name: 'Request a webinar module '
about: To collect requirement for a webinar
title: 'Request a webinar module '
labels: training
assignees: ''

---

Please fill in this `yaml`-style template in order to onboard your users in our Allianz Technology E2E Global Monitoring Dynatrace tool:

```yaml
OE: <OE name>                              # required
team-name: <your team name>                # required
cost-center: <your costcenter id>          # required; example: 1234567890
desired-date: <which Wednesday>            # required we are running webinars only on Wednesdays 
desired-module: <module from catalogue>    # required
special-topic: <custom required topic>     # optional
user-counts:                               # required 
  - <Email address1>
  - <Email address2>
  
  ```
