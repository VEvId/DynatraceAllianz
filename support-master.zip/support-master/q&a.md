# Q&A

**Q: Access control for Management Zones**

| Role | Description | Permissions |
| --- | --- | ---- |
| User | Standard user, access to all non-sensitive data of the environment | Access environment |
| Power-User | Extended user for troubleshooting, it is possible to see sensitive data and logs of the environment | Access environment, View Logs & View Sensitive Request Data | 
| Admin | Full access for administration and to manage settings for the respective Management Zone | Access environment, View Logs, View Sensitive Request Data & Change Monitoring Settings |

**Q: How to identify process groups more granulary within a JBOSS server**

If Dynatrace puts processes into a group that do not belong together and you need to separate them, for instance, several JBoss nodes running in the same server, a system property `DT_JBOSS_PG_NAME` needs to be defined at startup via the -D command line parameter to indentofy groups more granulary.

**Q: Can you tell us about the usual memory and cpu usage of the OneAgent?**

The memory and CPU usage of the OneAgent always depends on the host where it's been installed.
On average it uses 0.5% of the CPU and a similar number for the memory. 
We have set some statics thresholds on the OneAgent in a way that individual portions of the OneAgent (Log Monitoring, Network Analytics, etc) will be killed off in the case that the use of the memory or CPU increase above a certain threshold. We also have adaptive load management, in which the OneAgent will select purepaths in a smart way in order to reject them and ignore the processing, reducing the amount of resources needed to monitor a huge amount of transactions.

**Q: Does Dynatrace have a maximum amount of User Sessions that I can capture?**

As stated in their [documentation](https://www.dynatrace.com/support/help/how-to-use-dynatrace/real-user-monitoring/setup-and-configuration/web-applications/troubleshooting/what-does-a-max-user-actions-per-minute-exceeded-message-mean/), Dynatrace has a static default value of capturing a maximum of 3500 User Actions per minute, in order to avoid unexpected DEM Unit licenses consumption. However, given the huge scope of our global monitoring project, this maximum has been overriden to a much higher number. You have the choice to avoid over consumption of DEM Units by yourself by changing the settings of your application and turning RUM capture off when expecting a high load consumption or by setting a percentage of User Sessions to capture. You also have the choice to import a custom dashboard to keep your DEM consumption in track [here](https://github.developer.allianz.io/globalmonitoring/support/tree/master/import_a_dashboard/templates/dem_consumption)

**Q: Can I share my dashboard with everyone in my Management Zone?**

No. Permissions for viewing or editing dashboards are done in a completely different way than that of entities in Dynatrace. Dashboards can be shared by going to the settings of a Dashboard, clicking on **Share** and **Manage access**, where we have 3 different choices:
* Shareable link. You can generate a link in order for anyone that clicks on the link to be able to see the dashboard. Settings allow you to give access to anyone with the link or only to authenticated users in Dynatrace.
* Add users manually. You can add users to the Dashboard with either View or Edit permissions. They will immediately see your dashboard once you add them.
* Publish dashboard on this environment. This option is highly not recommended and is considered a bad practice in our environment. It might sound like publishing this dashboard will publish it to anyone in your Management Zone but, instead, it will publish it to everyone in the environment, effectively sharing your dashboard to the rest of OEs and Allianz users outside your management zone.

**Q: Why can't I see any of my logs?**

When it comes to monitoring logs, it's very important to know what kind of logs you are monitoring as they could contain very sensitive information. Not only that, but depending on the size of the log, it will consume more or less log analytics licenses from Dynatrace, so we should make sure we monitor only the most important logs. For these reasons, log monitoring is an opt-in setting within our Global Monitoring Solution, meaning that it is turned off by default. In order to turn it on, this is something you can do at installation time as described in our documentation, or you can change the settings of the host on the Dynatrace User Interface for each host individually.

**Q: During peak hours and load tests, I will be consuming more licenses than usual. Is this something that Dynatrace accounts for?**

The approach that we are taking is a pay as you go approach, meaning that whatever you consume you will be paying later in the invoice for the month. If you are to consume more Host Units or DEM Units than what was agreed for a specific amount of time (or for a whole month for what is worth), you will just have to pay for it. The amount of licenses that Allianz has in their contract with Dynatrace account for a very high amount of licenses, still far from being reached so you will not lose any monitoring data for the lack of licenses.

**Q: How Dynatrace billing works**

Billing for the use of Dynatrace platform is done based on average consumption per MZ – this is how the billing script is programmed. Thus, it is important to consider the following:
We cannot provide a per-host breakdown of the bill. The consumption data collection process does not allow it.
We cannot provide an automated split of billing for one Management Zone to multiple cost centers – if you cannot take full charge of the MZ, please segregate the secondary hosts into a separate entity. The general rule is 1 MZ = 1 Cost Center.
Billing is done on a monthly basis for the month prior – only then can the charges be based on actual consumption of each MZ. Until the month is over, no actuals can be provided.
Billing to WBS elements (and not actual cost centers) is performed with a 1-month delay, as the billing of such items closes before consumption data is collected. I.e. consumption of the Monitoring service for the month of May will be billed at the end of June only.
