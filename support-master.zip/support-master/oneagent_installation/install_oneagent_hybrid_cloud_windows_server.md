## Request for Dynatrace OneAgent installation (on HybridCloud Windows)

If you want to install the oneAgent onto multiple managed servers you can follow our process to request. 

### Open a order / request in ServiceNow
- open the link: 
  - url: https://aztech.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D892067981b2f60504006206e3b4bcb48%26sysparm_link_parent%3D8f9c39931b36ec104006206e3b4bcb6b%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default%26sysparm_view%3Dcatalog_default
## Request for oneAgent installation (on HybridCloud Windows) 

Short description:  
````
installing Dynatrace OneAgent on Hybrid Cloud Windows servers
````

### Requirements
(You have to fill with your dedicated data)  
````
The config lines has this values:
- HOSTNAME: short name of host, e.g. saf123456
- ENVIRONMENT(Stage): Prod|Preprod|AZDDEV|AZDPROD
- HOSTGROUP: \<any string without blank\>          
- AGENT-VERSION:latest    # default is latest ,it will choose the latest version from AG , incase if you want to install any other version please choose the version here . eg : `1.197.134.20200723-143315`
- INSTALLMODE: full|infraonly
````
Example:
````
### Open a order / request in ServiceNow

### Hybrid Cloud - Free Text Standard Service Requests
- open the url: Free Text SSRs | ServiceNow (service-now.com)
- url: https://aztech.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D892067981b2f60504006206e3b4bcb48%26sysparm_link_parent%3D8f9c39931b36ec104006206e3b4bcb6b%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default%26sysparm_view%3Dcatalog_default
- Select the Service: Windows
- Select SSR: Windows Support
- Select the Server/CI the SSR should work on: Select any one of your servers.
- Your request text:
  - Server Name: **Server Names** Enter all the required Servers/CI's information.
  - Task Required: OneAgent Installation.
  - HOSTNAME: saf123456
  - ENVIRONMENT(Stage): Prod
  - HOSTGROUP: az-tech-devops       
  - AGENT-VERSION:latest
  - INSTALLMODE: full|infraonly

### Windows Group Name
- **HybridCloud Windows:**: A.TEC.GLOB.HC.WINDOWS

````

For further queries and support, please feel free to reach us.
