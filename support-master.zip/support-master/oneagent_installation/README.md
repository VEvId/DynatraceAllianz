### Install Dynatrace OneAgent (latest)
Depending on the machine your business application is running on, different installation methods of the Dynatrace OneAgent is required.
Please select the proper approach from the list below.

#### Managed Server (managed by AZ-Technology):
- [Service request for single Hybrid Cloud server](./install_oneagent_hybrid_cloud.md)
- [Service request for single FMO/IBM server](./install_oneagent_fmo.md)
- [Use Change request for multiple servers](./install_with_changerequest.md)

#### Self-managed services:
- [Linux Server (VM)](./install_oneagent_linux_server.md)
- [Windows Server (VM)](./install_oneagent_windows.md)
- [AIX server](./install_oneagent_aix_server.md)
- [OpenShift Single Container](./install_oneagent_openshift_container.md)
- [OpenShift StatefulSet](./install_oneagent_openshift_stateful_set.md)
- [Pivotal Cloud Foundry](./install_oneagent_PCF.md)
- [Elastic Kubernetes Service (EKS)](./install_oneagent_on_eks.md)
- [Manage OneAgent installation on CRP2.0 Kubernetes Clusters](./install_oneagent_on_crp_2.0.md)
- [Change OneAgent installation to another tenant](./agent_change_tenant.md)

### Define your HOSTGROUP
The HOSTGROUP is a important parameter you need for the oneAgent installation. The HOSTGROUP parameter is helpful to group a set of hosts and its related processes and services.
Consider that hosts belong to at most one Host_Group, so there's no overlap between hosts and Host_Groups. The Global Monitoring team has a specific schema for HOSTGROUP selection and joining to correct management zone:
```
HOSTGROUP=<prefix: same as your mz but without the 'mz-'>-<your group name>
```
For example, the hosts belong to the team/management zone ```mz-az-tech-itmp``` and you have two application RAP and CISL then you can choose host 
groups ```az-tech-itmp-rap``` and ```az-tech-itmp-cisl``` while deploying agents.

### Select specific OneAgent version
One can easily download a previous version of the Dynatrace OneAgent in case that (eg. on 'prod' environments) the release of `latest` seems to be too risky.

After getting the correct `DT_PAAS_TOKEN` from the tenants overview page, send a `GET` request 
```bash
$ curl https://{tenant_id}.live.dynatrace.com/api/v1/deployment/installer/agent/versions/{os_type}/{installer_type}?flavor={flavor}&arch=all
``` 
where `{tenant_id}` must be replaced by the id of the `prod` or `preprod` environment.

The response is a list of the available OneAgent versions, labelled by version strings of the form `major.minor.revision.timestamp`.

For downloading the desired version, copy the binary using either `curl` or `wget` from the URL
```bash
https://{tenant_id}/live.dynatrace.com/api/v1/deployment/installer/agent/{os_type}/{installer_type}/version/{version}
```

In case that your host machine does not have Internet access, replace `https://{tenant_id}.live.dynatrace.com/api/v1` with `https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999/e/{tenant_id}/api/v1`
in order to access the Dynatrace API via the Environment Active Gate.

#### Technical details

The supported `{os_type}` values are
- `windows`
- `unix`
- `aix`
- `solaris`
- `zos`

The non-deprecated `{installer_type}` options are one of 
- `paas`: for application-only monitoring (OpenShift/Kubernetes/PCF containers)
- `default`: for a permanent installation on a physical host or a virtual machine

Use `{default-sh}` and `{paas-sh}` at your own risk!

The `{flavor}` options are one of
- `default` for most use cases
- `musl`: for Linux distros using the `musl C library` (eg. `Alpine`)

**Note that not all combinations of `{os_type}`, `{installer_type}` and `{flavor}` are supported!**
The response will be a `404` error in this case.

### Network Zone

Chosing a `NETWORK_ZONE` in accordance with your host's location, enables shorter and hence faster network connections between your OneAgent and an ActiveGate.

Available `NETWORK_ZONES` are

| Network Zone                    | Scope                                                              |
|---------------------------------|--------------------------------------------------------------------|
| az.aws.ec1                      | Instances in AWS EC1                                               |
| az.aws.ec1-fcp-ssm              | Instances in AWS EC1 in the FCP Shared Services/Management Network |
| az.aws.ew3                      | Instances in AWS EW3                                               |
| az.aws.ew3-fcp-ssm              | Instances in AWS EW3 in the FCP Shared Services/Management Network |
| az.aws.ase1                     | Instances in AWS ASE1                                              |
| az.aws.ase2                     | Instances in AWS ASE2                                              |
| az.on-prem.e1                   | Instances in E1                                                    |
| az.on-prem.e2                   | Instances in E2                                                    |
| az.on-prem.ap1                  | Instances in AP1                                                   |
| az.on-prem.ap2                  | Instances in AP2                                                   |
| az.on-prem.br1                  | Instances in BR1                                                   |
| az.on-prem.my1                  | Instances in MY1                                                   |
| az.on-prem.lv                   | Instances in LV                                                    |
| az.azure.europe-west            | Instances in Azure West Europe                                     |
| az.azure.france-central         | Instances in Azure France Central                                  |
| az.azure.asia-pacific-southeast | Instances in Azure Southeast Asia                                  |
| az.azure.australia-east         | Instances in Azure Australia East                                  |


If you cannot find your host's zone in the table above, please contact the [global monitoring support](https://github.developer.allianz.io/globalmonitoring/support) to create the appropriate zone.




