# Deploy OneAgent on Pivotal Web Services for application-only monitoring

## Get your dedicated PaaS token
If you didn't get a **dedicated PaaS `apitoken`** for your Management Zone during the onboarding process, please open a new [ticket](https://github.developer.allianz.io/globalmonitoring/support/issues/new/choose) an order a new PaaS token to our support team.

## Create a Dynatrace service in your Cloud Foundry environment

Create a single service instance for Dynatrace with the name `dynatrace` as a substring (for example, `dynatrace-service`) using the command below.
The command should include the parameters `environmentid` and `apitoken` written exactly as shown below.
Once the command is executed, you'll be prompted to enter your environment ID and API token.
The API token corresponds to the PaaS token mentioned above.

The code example below use the `cf` CLI for interfacing with Cloud Foundry clusters.

```yaml
cf cups dynatrace-service -p "environmentid, apitoken"
```

Description | `environmentid` | 
--- | --- |
Prod | ````grz73876```` |
PreProd | ````ily59392```` |

## Bind Dynatrace service to your application

You can either bind the created Dynatrace service to your application in your `manifest.yml` file prior to starting your app or you can bind the service to your app and restage the app afterwards.

If you're pushing a Java application, this could look like the following example:
```yaml
applications:
- name: spring-music
  memory: 768M
  instances: 1
  host: spring-music-${random-word}
  path: spring-music.war
  buildpack: https://github.com/cloudfoundry/java-buildpack.git
services:
  - dynatrace-service
```
  
## Configure the Network Zones
Please configure the network zone according to your Cloud Foundry via
```text
cf set-env APP_NAME DT_NETWORK_ZONE <your_network_zone>
```

The network zones are:

| Network Zone                    | Scope                                                              |
|---------------------------------|--------------------------------------------------------------------|
| az.aws.ec1                      | Instances in AWS EC1                                               |
| az.aws.ec1-fcp-ssm              | Instances in AWS EC1 in the FCP Shared Services/Management Network |
| az.aws.ew3                      | Instances in AWS EW3                                               |
| az.aws.ew3-fcp-ssm              | Instances in AWS EW3 in the FCP Shared Services/Management Network |
| az.aws.ase1                     | Instances in AWS ASE1                                              |
| az.aws.ase2                     | Instances in AWS ASE2                                              |
| az.on-prem.e1                   | Instances in E1                                                    |
| az.on-prem.e2                   | Instances in E2                                                    |
| az.on-prem.ap1                  | Instances in AP1                                                   |
| az.on-prem.ap2                  | Instances in AP2                                                   |
| az.on-prem.br1                  | Instances in BR1                                                   |
| az.on-prem.my1                  | Instances in MY1                                                   |
| az.on-prem.lv                   | Instances in LV                                                    |
| az.azure.europe-west            | Instances in Azure West Europe                                     |
| az.azure.france-central         | Instances in Azure France Central                                  |
| az.azure.asia-pacific-southeast | Instances in Azure Southeast Asia                                  |
| az.azure.australia-east         | Instances in Azure Australia East                                  |


If you cannot find your host's zone in the table above, please contact the [global monitoring support](https://github.developer.allianz.io/globalmonitoring/support) to create the appropriate zone.


  
## Configure default OneAgent log stream for Cloud Foundry (optional)

By default, OneAgent logs are written to the Cloud Foundry standard error stream.
With OneAgent version 1.125 or later, you can configure the default OneAgent log stream for applications deployed in your Cloud Foundry environment.
All you have to do is set the environment variable `DT_LOGSTREAM` to either `stdout` or `stderr`.

For example:

```text
cf set-env APP_NAME DT_LOGSTREAM stdout
```