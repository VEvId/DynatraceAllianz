## Change request for oneAgent installation (on Linux)

If you want to install the oneAgent to multiple managed servers you can use a change request. 

### Open a change request in ServiceNow
- Open a new **Normal change** in ServiceNow and fill all the required information.
- Add all the servers to the CI list

### Open Change tasks
Open a change task to this groups:
- **HybridCloud Linux:**: A.TEC.GLOB.HC.LINUX
- **FMO/IBM Linux:** IBM.DS.UNIX.EUR

Short description:  
````
Add Dynatrace in SYSCONF
````

Requirement: (You have to fill with your dedicated data)  
````
Add following configuration lines to the hosts config of subsystem Dynatrace
<HOSTNAME>;<ENVIRONMENT>;<HOSTGROUP>;<PORT-RANG>;<AGENT-VERSION>;<INSTALLMODE>;[<HOST-PROPERTY-LIST>]
...
Add the Dynatrace subsystem to the hosts and trigger a sysconf update.
````
The config lines has these values:
- HOSTNAME: short name of host, e.g. saf123456
- ENVIRONMENT(Stage): Prod|Preprod|AZDDEV|AZDPROD
- HOSTGROUP: \<any string without blank\>
- PORT-RANGE:50000:50100   # default port is used by watch dog process internally is 50000:50100.In case if this port is used by anyother app you can choose your own
- AGENT-VERSION:latest    # default is latest ,it will choose the latest version from AG , incase if you want to install any other version please choose the version here . eg : `1.197.134.20200723-143315`
- INSTALLMODE: full|infraonly
- HOST-PROPERTY: optional parameters, syntax: [prop1=value1,prop2=value2,...]

Example:
````
sla24751;Prod;az-af-abssahara-esb;50000:50100;latest;full;[ProfitCenter=B62]
````

For ````INSTALLMODE=full```` normally a restart of all the applications in the server is required. You can request this with annother 
change task giving exact description how to restart or you can request for a server reboot in a separat change task.



