## Manage OneAgent installation on CRP2.0 Kubernetes Clusters

**TODO:** update the examples/instructions with the azure cli tool!     


By default, CRP2.0 team delivers new `EKS` and/or `AKS` clusters with preinstalled OneAgents on each worker node.
The installation done by CRP2.0 team does not differ from the installation described in [Elastic Kubernetes Service (EKS)](./install_oneagent_on_eks.md) installation.

If not altered, the OneAgent is installed with the following options:
* `--set-app-log-content-access=true`
* `--set-host-group=<host_group_name>`
* `--set-infra-only=true`
* `--set-network-zone=<network_zone>`

### Get current configuration
One can check the current parameter settings passed to the OneAgent installer via
```bash
$ kubectl get oneagents --namespace=adp-dynatrace

NAME       APIURL                                                                   TOKENS     VERSION                     PHASE     AGE
oneagent   https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999/e/ily59392/api   oneagent   1.209.169.20210219-191956   Running   217d

```
```bash
$ kubectl --namespace=adp-dynatrace get oneagent oneagent --output=json
```
or in case that the `jq` parser is available via
```bash
$ kubectl --namespace=adp-dynatrace get oneagent oneagent --output=json | jq .spec.args
```
with the output
```json
[
  "--set-app-log-content-access=true",
  "--set-host-group=<host_group_name>",
  "--set-infra-only=false",
  "--set-network-zone=<network_zone>"
]
```

### Update OneAgent configuration
As soon as the OneAgent customer resource object is altered, Kubernetes will redeploy the OneAgent pods automatically.

For a _manual_ update, one can use `kubectl --namespace=adp-dynatrace edit oneagent oneagent` and update the settings directly.

For an _automated_ update, we suggest to implement the following approach in a scripting language of your choice:
1. Check the current status via 
   ```bash
   $ kubectl --namespace=adp-dynatrace get oneagent oneagent --output=json
   ```
   Parse the response according to `jq .spec.args`.
2. If the `--set-infra-only=true/false` parameter needs to be replaced, execute the following `kubectl patch` command:
   ```bash
   $ kubectl --namespace=adp-dynatrace patch oneagent oneagent \
               --type=json \
               --patch='[{"op": "replace", "path": "/spec/args", "value": ["--set-app-log-content-access=true", "--set-host-group=<host_group_name>", "--set-infra-only=true", "--set-network-zone=<network_zone>"]}]'
   ```
   without changing any of the values `<host_group_name>` and `<network_zone>`.

   Kubernetes will confirm the patch with a `oneagent.dynatrace.com/oneagent patched` message.
3. Observe the recreation of the `oneagent` and the redeployment of the corresponding pods via
   ```bash
   $ kubectl --namespace=adp-dynatrace get oneagents
   ```
   and
   ```bash
   $ kubectl --namespace=adp-dynatrace get pods
   ```
4. In order to _persist_ the changes permanently, add a `configMap` object to the namespace `adp-dynatrace` with the following content:
   ```yaml
   apiVersion: v1
   kind: ConfigMap
   metadata:
     name: oneagent-config
     namespace: adp-dynatrace
   data:
     infra_only: <true/false>
   ```
   This `configMap` will be read during any upgrade steps performed by the CRP 2.0 team.
