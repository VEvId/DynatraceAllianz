## Install OneAgent on a Windows Server (manually, privileged admin access required)
### Prerequisites/Preparation
#### 1.	Check available space
Dynatrace recommends 6.5 GByte free disk space for a full-stack installation.
By default it will be installed in `C:\` drive.`

More details:  
https://www.dynatrace.com/support/help/technology-support/operating-systems/windows/installation/disk-space-requirements-for-oneagent-installation-and-update-on-windows/

#### 2.	Check connectivity

Dynatrace OneAgent needs to communicate with an ActiceGate to transfer the monitoring data.
List of ActiveGates with usage are updated below. 
You can choose the ActiveGates according to your usage. 

##### 1. PreProd & prod support (Normal usage)

| Nr  | Location                                                    | ActiveGate-URL                                                  | IP                                                                                                                                | Usage                    | status             |
|-----|-------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|--------------------------|--------------------|
| 1   | E1 (Frankfurt)                                              | https://dt-eag2-e1.srv.allianz:9999                             | 44.160.240.64                                                                                                                     | multi-tenant (oneAgents) | :heavy_check_mark: |
| 2   | E2 (Paris)                                                  | https://dt-eag2-e2.srv.allianz:9999                             | 44.168.240.56                                                                                                                     | multi-tenant (oneAgents) | :heavy_check_mark: |
| 3   | AP1 (Singapore)                                             | https://dt-eag1-ap1.srv.allianz:9999                            | 10.186.32.64                                                                                                                      | multi-tenant (oneAgents) | :heavy_check_mark: |
| 4   | AP1 (Singapore)                                             | https://dt-eag2-ap1.srv.allianz:9999                            | 10.186.32.71                                                                                                                      | multi-tenant (oneAgents) | :heavy_check_mark: |
| 5   | AWS-EW3 (Paris)                                             | https://dt-eag.e2e-mon.ew3.aws.aztec.cloud.allianz:9999         | <ul><li>44.133.140.28 (eu-west-3a)</li><li>44.133.140.37 (eu-west-3b)</li><li>44.133.140.69 (eu-west-3c)</li></ul>                | multi-tenant (oneAgents) | :heavy_check_mark: |
| 6   | AWS-EW3 Future Cloud Platform (Shared Services/Management)  | https://dt-eag-fcp-ssm.e2e-mon.ew3.aws.aztec.cloud.allianz:9999 | <ul><li>44.121.80.42 (eu-west-3a)</li><li>44.121.84.42 (eu-west-3b)</li><li>44.121.88.42 (eu-west-3c)</li></ul>                   | multi-tenant (oneAgents) | :heavy_check_mark: |
| 7   | AWS-EC1- (Frankfurt)                                        | https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999         | <ul><li>44.130.167.140 (eu-central-1a)</li><li>44.130.167.168 (eu-central-1b)</li><li>44.130.167.205 (eu-central-1c)</li></ul>    | multi-tenant (oneAgents) | :heavy_check_mark: |
| 8   | AWS-EC1 Future Cloud Platform (Shared Services/Management)  | https://dt-eag-fcp-ssm.e2e-mon.ec1.aws.aztec.cloud.allianz:9999 | <ul><li>44.120.128.42 (eu-central-1a)</li><li>44.120.132.42 (eu-central-1b)</li><li>44.120.136.42 (eu-central-1c)</li></ul>       | multi-tenant (oneAgents) | :heavy_check_mark: |
| 9   | AWS-ASE1 (Singapore)                                        | https://dt-eag.e2e-mon.ase1.aws.aztec.cloud.allianz:9999        | <ul><li>44.131.231.45 (ap-southeast-1a)</li><li>44.131.231.15 (ap-southeast-1b)</li><li>44.131.231.79 (ap-southeast-1c)</li></ul> | multi-tenant (oneAgents) | :heavy_check_mark: |
| 10  | AWS-ASE2 (Sydney)                                           | https://dt-eag.e2e-mon.ase2.aws.aztec.cloud.allianz:9999        | <ul><li>44.131.60.15 (ap-southeast-2a)</li><li>44.131.60.45 (ap-southeast-2b)</li><li>44.131.60.79 (ap-southeast-2c)</li></ul>    | multi-tenant (oneAgents) | :heavy_check_mark: |
| 11  | AZURE-WE1 (Amsterdam)                                       | https://dt-eag.e2e-mon.we1.azure.aztec.cloud.allianz:9999       | <ul><li>44.138.60.6 (west-europe-1)</li><li>44.138.60.6 (west-europe-2)</li><li>44.138.60.6 (west-europe-3)</li></ul>             | multi-tenant (oneAgents) | :heavy_check_mark: |


##### 2. PreProd (dedicated usage)

Nr. | Location |ActiveGate-URL | IP | Usage |status|
--- | --- | --- | --- | --- | ---
1 |E1 (Frankfurt)| https://dt-eag1-e1.srv.allianz:9999 |44.160.240.63 | PreProd Plugins/oneAgents | :heavy_check_mark:
2 |E1 (Frankfurt)| https://dt-eag6-e1.srv.allianz:9999 |44.160.240.102 | PreProd Mainframe | :heavy_check_mark:
3 |E1 (Frankfurt)| https://dt-eag4-e1.srv.allianz:9999 |44.160.240.96 | PreProd Synthetic | :heavy_check_mark:
4 |E2 (Paris)| https://dt-eag4-e2.srv.allianz:9999 |44.168.240.104 | PreProd Synthetic | :heavy_check_mark:
5 |E2 (Paris)| https://dt-eag1-e2.srv.allianz:9999 | 44.168.240.55 | PreProd Plugins/oneAgents | :heavy_check_mark:
6 |AWS-EW3 (Paris)|https://dt-sag-preprod.e2e-mon.ew3.aws.aztec.cloud.allianz:9999 |44.133.140.9 | PreProd Synthetic | :heavy_check_mark:
3 |AWS-EC1 (Frankfurt)| https://dt-sag-preprod.e2e-mon.ec1.aws.aztec.cloud.allianz:9999 |44.130.167.158 | PreProd Synthetic | :heavy_check_mark:

#####  3. Prod (dedicated usage)
Nr. | Location |ActiveGate-URL | IP | Usage |status|
--- | --- | --- | --- | --- | ---
1 |E1 (Frankfurt)| https://dt-eag3-e1.srv.allianz:9999 | 44.160.240.95 | Prod Plugins/oneAgent | :heavy_check_mark:
2 |E1 (Frankfurt)| https://dt-eag5-e1.srv.allianz:9999 | 44.160.240.100 | Prod Synthetic | :heavy_check_mark:
3 |E2 (Paris)| https://dt-eag3-e2.srv.allianz:9999 |44.168.240.98 | Prod Plugins/oneAgent | :heavy_check_mark:
4 |E2 (Paris)| https://dt-eag5-e2.srv.allianz:9999 | 44.168.240.117 | Prod Synthetic | :heavy_check_mark:
5 |AWS-EW3 (Paris)| https://dt-sag-prod.e2e-mon.ew3.aws.aztec.cloud.allianz:9999 |44.133.140.27 | Prod Synthetic  | :heavy_check_mark:
2 |AWS-EC1 (Frankfurt)| https://dt-sag-prod.e2e-mon.ec1.aws.aztec.cloud.allianz:9999 |44.130.167.13 | Prod Synthetic  | :heavy_check_mark:

Check API connectivity (will be used for Agent download later) to your next located ActiveGate using command line:
```
curl -k -L --write-out "%{http_code}\n" "<ActiveGate-URL>/communication"
```
Here, please fill in the `<ActiveGate-URL>` as in the table above. 
For example, on E1 use
```
curl -k -L --write-out "%{http_code}\n" "https://dt-eag1-e1.srv.allianz:9999/communication
```
**Expected result:** `200`

Check API connectivity (will be used for Agent download later):
##### Production environment
````
curl -k "<ActiveGate-URL>/e/grz73876/api/v1/time"
````

Here, please fill in the `<ActiveGate-URL>` as in the table above. For example, on E1 use
````
curl -k "https://dt-eag3-e1.srv.allianz:9999/e/grz73876/api/v1/time"
````

##### Pre-production environment
````
curl -k "<ActiveGate-URL>/e/ily59392/api/v1/time"
````
Again, please replace `<ActiveGate-URL>` by the respective URL.

**Expected result:** Cluster time in UTC milliseconds like ````1583407525704````.

If `curl` is not available on the server you also can check the connection by using the internet browser:  
Opening `<ActiveGate-URL>/e/grz73876/api/v1/time` you should see the timestamp in the browser.
If you get a security warning because of a wrong certificate please accept to load the page anyway.

If connection fails, normally a firewall change is needed to the target IPs of the ActiveGates on port `9999`.

If you are unable to connect to any of the `<ActiveGate-URL>` based on location then please contact us.

#### Notes on the Connectivity on AWS EC1 & EW3

For the Active Gates in AWS, you may need a FCC to the three IPs as listed in the table (or at least one for each desired availability zone).

A strong indicator for the necessity of a FCC is the statement `Received http code 502 from proxy` in return of a connectivity check command as above.

Note that your VPC must be connected to the Allianz network via an AWS service endpoint (which should be the case by default). 


#### 3. Network Zones
Chosing a `NETWORK_ZONE` in accordance with your host's location, enables shorter and hence faster network connections between your OneAgent and an ActiveGate.

Available `NETWORK_ZONES` are

| Network Zone                    | Scope                                                              |
|---------------------------------|--------------------------------------------------------------------|
| az.aws.ec1                      | Instances in AWS EC1                                               |
| az.aws.ec1-fcp-ssm              | Instances in AWS EC1 in the FCP Shared Services/Management Network |
| az.aws.ew3                      | Instances in AWS EW3                                               |
| az.aws.ew3-fcp-ssm              | Instances in AWS EW3 in the FCP Shared Services/Management Network |
| az.aws.ase1                     | Instances in AWS ASE1                                              |
| az.aws.ase2                     | Instances in AWS ASE2                                              |
| az.on-prem.e1                   | Instances in E1                                                    |
| az.on-prem.e2                   | Instances in E2                                                    |
| az.on-prem.ap1                  | Instances in AP1                                                   |
| az.on-prem.ap2                  | Instances in AP2                                                   |
| az.on-prem.br1                  | Instances in BR1                                                   |
| az.on-prem.my1                  | Instances in MY1                                                   |
| az.on-prem.lv                   | Instances in LV                                                    |
| az.azure.europe-west            | Instances in Azure West Europe                                     |
| az.azure.france-central         | Instances in Azure France Central                                  |
| az.azure.asia-pacific-southeast | Instances in Azure Southeast Asia                                  |
| az.azure.australia-east         | Instances in Azure Australia East                                  |


If you cannot find your host's zone in the table above, please contact the [global monitoring support](https://github.developer.allianz.io/globalmonitoring/support) to create the appropriate zone.



#### 4. Installation
Login to the machine with admin access, open an command prompt (cmd) and navigate to some tmp folder: 
```
cd C:\TEMP
```
Download the binary installation archive: Use your nearest ActiveGate in the beginning of the URL.

##### Prepare installation parameters

Providing a valid `HOST_GROUP_NAME` during OneAgent installation is crucial for the host's metrics' visibility in Dynatrace.

The `HOST_GROUP_NAME` is composed according to the scheme `az-<oe>-<team>-<identifier>` where `<oe>` and `<team>` define your _organizational entity_ and _team_, respectively,
and the `<identifier>` is used to further identify the purpose of the host. 

Note that the `identifier` may not contain hyphens!

Furthermore, it's recommended to define a `NETWORK_ZONE` during installation in order to preconfigure a default set of ActiveGates that the OneAgent will later connect to.
Using a `NETWORK_ZONE` in accordance with your host's platform location enables shorter and hence faster network connections.

More parameters are available for custom installation:
https://www.dynatrace.com/support/help/technology-support/operating-systems/windows/installation/customize-oneagent-installation-on-windows/

##### Production environment
```
curl -k -o Dynatrace-OneAgent-Windows-latest.exe "https://dt-eag2-e1.srv.allianz:9999/e/grz73876/api/v1/deployment/installer/agent/windows/default/latest?Api-Token=CF95DSOwRT-RqOzh_Y-_k&arch=x86&flavor=default"
```
##### Pre-production environment
```
curl -k -o Dynatrace-OneAgent-Windows-latest.exe "https://dt-eag2-e1.srv.allianz:9999/e/ily59392/api/v1/deployment/installer/agent/windows/default/latest?Api-Token=_JHfm5hGQgSlkyFPttRyi&arch=x86&flavor=default"
```

If `curl` is not available on the server you can use the internet browser to download the file:  
* Production: Open https://dt-eag2-e1.srv.allianz:9999/e/grz73876/api/v1/deployment/installer/agent/windows/default/latest?Api-Token=CF95DSOwRT-RqOzh_Y-_k&arch=x86&flavor=default
* Pre-Production: Open https://dt-eag2-e1.srv.allianz:9999/e/ily59392/api/v1/deployment/installer/agent/windows/default/latest?Api-Token=_JHfm5hGQgSlkyFPttRyi&arch=x86&flavor=default
* Use `Save as` to store the file  as `C:\TEMP\Dynatrace-OneAgent-Windows-latest.exe`.
* If you get a security warning because of a wrong certificate please accept to load the page anyway.

Check the file:
```
C:\TEMP> dir Dynatrace-OneAgent-Windows-latest.exe
```
Result output similar to:
```
 Datenträger in Laufwerk C: ist Windows
 Volumeseriennummer: 6A68-1B2B

 Verzeichnis von C:\TEMP

11.03.2020  12:42        82.885.512 Dynatrace-OneAgent-Windows-latest.exe
               1 Datei(en),     82.885.512 Bytes
               0 Verzeichnis(se), 23.986.618.368 Bytes frei
```


Run installer: Use your nearest ActiveGate in parameter `--set-server`, 
your predefined `HOST_GROUP` in the parameter `--set-host-group`
and your predefined `NETWORK_ZONE` in the parameter `--set-network-zone` .

You can also use the variable for your directory selection `INSTALL_PATH="D:\test dir" ` .
Default directory is on `C:\` drive.

##### 4.1. Enable Fullstack Monitoring
```
C:\TEMP\Dynatrace-OneAgent-Windows-latest.exe --quiet ^
                                              --set-app-log-content-access=true ^
                                              --set-infra-only=false ^
                                              --set-server=https://dt-eag2-e1.srv.allianz:9999 ^
                                              --set-host-group=<my predifined host group> ^
                                              --set-network-zone=<my prefefined network zone id>
```
##### 4.2. Enable Infrastructure only Monitoring 
```
C:\TEMP\Dynatrace-OneAgent-Windows-latest.exe --quiet ^
                                              --set-app-log-content-access=true ^
                                              --set-infra-only=true ^
                                              --set-server=https://dt-eag2-e1.srv.allianz:9999 ^
                                              --set-host-group=<my predifined host group> ^
                                              --set-network-zone=<my predefined network zone>
```

Check the installation log file: The log file is located in `C:\ProgramData\dynatrace\oneagent\log\installer`.
Search for the file like this `installation_msiexec_<timestamp>.log` with the latest timestamp and check for `Dynatrace OneAgent -- Installation completed successfully.` in one of the last lines in the file.

Note: Difference between infrastructure only monitoring and full stack in Dynatrace

![FullstackVsCIM](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/FullstackVsCIM.png)

##### 4.3. Enable Log Monitoring
 
 After the agent installation you should enable log monitoring from your host in Dynatrace GUI as well (please follow below steps)
 
 ![log](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/logmonitoring.gif)


##### 4.4. Disable Log Monitoring
If not specified, Log Monitoring will be enabled by default. Make sure to set the flag ```--set-app-log-content-access=false``` during installation to disable Log Monitoring.