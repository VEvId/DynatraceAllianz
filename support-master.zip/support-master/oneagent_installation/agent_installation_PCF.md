# Deploy OneAgent on Pivotal Web Services for application-only monitoring

## Get your dedicated PaaS token
If you didn't get a **dedicated PaaS `apitoken`** for your Management Zone during the onboarding process, please open a new [ticket](https://github.developer.allianz.io/globalmonitoring/support/issues/new/choose) an order a new PaaS token to our support team.

## Create a Dynatrace service in your Cloud Foundry environment

Create a single service instance for Dynatrace with the name `dynatrace` as a substring (for example, `dynatrace-service`) using the command below. The command should include the parameters `environmentid` and `apitoken` written exactly as shown below. Once the command is executed, you'll be prompted to enter your environment ID and API token. The API token corresponds to the PaaS token mentioned above.

The code example below use the `cf` CLI for interfacing with Cloud Foundry clusters.

```yaml
cf cups dynatrace-service -p "environmentid, apitoken"
```

Description | `environmentid` | 
--- | --- |
Prod | ````grz73876```` |
PreProd | ````ily59392```` |

## Bind Dynatrace service to your application

You can either bind the created Dynatrace service to your application in your manifest.yml file prior to starting your app or you can bind the service to your app and restage the app afterwards.

If you're pushing a Java application, this could look like the following example:

```yaml
---
applications:
- name: spring-music
  memory: 768M
  instances: 1
  host: spring-music-${random-word}
  path: spring-music.war
  buildpack: https://github.com/cloudfoundry/java-buildpack.git
services:
  - dynatrace-service
  ```
  
## Configure default OneAgent log stream for Cloud Foundry (optional)

By default, OneAgent logs are written to the Cloud Foundry standard error stream. With OneAgent version 1.125 or later, you can configure the default OneAgent log stream for applications deployed in your Cloud Foundry environment. All you have to do is set the environment variable `DT_LOGSTREAM` to either `stdout` or `stderr`.

For example:

```javascript
cf set-env APP_NAME DT_LOGSTREAM stdout
```
