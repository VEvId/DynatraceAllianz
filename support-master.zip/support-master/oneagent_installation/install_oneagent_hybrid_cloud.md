# Install OneAgent on a Hybrid Cloud Server

1. Access [SIM Service Portal](https://aztech.service-now.com/nav_to.do?uri=%2Fcatalog_home.do%3Fsysparm_view%3Dcatalog_default) and click the **Order Something** link.

![snowhc1](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc1.png)

2. Click the **Infrastructure Service** link.

![snowhc2](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc2.png)

3. Click the **Server Services** link.

![snowhc3](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc3.png)

4. Click the **Hybrid Cloud Services** link.

![snowhc4](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc4.png)

5. Click the **Hybrid Cloud Services** link.

![snowhc5](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc5.png)

6. Click the **Change for existing services** link.

![snowhc6](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc6.png)

7. Click the **Standard Service Requests** link.

![snowhc7](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc7.png)

8. Select the following items:

- Select **server** to install the Dynatrace OneAgent
- Select SSRs **Install Dynatrace Agent**
- Select **Data Center** (E1 or E2)
- Select **Stage** (Preproduction or Production)
- Inform the **Host Group** shared during the onboarding process (Check your GitHub support ticket)
- Monitoring **type** (Full Stack or Cloud Infrastructure monitoring)

![snowhc8](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc8.png)

9. Click the **Order Now** link
