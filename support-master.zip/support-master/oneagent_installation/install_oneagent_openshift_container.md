## Install OneAgent inside Kubernetes Deployment

### Run-time installation
The installation during *run time* has the advantage that no application Docker image needs to be changed and rebuilt.
Therefore this is the recommended way to monitor applications running inside Docker containers (OpenShift pods).

#### `initContainer` preparation, `environment variables` setup and `volume` specification
Supplement the deployment configuration with an `initContainer` and an ephemeral volume with the following configuration:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: {...} 
spec:
  selector: {...}
  template:
    metadata: {...}
    spec:
      containers:
        - <your application container configuration goes here>
          env:
            - <your predefined envs go here>
            - name: LD_PRELOAD
              value: /opt/dynatrace/oneagent/agent/lib64/liboneagentproc.so
            - name: DT_NETWORK_ZONE
              value: <your_network_zone, cf. table below>
            - name: DT_CUSTOM_PROP
              value: <whitespace-separated list of keys or key-value pairs>
            - name: DT_TAGS
              value: <whitespace separated list of tags>
            - name: DT_CONNECTION_POINT
              value: <cf. table below>
          volumeMounts:
            - mountPath: /opt/dynatrace/oneagent
              name: oneagent
      initContainers:
        - image: 'alpine:3.8'
          imagePullPolicy: IfNotPresent
          name: install-oneagent
          env:
            - name: DT_API_URL
              value: <cf. table below>
            - name: DT_PAAS_TOKEN
              value: <cf. table below>
            - name: DT_ONEAGENT_OPTIONS
              value: flavor=<flavor>&include=<technology>
          command:
            - /bin/sh
          args:
            - '-c'
            - >-
              ARCHIVE=$(mktemp) && wget -O $ARCHIVE
              "${DT_API_URL}/v1/deployment/installer/agent/unix/paas/latest?Api-Token=${DT_PAAS_TOKEN}&${DT_ONEAGENT_OPTIONS}"
              && unzip -o -d /opt/dynatrace/oneagent ${ARCHIVE} && rm -f ${ARCHIVE}
          resources: {}
          terminationMessagePath: /dev/termination-log
          terminationMessagePolicy: File
          volumeMounts:
            - mountPath: /opt/dynatrace/oneagent
              name: oneagent
       volumes:
         - <your predefined volumes go here>
         - emptyDir: {}
           name: oneagent
```


This change advises the `initContainer` to load the *OneAgent* binary from the Dynatrace Environment and to write it to the ephemeral volume `oneagent`.
Afterwards, the *OneAgent* binary is made available to the application container by mounting the same volume to `/opt/dynatrace/oneagent`.

The `<flavor>` is `default` for Docker images based on non-`Alpine Linux`; users of `Alpine Linux`-based images must select `flavor=musl`.

Supported values for the `<technology>` parameter are `all`, `java`, `apache`, `nginx`, `nodejs`, `dotnet`, `php` and `go`.
Note that `flavor=musl` excludes `dotnet`, `php` and `go`.
For more details, visit the [official Dynatrace documentation](https://www.dynatrace.com/support/help/technology-support/cloud-platforms/kubernetes/other-deployments-and-configurations/deploy-oneagent-on-kubernetes-for-application-only-monitoring/#expand-1318integrate-at-container-runtime). 

These ephemeral volumes may not be configured in the `volumeClaimTemplates` section, since this section is reserved for *persistent* volumes.
Furthermore, the ephemeral volumes `oneagent` do not interfere in case of horizontal scaling, ie. one ephemeral volume will be created with every new pod.

The environment variable `LD_PRELOAD` in the application container(s) is essential for the monitoring to work properly
(basically, it tells the OS to load the dynatrace binary before each command execution).

The optional environment variable `DT_CUSTOM_PROP` accepts a list of `key-value pairs` which will
be exposed to Dynatrace on `Process group` and `Service` level.
The `key-value pairs` will be added as `Environment Custom Meta Data` to `Process groups`/`Services` and allow for fine-granular filers to make entities visible inside a `Management Zone`.

Usually, the env `DT_CUSTOM_PROP` is the right place to put the `HOST_GROUP` name that was provided by the Global Monitoring team during onboarding.
Add it in the form
```yaml
    env:
      - name: DT_CUSTOM_PROP
        value: HOST_GROUP_NAME=az-<oe>-<team>-<application_name> <another_key>=<another_value> ...
```
to the deployment configuration. `key-value` pairs from `DT_CUSTOM_PROP` will be added to `PROCESS_GROUPS` and `SERVICES` in Dynatrace and will be propagated to `HOSTS` automatically.
Nevertheless, if your pod doesn't run a monitored process, please add the entry `HOST_GROUP_NAME=az-<oe>-<team>-<application_name>` to the environment variable `DT_TAGS`.

A `Management Zone Rule` that scans for the `[Environment]HOST_GROUP_NAME` will be automatically added to each `Management Zone`.

The optional environment variable `DT_TAGS` accepts a list of `tags` (both single `values` and `key-value-pairs` are supported) which will be exposed to Dynatrace on `Process Group` and `Service` level.
In contrast to the `key-value pairs` offered by `DT_CUSTOM_PROP`, the `tags` obtained from `DT_TAGS` can additionally be used for manual filtering in `Transactions and services` section of the GUI. 

#### Connection Point

The additional environment variable `DT_CONNECTION_POINT` is pointing to the URLs of the installed *ActiveGates* on the network.
The table below exhibits all available data-center specific URLs.
Unless you have ordered a dedicated tenant, the table also exhibits the proper `DT_API_URL` and `DT_PAAS_TOKEN` for downloading the agents.

DC | Stage |`DT_CONNECTION_POINT` | `DT_API_URL` (https://<tenant_id>.live.dynatrace.com/api) | `DT_PAAS_TOKEN` |
--- | --- | --- | --- | --- |
E1  | Prod    | `https://dt-eag2-e1.srv.allianz:9999`  | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
E2  | Prod    | `https://dt-eag2-e2.srv.allianz:9999`  | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
EC1 | Prod    | `https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999` | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
EW3 | Prod    | `https://dt-eag.e2e-mon.ew3.aws.aztec.cloud.allianz:9999` | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
AP1 | Prod    | `https://dt-eag1-ap1.srv.allianz:9999` | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
AP1 | Prod    | `https://dt-eag2-ap1.srv.allianz:9999` | `https://grz73876.live.dynatrace.com/api` | `CF95DSOwRT-RqOzh_Y-_k` |
E1  | Preprod | `https://dt-eag1-e1.srv.allianz:9999`  | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
E1  | Preprod | `https://dt-eag2-e1.srv.allianz:9999`  | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
E2  | Preprod | `https://dt-eag1-e2.srv.allianz:9999`  | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
E2  | Preprod | `https://dt-eag2-e2.srv.allianz:9999`  | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
EC1 | Preprod | `https://dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999` | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
EW3 | Preprod | `https://dt-eag.e2e-mon.ew3.aws.aztec.cloud.allianz:9999` | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
AP1 | Preprod | `https://dt-eag1-ap1.srv.allianz:9999` | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |
AP1 | Preprod | `https://dt-eag2-ap1.srv.allianz:9999` | `https://ily59392.live.dynatrace.com/api` | `_JHfm5hGQgSlkyFPttRyi` |


#### Network Zone

The network zones to be put into the `DT_NETWORK_ZONE` variable are:

| Network Zone                    | Scope                                                              |
|---------------------------------|--------------------------------------------------------------------|
| az.aws.ec1                      | Instances in AWS EC1                                               |
| az.aws.ec1-fcp-ssm              | Instances in AWS EC1 in the FCP Shared Services/Management Network |
| az.aws.ew3                      | Instances in AWS EW3                                               |
| az.aws.ew3-fcp-ssm              | Instances in AWS EW3 in the FCP Shared Services/Management Network |
| az.aws.ase1                     | Instances in AWS ASE1                                              |
| az.aws.ase2                     | Instances in AWS ASE2                                              |
| az.on-prem.e1                   | Instances in E1                                                    |
| az.on-prem.e2                   | Instances in E2                                                    |
| az.on-prem.ap1                  | Instances in AP1                                                   |
| az.on-prem.ap2                  | Instances in AP2                                                   |
| az.on-prem.br1                  | Instances in BR1                                                   |
| az.on-prem.my1                  | Instances in MY1                                                   |
| az.on-prem.lv                   | Instances in LV                                                    |
| az.azure.europe-west            | Instances in Azure West Europe                                     |
| az.azure.france-central         | Instances in Azure France Central                                  |
| az.azure.asia-pacific-southeast | Instances in Azure Southeast Asia                                  |
| az.azure.australia-east         | Instances in Azure Australia East                                  |


If you cannot find your host's zone in the table above, please contact the [global monitoring support](https://github.developer.allianz.io/globalmonitoring/support) to create the appropriate zone.



### Troubleshooting

#### On Allianz OpenShift: Pod is running, but not visible in Dynatrace as a host
**Please note that you should be able to reach the `DT_CONNECTION_POINT` from each OpenShift cluster _without using a proxy_.**

As soon as you see your pod as up and running, the `initContainer` has exited successfully (exit code `0`), ie. it could download and unpack the `PaaS` OneAgent binary.

If your host remains invisible in Dynatrace, first check the `HOST_GROUP_NAME` you provided to the `container specs` and make sure it resembles the name of your oe/team.

In case that the logs on `/opt/dynatrace/oneagent/log` imply that there is a connectivity issue, please check the connectivity from the pod's terminal by executing one of
```bash
curl -k -v -s ${DT_CONNECTION_POINT}/e/grz73876/api/v1/time
curl -k -v -s ${DT_CONNECTION_POINT}/e/ily59392/api/v1/time
```
and check whether a UTC timestamp is returned.
If the `curl` log output indicates that it tries to connect via a proxy, please run one of

```bash
curl -k-v -s -x '' ${DT_CONNECTION_POINT}/e/grz73876/api/v1/time
curl -k-v -s -x '' ${DT_CONNECTION_POINT}/e/ily59392/api/v1/time
```
If this change fixes the issue, this indicates that the domains `.srv.allianz` and/or `.aztec.cloud.allianz` are not on your system-wide `no_proxy` list.

If you still cannot reach the `$DT_CONNECTION_POINT`, although you added `ec1.aws.aztec.cloud.allianz` to the `no_proxy` environment variable, you might need an FCC.