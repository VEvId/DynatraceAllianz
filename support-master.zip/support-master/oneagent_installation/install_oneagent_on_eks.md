## Install OneAgent on Elastic Kubernetes Service (EKS)
The latest and recommended method to deploy the OneAgent is the installation via the Dynatrace Operator.
The Operator will enable the monitoring on any running and future worker node.

The main advantage of the Operator method is that the OneAgents' pods do not need to run in `privileged`.
Nevertheless, the performance/health of the hosts (ie. worker nodes) is fully monitored.

For alternative installation methods, cf. [here](https://www.dynatrace.com/support/help/technology-support/cloud-platforms/kubernetes/other-deployments-and-configurations/kubernetes-deployment-strategies/).
Please note that the AGM team does not provide support for installations different from the Dynatrace Operator.

### Install Dynatrace OneAgent Operator
#### Prerequisites
Clone the [AGM Dynatrace Operator](https://github.developer.allianz.io/globalmonitoring/dynatrace-oneagent-operator) repository to your local machine.
Follow the instructions provided therein.

Do not forget to retrieve the `Api URL` and `bearerToken` of your EKS instance.

#### Deploy OneAgent Operator
The [official documentation](https://www.dynatrace.com/support/help/technology-support/cloud-platforms/kubernetes/deploy-oneagent-k8/) **cannot be applied directly**,
but requires some adjustments (main reason is the missing internet access from EKS).

The [AGM Dynatrace Operator](https://github.developer.allianz.io/globalmonitoring/dynatrace-oneagent-operator) repository you cloned in the previous step contains both the configuration files and a detailed installation instruction.
In summary, these adjustments consist of
- retrieving the `stage`-dependent `DT_PAAS_TOKEN` for creating the `Secret`
- turning on/off the `apparmor` security features in the provided `PodSecurityPolicy` objects
- using the ActiveGate `dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999/e/tenant_id/api` as a proxy to the Dynatrace API URL
- using the ActiveGate `dt-eag.e2e-mon.ec1.aws.aztec.cloud.allianz:9999` as the `DT_CONNECTION_POINT`
- adding the OneAgent installer options
  * `--set-app-log-content-access=true`
  * `--set-host-group=<host_group_name>`
  * `--set-infra-only=true`
- providing the `DT_CUSTOM_PROP` and `DT_TAGS` environments for labelling/tagging the hosts (worker nodes)

If not specified, Log Monitoring will be enabled by default for your Kubernetes environment.
Make sure to set the flag ``--set-app-log-content-access=false`` during installation to disable Log Monitoring.


*AGM - Allianz Global Monitoring*
