# Install OneAgent on an IBM managed FMO Server

1. Access SIM Service Portal (https://aztech.service-now.com/aportal) and click the **Order Something** link.

![snowhc1](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc1.png)

2. Click the **Infrastructure Service** link.

![snowhc2](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc2.png)

3. Click the **Server Services** link.

![snowhc3](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowhc3.png)

4. Click the **Operating System Services** link.

![snowfmo4](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowfmo4.png)

5. Click the **Linux Services** link.

![snowfmo5](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowfmo5.png)

6. Click the **Operational Service Requests** link.

![snowfmo6](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/snowfmo6.png)

7. Select the following items:

- Select **Service Request**: Change value in system configuration (ALZ0337) 
- Select your **server** (You only can select servers you are member of the managing assignment group (Fgroup) of this server)
- Fill the Description field with this information:
````
Add to config of subsystem Dynatrace (OS_independent/filedir.sc/tmp/dynatrace/hosts.txt)
HOSTNAME;ENVIRONMENT;HOSTGROUP;PORT-RANGE;AGENT-VERSION;INSTALLMODE;[HOST-PROPERTY]
Add the Dynatrace subsystem to the hosts and trigger a sysconf update.
````
The config lines has this values:
- HOSTNAME: short name of host, e.g. saf123456
- ENVIRONMENT(Stage): Prod|Preprod|AZDDEV|AZDPROD
- HOSTGROUP: \<any string without blank\>
- PORT-RANGE:50000:50100&nbsp;&nbsp;  # default port is used by watch dog process internally is 50000:50100.In case if this port is used by anyother app you can choose your own 
- AGENT-VERSION:latest &nbsp;&nbsp; # default is latest ,it will choose the latest version from AG , incase if you want to install any other version please choose the version here . eg : `1.197.134.20200723-143315` .
- INSTALLMODE: full|infraonly
- HOST-PROPERTY: optional parameters, syntax: [prop1=value1,prop2=value2,...]

Example:
````
sla24751;Prod;az-af-abssahara-esb;50000:50100;latest;full;[ProfitCenter=B62]
````

![snowfmo7](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/img/SNOW%20SSR.png)

8. Click the **Order Now** link
