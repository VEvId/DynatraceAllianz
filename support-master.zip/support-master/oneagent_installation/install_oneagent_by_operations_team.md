## Dynatrace oneAgent installations guide for Operations team

This guide is for member of the UNIX operations teams (HybridCloud, FMO/IBM). It describes how the ops teams will get the request and how to proceed the request with SYSCONF.

### The request
There are two ways the installation request will come to the ops team:
#### Service Request
- **FMO/IBM:** ALZ0337 (Change value in system configuration)
- **HybridCloud:** Hybrid Cloud - Standard Service Requests / Install Dynatrace Agent

#### Changetask
Inside a change task you will get all informations you need for the Install

#### Properties needed to trigger installation with SYSCONF:
Inside the Request you will find following parameters:
- HOSTNAME: short name of host, e.g. saf123456
- ENVIRONMENT(Stage): Prod|Preprod|AZDDEV|AZDPROD
- HOSTGROUP: \<any string without blank\>
- INSTALLMODE: full|infraonly
- HOST-PROPERTY: optional parameters, syntax: [prop1=value1,prop2=value2,...]
  
  
### Trigger SYSCONF
In SYSCONF you have to do following steps:
#### 1. Check 
Check if the host already has subsystem "dynatrace" with an entry in the hosts.txt (OS_independent/filedir.sc/tmp/dynatrace/hosts.txt).
If the host has dynatrace you have to connect to the host as ````root```` and delete the marker file 
````/opt/dynatrace/.dynatrace_installed.sc````. Only if you remove this file a new installation from SYSCONF will be triggered.

#### 2. Set (new) configuration
Add or update the properties inside the hosts.txt configuration of subsystem "dynatrace".  
Location: OS_independent/filedir.sc/tmp/dynatrace/hosts.txt  
The Syntax is:
````
HOSTNAME:ENVIRONMENT:HOSTGROUP:INSTALLMODE:[HOST-PROPERTY]
````

#### 3. Set subsystem
Add Dynatrace subsystem to the host and trigger a sysconf update. This will start the installation process.

**Remark:** The installation will create a separat volume mounted on ````/opt/dynatrace```` in the ````appl-vg````. If this fails you can try to create a volume manually.


