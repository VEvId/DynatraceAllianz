## Change OneAgent installation to another tenant (manually, `root`/`admin` access required)

#### 1.	Stop agent:
Linux: (as root)
````
service oneagent stop
````
Windows: (as admin)  
````net stop "Dynatrace OneAgent"````, where ````Dynatrace OneAgent```` is the service name for OneAgent.

#### 2. Set new configuration:

Linux: (as root)
````
/opt/dynatrace/oneagent/agent/tools/oneagentctl --set-server=<ActiveGate-URL> --set-tenant=<tenant> --set-tenant-token=<tenant-token>
````
Windows: (as admin)
````
C:\Program Files (x86)\dynatrace\oneagent\agent\tools\oneagentctl.exe --set-server=<ActiveGate-URL> --set-tenant=<tenant> --set-tenant-token=<tenant-token>
````

Choose your nearest ActiveGate:

DC | ActiveGate-URL 
--- | --- 
E1 | ````https://dt-eag2-e1.srv.allianz:9999/communication ````
E2 | ````https://dt-eag2-e2.srv.allianz:9999/communication ````

Choose your system, you want to connect the agent to:

System | tenant | tenant-token
--- | --- | ---
Prod | ````grz73876```` | ````BMpc4Z4dtAVCth40````
PreProd | ````ily59392```` | ````n1MR3m8o6TWP5pUj````

If you also need to switch the ````host group```` please add additional parameter: ````--set-host-group=<new host group>````.

#### 3. Set the networkzone :

Add network zone accoding to your host location

On Linux or AIX:

```command
/opt/dynatrace/oneagent/agent/tools/oneagentctl --set-network-zone=<your.network.zone>
```
On Windows:

```command
%PROGRAMFILES%\dynatrace\oneagent\agent\tools\oneagentctl.exe --set-network-zone=<your.network.zone>
```

Available `NETWORK_ZONES` are

| Network Zone | Scope |
| --- | ---|
|az.aws.ec1 | Instances in AWS EC1 |
|az.aws.ew3 | Instances in AWS EW3 |
|az.aws.ase1 | Instances in AWS ASE1 |
|az.aws.ase2 | Instances in AWS ASE2 |
|az.on-prem.e1 | Instances in E1 |
|az.on-prem.e2 | Instances in E2 |
|az.on-prem.ap1 | Instances in AP1 |
|az.on-prem.br1| Instances in BR1 |
|az.azure.europe-west | Instances in Azure West Europe |
|az.azure.france-central | Instances in Azure France Central |
|az.azure.asia-pacific-southeast | Instances in Azure Southeast Asia  |

If you cannot find your host's zone in the table above, please contact the [global monitoring support](https://github.developer.allianz.io/globalmonitoring/support) to create the appropriate zone.

#### 4. Set the hostgroup :

Host_Groups are sets of hosts which can be configured while installing the agent. Host_Groups are helpful for users to group and configure a set of hosts and its related processes and services. Consider that hosts belong to at most one Host_Group, so there's no overlap between hosts and Host_Groups. The Global Monitoring team has a specific schema for Host_Group selection. For example, you are belongs to the team mz-az-tech-itmp and you have two application RAP and CISL then you can choose host groups az-tech-itmp-rap and az-tech-itmp-cisl while deploying agents.

***Note :*** Our name convention doesn't allow white spaces or hyphens for the applications names, please always use lower case letter for the host group names.

Linux or AIX:

```command
/opt/dynatrace/oneagent/agent/tools/oneagentctl --set-host-group=MyHostGroup

````
Windows:

```command
%PROGRAMFILES%\dynatrace\oneagent\agent\tools\oneagentctl.exe --set-host-group=MyHostGroup

```
#### 5.	Start agent:
Linux: (as root)
````
service oneagent start
````
Windows: (as admin)  
````net start "Dynatrace OneAgent"````, where ````Dynatrace OneAgent```` is the service name for OneAgent.

More details:
https://www.dynatrace.com/support/help/setup-and-configuration/dynatrace-oneagent/oneagent-configuration-via-command-line-interface/
