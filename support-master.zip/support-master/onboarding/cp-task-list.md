


| Task  | Description  | Reponsable  | Status  | Comments |
|---|---|---|---|---|
| 1 | Have a complete list of apps/services from CP  | CP  | :white_check_mark: | Ilya shared our internal list with CP |
| 2 | Prioritize the application list  | CP  |  | One Marketing is one of the priorities of Allianz SE |
| 3 | Identify Service Owners/Ops  | CP  |   |
| 4 | Provide them with instructions to create a ticket in GitHub [**(link)**](https://github.developer.allianz.io/globalmonitoring/support/blob/master/onboarding/onboarding_business_application.md) | GM  | :white_check_mark: |
| 5 | Global monitoring support will walk through the agent installation with root access from service owner [**(link)**](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/README.md) | GM  | In progress |
| 6 | Access Dynatrace [**GUI**](https://rfe60458.live.dynatrace.com) to test if agent is working  | CP/GM  | In progress  |
