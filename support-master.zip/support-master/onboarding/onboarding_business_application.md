## Onboard a business application to AZ Tech E2E Global Monitoring

### Provide application's metadata
Some Metadata of your organization and application are required.
Please follow one of the links to onboard an application running on
[a virtual machine](https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=onboard-a-business-application-running-on-a-vm.md&title=Onboard+business+application+on+VM)
or on
[CRP container platform](https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=onboard-a-business-application-running-on-crp.md&title=Onboard+new+application+to+Global+Monitoring)
to open a new ticket.
