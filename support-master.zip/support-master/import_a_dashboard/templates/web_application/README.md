### Web Application Dashboard


This Dashboard is intended to show performance and usage metrics of a specific Web Application. Big emphasis on the performance from a geolocational perspective.

In order to finish the configuration:
- For most tiles, select the application that you want to monitor
- For the availability, choose a browser monitor
- For custom charts, change the filter to your desire application
- For User Session queries, change the SQL query and choose a different value(name) for 'useraction.application='

<p align="left">
  <img size="100%" src="../../previews/web_application.PNG" width="90%" height="90%" /></div>
</p>
