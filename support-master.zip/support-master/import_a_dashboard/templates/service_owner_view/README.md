### Service Owner View Dashboard #1


This Dashboard is intended to show a high-level view of different applications, let them be web, mobile or custom, from the perspective of a service owner, with higher interest in KPIs.

In order to finish the configuration:
- For each World Map tile, add a different Application
- For each KPI tile, add an application and a KPI of that Application
- For the custom chart above, choose the metric Applications > Web > Action Count (load Action, by browser) and choose to split by Web Application

<p align="left">
  <img size="100%" src="../../previews/service_owner_view.PNG" width="90%" height="90%" /></div>
</p>
