### Citrix Overview Dashboard


This Dashboard is intended to show health and performance metrics of your Citrix environment.

In order to finish the configuration:
- Restrict the overview tiles (host and network health) to the Citrix Management Zone
- Select the RUM Custom Application for Citrix in the 'Custom Application' tile
- The rest of the tiles should be working fine, but feel free to restrict them to the Citrix Management Zone as well
- Alternatively, just restrict the whole dashboard to the Citrix Management Zone

<p align="left">
  <img size="100%" src="../../previews/citrix_overview.PNG" width="90%" height="90%" /></div>
</p>
