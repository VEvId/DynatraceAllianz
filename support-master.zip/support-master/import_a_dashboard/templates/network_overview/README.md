### Network Overview Dashboard


In addition to Dynatrace's out of the box Network view, we can add this dashboard focused on figuring out if your network is fine or if there's some strange behaviour before we get down to detail and troubleshoot. 

In order to finish the configuration:
- Configure the World Map tile to an application (internal applications work better in this case)
- Restrict any tile to a specific Management Zone, or restrict the whole dashboard

<p align="left">
  <img size="100%" src="../../previews/network_overview.PNG" width="90%" height="90%" /></div>
</p>
