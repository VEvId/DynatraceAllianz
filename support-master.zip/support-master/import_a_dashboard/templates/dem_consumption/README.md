### DEM Consumption Dashboard


This dashboard's objective is to give you an estimate of your DEM License consumption over different periods of time to understand how much you are consuming and to get an estimate on how much you could be paying at the end of the month.

The dashboard should be fully functional once imported without further configuration. Remember to set a Management Zone filter and a timeframe filter on the top right corner of the screen to get relevant results.

<p align="left">
  <img size="100%" src="../../previews/dem_consumption.PNG" width="90%" height="90%" /></div>
</p>
