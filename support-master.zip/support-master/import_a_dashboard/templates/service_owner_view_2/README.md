### Service Owner View Dashboard #2


This Dashboard is intended to show a high-level view of different applications, let them be web, mobile or custom, from the perspective of a service owner, with higher interest in user activity.

In order to finish the configuration:
- Restrict the first level tiles to the Management Zone you might be interested in
- For each User Behaviour tile, add a different Application
- For each Custom Chart, choose a different application as a filter

<p align="left">
  <img size="100%" src="../../previews/service_owner_view_2.PNG" width="90%" height="90%" /></div>
</p>
