### Database Overview Dashboard


This Dashboard is intended to show overall health and usage of all databases in a Management Zone. Customizing this dashboard is key to showing only the databases that you might be interested in instead of an overview.

In order to finish the configuration:
- For each database tile below, choose a database of the mentioned technology
- Feel free to clone these database tiles if you need more of them, or remove them if not needed
- Consider also restricting parts of the dashboard to a specific Management Zone

<p align="left">
  <img size="100%" src="../../previews/database_overview.PNG" width="90%" height="90%" /></div>
</p>
