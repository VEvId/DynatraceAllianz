### Java Application Dashboard


This Dashboard is intended to show overall health of a Java Application, along with the services that power it and the most important metrics for Java processes, such as GC time and JVM metrics.

In order to finish the configuration:
- Restrict service health tile to the Management Zone of the application (if available)
- For each service tile, select a service that is used in your Java application
- Feel free to clone tiles to add more services
- For the custom charts, change the filters for the Java Processes of your application

<p align="left">
  <img size="100%" src="../../previews/java_application.PNG" width="90%" height="90%" /></div>
</p>
