### Import a dashboard


Choose one of the templates provided below to import one of our predefined dashboards into your environment. Follow these simple steps:
1. Save the JSON corresponding to one of the dashboard templates below
2. Go to the Dynatrace environment and go to 'Dashboards'
3. Create a new Dashboard
4. On the new Dashboard, click on 'Edit' > 'Settings' > 'Advanced Setting'
5. Go to 'Dashboard JSON', select 'Upload' and choose the JSON file of the dashboard you saved previously

Your dashboard will now be uploaded with a different name - the one on the template. Follow the specific steps for each dashboard listed below to finish configuring it:

- [Service Owner View #1](./templates/service_owner_view/)
- [Service Owner View #2](./templates/service_owner_view_2/)
- [Web Application](./templates/web_application/)
- [Java Application](./templates/java_application/)
- [Database Overview](./templates/database_overview/)
- [Network Overview](./templates/network_overview/)
- [Citrix Overview](./templates/citrix_overview/)
- [DEM Consumption](./templates/dem_consumption/)
