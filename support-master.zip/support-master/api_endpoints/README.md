# **Dynatrace API for the Allianz e2e global monitoring solution**

Dynatrace offers a very powerful API with many endpoints, allowing for the automation of many of the processes usually done in Dynatrace, such as creation of entities and modification of the settings. In order to use this API, you need to be able to identify yourself with an API token. However, permissions for the Dynatrace API token come for the whole tenant, meaning we can't give out a Dynatrace API token to anyone in Allianz, as they would be able to create or modify entities for other customers.

That's why, from the Global Monitoring Team, we have set up an API Gateway in between our customers and the Dynatrace API to make the use of the Dynatrace API possible by restricting calls on specific Management Zones.

## Authentication

In order to authenticate your call to the API, you can set a header in your call that contains the following information:

```sh

apikey: XXXXXXXXXXXXXXXXXXXX

```

## Use valid Certificate

The connection to the Dynatrace API is configured to be as secure as possible, meaning that it goes through HTTPS and uses an Allianz Certificate to validate the requests. However, the Allianz certificate is not issued by a public CA, so we will have to make sure that the Allianz Root CA is passed during the call to the API for the connection to be validated and secured.

For example, if you're connecting from your AVC, your browser should already be configured to use the Allianz Root CA, so it should work by default. However, other tools such as curl will ask for the certificate, which can be provided via the ``--cacert`` parameter. You can follow the instructions described [here](https://curl.haxx.se/docs/sslcerts.html) in order to download the certificate from the browser itself:

>If you use Internet Explorer, this is one way to get extract the CA cert for a particular server:
> - View the certificate by double-clicking the padlock
> - Find out where the CA certificate is kept (Certificate> Authority Information Access>URL)
> - Get a copy of the crt file using curl
> - Convert it from crt to PEM using the openssl tool: openssl x509 -inform DES -in yourdownloaded.crt -out outcert.pem -text
> - Add the 'outcert.pem' to the CA certificate store or use it stand-alone as described below.


## Endpoints

Each single endpoint will need a specific configuration in the backend to be enabled to the public. Here you can find a list of all the endpoints that are available as of now, with their counterpart in the Dynatrace API.

#### **GET entities**

| Tenant | Endpoint URL |
| ----- | ----- |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/entities |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/entities |

Returns a list with all the entities in the environment, given the specific filters. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/entity-v2/get-entities-list/). As specified in the link, the `entitySelector` parameter has to be given with at least one of `entityId` or `type`.

#### **GET all hosts**

| Tenant | Endpoint URL |
| ----- | ----- |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/hosts |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/hosts |

Returns a list with all the hosts in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/hosts-api/get-all/), except for `managementZone` that is disabled.

#### **GET a host**

| Tenant | Endpoint URL |
| ----- | ----- |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/entity/host/{hostId} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/entity/host/{hostId} |

Returns the properties of one specific host. The response will be the same as the one described in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/hosts-api/get-a-host/).

#### **GET all process groups**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/process-groups |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/process-groups |

Returns a list with all the process groups in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/process-groups-api/get-all/), except for `managementZone` that is disabled.

 

#### **GET all processes**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/processes |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/processes |

Returns a list with all the processes in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/processes-api/get-all/), except for `managementZone` that is disabled.

 

#### **GET all services**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/services |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/services    |

Returns a list with all the services in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/services-api/get-all/), except for `managementZone` that is disabled.

 

#### **GET all applications**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/applications |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/applications |

Returns a list with all the applications in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/topology-and-smartscape/applications-api/get-all/), except for `managementZone` that is disabled.

 

#### **GET all synthetic monitors**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/synthetic-monitors |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/synthetic-monitors |

Returns a list with all the synthetic monitors in the environment. All the parameters you can use are the same as listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/synthetic/synthetic-monitors/get-all-monitors/), except for `managementZone` that is disabled.

 

#### **GET a synthetic monitor**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/synthetic/{monitorId} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/synthetic/{monitorId} |

Returns a detailed description of one synthetic monitor. You need to set up the ID of the synthetic monitor in the path of the request and make sure that it's included in your management zone or the request will be refused. The reponse is the same as in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/synthetic/synthetic-monitors/get-a-monitor/).



#### **PUT a synthetic monitor**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/synthetic/{monitorId} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/synthetic/{monitorId} |

Modifies an already existing synthetic monitor. You need to set up the ID of the synthetic monitor in the path of the request and make sure that it's included in your management zone or the request will be refused. The parameters that you can use are the same as in [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/synthetic/synthetic-monitors/put-a-monitor/) and the response will be empty if the call was successful.



#### **POST a custom tag**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/tag |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/tag |

Tags an entity with a defined tag of your choice. This tag is considered a `manual tag` and therefore can be deleted manually as well. The parameters and body that you can use are the same as in [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/custom-tags/post-tags/), but the `entitySelector` is disabled and you need to use the field `entityId` directly inside the body, which has to point to an entity that belongs to your management zone.


#### **GET anomaly detection settings for a Process Group**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/anomalyDetection/processGroup/{id} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/anomalyDetection/processGroup/{id} |

Gets the anomaly detection settings of a Process Group identified by the Process Group ID. The parameters that you can use are the same as in [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/anomaly-detection-api/anomaly-detection-api-process-groups/get-config/). If the call was successful, the response contains the configuration of anomaly detection for the process group with the given ID. 



#### **PUT anomaly detection settings for a Process Group**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/anomalyDetection/processGroup/{id} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/anomalyDetection/processGroup/{id} |

Modifies the anomaly detection settings of a Process Group identified by the Process Group ID, with which we will verify that it is included in your management zone. The parameters that you can use are the same as in [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/anomaly-detection-api/anomaly-detection-api-process-groups/put-config/) and the response will be empty if the call was successful.



#### **GET data points**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/timeseries/data-points/{timeseriesIdentifier} |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/timeseries/data-points/{timeseriesIdentifier} |

Returns a list of data points for the `timeseriesIdentifier` metric, filtered for entities in the Management Zone of the user calling the API. The parameters, how to use them and the reponse is the same as in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/metric-v1/read-data-points/get-data-points/). Please consider using the endpoint for metrics v2 for custom metrics.



#### **GET data points - metrics v2**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/metrics |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/metrics |

Returns data points for a specific metric. You can use these endpoints in two ways.
- By specifing a `metricSelector` parameter in which the metric includes the management zone's name. This would incude custom metrics that are not associated with a management zone except for the name.
- By specifing an `entityId` in the `entitySelector` parameter. This entity has to belong to your management zone.

The parameters, how to use them and the reponse is the same as in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/metric-v2/get-data-points/).

Please check out the example below of a valid request to the Prod Data Point V2 endpoint:

> Let's assume we want to get some data out of the cpu usage metric of a given host.  
> Our parameters to achieve that will look like the following:  
> ```
> metricSelector = builtin:host.cpu.(usage,idle)
> entitySelector = {  
>    "type": "HOST",  
>    "entityId": "HOST-1234567890"  
>  }
>```
> Combining them should result in an endpoint that looks like:  
> `https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/metrics?metricSelector=builtin:host.cpu.(usage,idle)&entitySelector=type("HOST"),entityId("HOST-1234567890")&from=now-5m`
>  
> *NOTE: "&from=now-5m" is just to limit the retrieved data for the past 5 minutes*




#### **GET a User Sessions Query Table**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/usql/table |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/usql/table |

Executes the User Session Query specified in the request returns results as a table structure of the requested columns. Any result given by the Dynatrace API will be restricted to the Management Zone of the user calling the API. The parameters, how to use them and the reponse is the same as in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/user-sessions/table/).


#### **GET problem feed**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/problem/feed |
| Prod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/problem/feed |

Returns a list of all the problems that have been generated in Dynatrace for your specific Management Zone according to the parameters specified in the query. It works the same way as the original [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/problems/problems/get-feed/).


#### **POST an event**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/events |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/events |

Pushes an event into an entity in Dynatrace. The parameters that you can use in the body of the request are the same as the ones listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/events/post-event/). The `attachRules` parameter is disabled and you have to use the parameter `entityId` instead, which accepts values for hosts, process groups, processes, services and applications. It is not supported to push events to entities with a specific tag as of yet.


#### **POST a Maintenance Window**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/maintenanceWindows |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/maintenanceWindows |

Creates a Maintenance Window in Dynatrace. The parameters that you can use in the body of the request are the same as the ones listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/maintenance-windows-api/post-mw/). The `name` parameter is modified with a prefix and you will see it in Dynatrace as:
`<apimw>-<mz_name>-<customer_name>` and the `managementZone` , `mzId` parameters under `scope` are disabled.


> **Example:**  
> If your management zone name is `mz-allianz`, for a given Maintenance Window name: `MaintWindow123` it will create a Maintenance Window called:
>   
> apimw-mz-allianz-MaintWindow123


#### **PUT a Maintenance Window**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/updateMaintenanceWindows/{mwId} |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/updateMaintenanceWindows/{mwId} |

Modifies a Maintenance Window in Dynatrace. The parameters that you can use in the body of the request are the same as the ones listed in the [Dynatrace API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/maintenance-windows-api/put-mw/). The `name` parameter is modified with a prefix and you will see it in Dynatrace as `<apimw>-<mz_name>-<customer_name>` and the `managementZone` , `mzId` parameters under `scope` are disabled.

>**Note:**
> As mentioned above for `POST` the same naming convention will be followed if you alter the name field


#### **GET all Maintenance Windows**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/all/maintenanceWindows |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/all/maintenanceWindows |

Gets all Maintenance Windows from Dynatrace that were created via API calls to the `dt-api` Endpoint.


#### **GET a Maintenance Window by ID**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/maintenanceWindows/{mwId} |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/maintenanceWindows/{mwId} |

Gets a Maintenance Window from Dynatrace by ID.

> **NOTE:** Will retrieve only Maintenance Windows that were created via API calls to the `dt-api` domain.
 

#### **DELETE a Maintenance Window by ID**

| Tenant | Endpoint URL |
| ------ | ------ |
| Preprod | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/preprod/maintenanceWindows/{mwId} |
| Prod    | https://dt-api.e2e-mon.ec1.aws.aztec.cloud.allianz/prod/maintenanceWindows/{mwId} |

Deletes a Maintenance Window from Dynatrace by ID.

> **NOTE:** Will delete only Maintenance Windows that were created via API calls to the `dt-api` domain.

## **F.A.Q.**

 

#### I need a new endpoint, what can I do to get it enabled?

As mentioned above, each endpoint that we want to add needs a minimum of development from our side to be added. If you have a need for an specific endpoint of the Dynatrace API that is not available yet, please let us know in our [support channel](https://github.developer.allianz.io/globalmonitoring/support) by opening an issue and we will take care of it as soon as possible.

 

#### How can I get an API token to use this service?

You can create an issue in our [support channel](https://github.developer.allianz.io/globalmonitoring/support) letting us know that you want an API token and what your management zone is and we will make sure we add one for you.

 

#### I am getting unexpected errors that don't make sense. What can I do to fix them?

We are still running this as a trial and that's why we have mostly enabled endpoints for the preprod tenant, which means that it's not perfect. If you find a problem, bug or incorrect response, please let us know in our [support channel](https://github.developer.allianz.io/globalmonitoring/support) and we will get right into fixing it.
