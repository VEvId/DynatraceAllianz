# Support for the e2e global monitoring platform

<p align="center">
  <img size="50%" src="dynatrace_logo.png" width="40%" height="40%" /></div>
</p>

We are here to learn from your feedback and collaboratively turn our e2e global monitoring into a great service. The Global e2e Monitoring Team loves transparency and customer interaction. That’s why we sat together and created the following principles that our team commits to:

- Timeliness: Dedicated contact person to handle your issue end-2-end.
- Transparency: Daily updates with next steps, no email only communication.
- Closure: Support tickets get solved, rejected or put on roadmap as feature request

<table style="width: 100%">
  <colgroup>
     <col span="1" style="width: 50%;">
     <col span="1" style="width: 50%;">
  </colgroup>
  <tbody>
    <tr>
      <th align="center">End-to-End Monitoring</th>
      <th align="center">Service Availability Monitoring</th>
    </tr>
    <tr>
      <td align="center">Self-Service</td>
      <td align="center">Managed (*)</td>
    </tr>
    <tr>
      <td align="center"><img src="e2e_visibility.png" alt="drawing" width="450"/></td>
      <td align="center"><img src="service_availability.png" alt="drawing" width="450"/></td>
    </tr>
    <tr>
      <td><b>Dynatrace</b> automatically and continuously maps the dependencies of your entire environment, no matter how complex it is. It automatically creates a complete, real-time topology of your digital ecosystem and it will discover all your assets and what is running inside of them, so your topology is always up to date.</td>
      <td><b>Dynatrace</b> Synthetic Monitoring makes it easy for you to monitor the availability and performance of your applications as experienced by your customers around the world and around the clock. Please just share your requirements with us and we would do the rest!</td>
    </tr>
    <tr>
      <td>
        <ul>
          <h3>Predefined requests:</h3>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/blob/master/order_mz_sim.md">Onboard a new business application/team via SIM</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=user+management&template=onboard-additional-users-on-a-specific-management-zone.md&title=Onboard+additional+users">Onboard additional users on a specific Management Zone</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=training&template=onboard-training-users.md&title=Request+a+training">Request for a Training</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=training&template=request-a-webinar-module.md&title=Request+a+webinar+module+">Request for a Webinar</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/blob/master/api_endpoints/README.md#dynatrace-api-for-the-allianz-e2e-global-monitoring-solution">Request an API token for the API Gateway </a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new">Others (pricing, questions, feedback, etc.)</a>
          </li>
          <br>
          <h3>Tenant Global Settings</h3>
           <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/tree/settings-2.0-documentation/settings_2.0.md"> How to properly use the Global Settings section in the Dynatrace tenant</a>
          </li>
          <h3>Global monitoring guides:</h3>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/starter-kit/blob/master/README.md#global-monitoring-starter-kit">Starter kit</a>
          </li>
          <li>
            <a href="./oneagent_installation/README.md">Dynatrace OneAgent installation</a>
          </li>
          <li>
            <a href="./import_a_dashboard/README.md">Import a predefined dashboard</a>
          </li>    
          <li>
            <a href="./api_endpoints/README.md">Dynatrace API gateway usage for  Allianz e2e global monitoring solution</a>
          </li>
          <li>
            <a href="./infra-fullstack.md">Switch from Infrastructure (CIM) to Full Stack (FS) mode</a>
          </li>
          <li>
            <a href="./submanagement-zone-restriction.md">How to define namespace restricted submanagement zones</a>
          </li>   
           <h3>Ingest new metrics:</h3>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/blob/master/prometheus_runbook.md">Prometheus integration</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/tree/master/opentelemetry_runbook">OpenTelemetry integration</a>
          </li>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/tree/master/http_parser_extension_runbook.md">HTTP Parser Extension</a>
          </li>
          </li>          
        </ul>
      </td>
      <td valign="top">
        <ul>
          <li>
            <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=onboard+request&template=request-service-availability-monitor.md&title=Request+a+new+Service+Availability+Monitor">Request a new Service Availability Monitor</a>
          </li>
          <li>
            <a href="https://connect.allianz.com/groups/global-apm-tool/blog/2021/06/28/availability-monitoring-migration-from-grafana-to-dynatrace">Grafana migration Q&A</a>
          </li>
          <li>
            <a href="./service_availability_q&a.md">Q&A</a>
          </li>
        </ul>      
      </td>
    </tr>
  </tbody>
</table>

Please have a look into our evolving [Q&A](./q&a.md). They might cover your question.  

You can also take a look at our [GDPR compliance statement](./gdpr_compliance.md) which can also help you configure your environment to make it GDPR compliant.

And last but not least, stay tuned for more relevant announcements following our [Allianz Connect Web page](https://connect.allianz.com/groups/global-apm-tool)

(*) Global E2E Monitoring also provides consulting and enablement services – from Dynatrace onboarding guidance, KPI/threshold creation, dashboard design, creation of alerts down to other APM-related topics. The regular fee is 540 EUR/PD. If a more in-depth, complex integration is needed then a Dynatrace colleague can be leased to the inquiring team for 1040 EUR/PD. Each PD counts as 8 hours of work




