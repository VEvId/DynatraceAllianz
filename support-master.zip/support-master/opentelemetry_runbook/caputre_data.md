# Configuring how to capture data

Find here a list of the different features of OpenTelemetry that are configurable in Dynatrace.

In this guide you find specified the steps needed to configure each of them. Please keep reading for more details.

## Resource attributes
While Dynatrace automatically captures all OpenTracing and OpenTelemetry resource attributes, to prevent the accidental storage of personal data, only the values of resource attributes for which a related key is specified in the allow-list below are stored. 

Open a <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=general-issue-template.md&title=%5BIssue+short+Description%5D">GitHub issue</a>  specifying the keys of the resource attributes you want to store in Dynatrace.

## Span events attributes
While Dynatrace automatically captures all OpenTracing and OpenTelemetry span event attributes, it only stores span event attribute values when the related keys are specified

Open a  <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=general-issue-template.md&title=%5BIssue+short+Description%5D">GitHub issue</a> specifying the keys of the span event attributes you want to store in Dynatrace.

## Span capturing
All detected OpenTelemetry/OpenTracing spans are captured by default. This means that every detected span is added to PurePath. T

We recommend that you exclude spans for technologies supported out of the box by OneAgent for Java and Go. Define rules to exclude specific spans.

Open a  <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=general-issue-template.md&title=%5BIssue+short+Description%5D">GitHub issue</a> specifying:

**a) Span capture rule name**

**b) Span capture rule action** (ignore/capture)

**c) Matchers**
   
   - Source (Attribute / Instrumentation library name/ Instrumentation library version/ span kind/ Span name) 
    
   - Comparison type (Contains/ Does not contain/ Does not end with/ Does not start with/ Ends with/ Equals/ Starts with)
   
   - Value
   
   - Case sensitive (True/ False)

## Span entry points
OpenTelemetry/OpenTracing spans can start new PurePaths. Define rules that define which spans should not be considered as entry points.

Open a  <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=general-issue-template.md&title=%5BIssue+short+Description%5D">GitHub issue</a> specifying:

**a) Entry point rule name**

**b) Entry point rule action** (Create entry point/ Do not create entry point)

**c) Matchers**
   
   - Source (Attribute / Instrumentation library name/ Instrumentation library version/ span kind/ Span name) 
    
   - Comparison type (Contains/ Does not contain/ Does not end with/ Does not start with/ Ends with/ Equals/ Starts with)
   
   - Value
   
   - Case sensitive (True/ False)

## Span context propagation
Open a  <a href="https://github.developer.allianz.io/globalmonitoring/support/issues/new?assignees=&labels=&template=general-issue-template.md&title=%5BIssue+short+Description%5D">GitHub issue</a> specifying:

**a) Context propagation rule name**

**b) Context propagation rule action** (Propagate/ Do not propagate)

**c) Matchers**
   
   - Source (Attribute / Instrumentation library name/ Instrumentation library version/ span kind/ Span name) 
    
   - Comparison type ( Contains/ Does not contain/ Does not end with/ Does not start with/ Ends with/ Equals/ Starts with)
   
   - Value
   
   - Case sensitive (True/ False)
