# OpenTelemetry Integration

https://www.dynatrace.com/support/help/extend-dynatrace/opentelemetry

## 1. In combination with OneAgent

OneAgent automatically taps into traces exposed via OpenTracing and OpenTelemetry custom- or pre-instrumentation and sends the telemetry data to the Dynatrace platform.

Check the prerequisites for your technology: 

https://www.dynatrace.com/support/help/extend-dynatrace/opentelemetry/opentracing#prerequisites

Dynatrace automatically captures all OpenTracing and OpenTelemetry spans, but you can control and adapt how OpenTelemetry and OpenTracing spans are combined with OneAgent data into PurePath.
  #### 1.1 <a href="./caputre_data.md">Configuring how to capture data</a>
   
  #### 1.2 <a href="./visualize_data.md">Visualizing captured data - span attributes</a>


