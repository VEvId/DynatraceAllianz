# Visualizing captured data

After following the <a href="./a)_configure_how_to_caputre_data.md">Configuring how to capture data</a> guide, you can define **span attributes** to then visualize your data and chart it in dashboards. Find in this guide the steps needed to chart OpenTelemetry data.

## Steps
### 1) Open a GitHub ticket to create a span attribute
Include the key of the span attribute you want to create.
The key is seen in the purepath of the span. 
<p align="left">
  <img size="50%" src= "../images/1-Opentelemetry runbook.png" width="100%" height="100%" /></div>
</p>


Tell us the display name of the metric which stores the value of the span attribute.

How does the logic works? We will create a span attribute -> Request attribute with the span attribute -> Calculated service metric from the request attribute.

**Structure of your GitHub issue request:**
- Span attribute key
- Calculated metric name (If not defined, will be the same as the span attribute key)

### Chart the calculated metric and pin it to a dashboard.
The calculated metric will store the value of the span attribute of your choice.

**a)** Go to the *main menu -> metrics* and find your metric. 

Metric ID = ***calc:service.displayName***
<p align="left">
  <img size="50%" src= "../images/2-Opentelemetry runbook.png" width="100%" height="100%" /></div>
</p>

**b)** Click to "create chart" to access to the Data Explorer feature


**c)** Personalize your chart and pin it to a dashboard

You can split by "service" and then filter by your "serviceID" or "service name" to see the value of that metric for a specific service.
<p align="left">
  <img size="50%" src= "../images/3-Opentelemetry runbook.png" width="100%" height="100%" /></div>
</p>
