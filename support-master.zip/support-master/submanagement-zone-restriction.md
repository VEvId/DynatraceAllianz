# Creating Submanagement Zones for Kubernetes Namespaces

The submanagement zones feature enables you to define management zones via CaC. Those submanagement zones created are contained within the "parent" management zone that has their definition file.

For a more in-depth description of their configuration please check the readme file found inside your management zone repository, under the directory: `sub_management_zones`  

##  How to define Kubernetes-namespace restricted submanagement zones

Once you got familiar with the definition of a submanagement zone, it's just a matter of identifying the rules required to restrict it as you see fit.

For context let's assume we have a main management zone onboarded already, and it includes some Kubernetes cluster:
```
  oe: az-example
  team: blue
  crp_eks_labels:
    - 100-ec1-dev
    - 200-ew3-dev
  crp_aks_labels:
    - 300-ap1-dev
```


### Restrict to a K8s Namespace (for workloads and pods)

Our goal is to get a submanagement zone that displays data **only about the workloads and pods** running on one of the already monitored Kubernetes clusters, but **just from a specific existing namespace**.  

#### Template for K8s namespace restricted submanagement:

```yml
# Replace the following placeholders:
# <submanagement-zone-name>
# <K8s-cluster-name>
# <K8s-namespace-name>

name: <submanagement-zone-name>
entitySelectorBasedRules:
 - enabled: True
   # Restriction on the namespace
   entitySelector: >-
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                   type("KUBERNETES_CLUSTER"),
                   entityName("<K8s-cluster-name>")
                   ),
                   entityName("<K8s-namespace-name>")
   
 - enabled: True
   # Restriction on the workloads
   entitySelector: >- 
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                   type("KUBERNETES_CLUSTER"),
                   entityName("<K8s-cluster-name>")
                   ),
                   entityName("<K8s-namespace-name>")
                   )
 - enabled: True
   # Restriction on the pods
   entitySelector: >- 
                    type(CLOUD_APPLICATION_INSTANCE),
                    fromRelationships.isInstanceOf(
                    type(CLOUD_APPLICATION),
                    toRelationships.isNamespaceofCa(
                    type(CLOUD_APPLICATION_NAMESPACE),
                    toRelationships.isClusterOfNamespace(
                    type("KUBERNETES_CLUSTER"),
                    entityName("<K8s-cluster-name>")
                    ),
                    entityName("<K8s-namespace-name>")
                    )
                    )
```

<details>
    <summary>Click to see example without multiline break! </summary>

For this example let's assume further there is a namespace called `kube-important` into our existing K8s cluster: `200-ew3-dev` and we are interested into restricting our view just to this particular namespace.

To achieve that we simply create a submanagement zone (we named it`important_restrict`) definition as following:
```
name: important_restrict
entitySelectorBasedRules:
 - enabled: True
   entitySelector:
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                      type("KUBERNETES_CLUSTER"),
                      entityName("200-ew3-dev")
                   ),
                   entityName("kube-important")
   
 - enabled: True
   entitySelector:
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                       type(CLOUD_APPLICATION_NAMESPACE),
                       toRelationships.isClusterOfNamespace(
                          type("KUBERNETES_CLUSTER"),
                          entityName("200-ew3-dev")
                       ),
                       entityName("kube-important")
                   )
 - enabled: True
   entitySelector:
                   type(CLOUD_APPLICATION_INSTANCE),
                   fromRelationships.isInstanceOf(
                      type(CLOUD_APPLICATION),
                      toRelationships.isNamespaceofCa(
                          type(CLOUD_APPLICATION_NAMESPACE),
                          toRelationships.isClusterOfNamespace(
                             type("KUBERNETES_CLUSTER"),
                             entityName("200-ew3-dev")
                          ),
                          entityName("kube-important")
                      )
                   )
```
</details>

<details>
    <summary>Click to see example with multiline break! </summary>

## Warning
Notice that in order to use a multiline block scalar `>-` (e.g. for better readability) the indentation has to be the same among all lines of the multiline block: 
```
name: important_restrict
entitySelectorBasedRules:
 - enabled: True
   entitySelector: >-
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                   type("KUBERNETES_CLUSTER"),
                   entityName("200-ew3-dev")
                   ),
                   entityName("kube-important")
   
 - enabled: True
   entitySelector: >- 
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                   type("KUBERNETES_CLUSTER"),
                   entityName("200-ew3-dev")
                   ),
                   entityName("kube-important")
                   )
 - enabled: True
   entitySelector: >- 
                   type(CLOUD_APPLICATION_INSTANCE),
                   fromRelationships.isInstanceOf(
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                   type("KUBERNETES_CLUSTER"),
                   entityName("200-ew3-dev")
                   ),
                   entityName("kube-important")
                   )
                   )
```
</details>


### Restrict to a K8s Namespace (for process groups, services and hosts)

Our goal this time is to get a submanagement zone that displays data **only about the services and hosts** running on one of the already monitored Kubernetes clusters, but **just from a specific existing namespace**.  

#### Template for K8s namespace restricted submanagement:

```yml
# Replace the following placeholders:
# <submanagement-zone-name>
# <K8s-namespace-name>

name: <submanagement-zone-name>
rules:
    - type: PROCESS_GROUP
      enabled: true
      propagationTypes:
        - PROCESS_GROUP_TO_SERVICE                 # To include all services provided by matching process groups.
        - PROCESS_GROUP_TO_HOST                    # To include all underlying hosts of matching process groups.
      conditions:
        - key:
            attribute: PROCESS_GROUP_PREDEFINED_METADATA
            dynamicKey: KUBERNETES_NAMESPACE
            type: PROCESS_PREDEFINED_METADATA_KEY
          comparisonInfo:
            type: STRING
            operator: EQUALS
            value: <K8s-namespace-name>                              
            negate: false
            caseSensitive: true
```

<details>
    <summary>Click to see example! </summary>

For this example let's assume we are interested in a namespace called `kube-primary`.

To achieve that we simply create a submanagement zone (we named it `primary_restrict`) definition as following:
```
name: primary_restrict
rules:
    - type: PROCESS_GROUP
      enabled: true
      propagationTypes:
        - PROCESS_GROUP_TO_SERVICE  
        - PROCESS_GROUP_TO_HOST
      conditions:
        - key:
            attribute: PROCESS_GROUP_PREDEFINED_METADATA
            dynamicKey: KUBERNETES_NAMESPACE
            type: PROCESS_PREDEFINED_METADATA_KEY
          comparisonInfo:
            type: STRING
            operator: EQUALS
            value: kube-primary                            
            negate: false
            caseSensitive: true
```
</details>

#

Once we got the submanagement zone definition into our repository, we should shortly see it, restricted as expected, in Dynatrace.
