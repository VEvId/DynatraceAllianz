# Prometheus Integration

To see Prometheus metrics in Dynatrace the Prometheus extension needs to be configured by the Global Monitoring team.
The extension will push metrics to the Dynatrace API.

## Steps

### Open a Github issue requesting the integration 
Provide the following information in the ticket:

**1) List of names of the metrics with its dimensions**

We can group them in groups of maximum 100 metrics. You can later enable/disable the metric ingestion by group easily. If no metric unit is provided, "count" will be used by default.

**2) Metric interval ingestion**

1 minute is the default value for the frequency of ingestion of the metric.
In case you want less frequency to reduce costs, please specify.

**3) Prometheus endpoint**

Provide the url of the endpoint and a description for the integration. 

**4) Management zone**

Management zone where you want to see the metrics in Dynatrace.

**5) Device display name**

Name your Prometheus device in Dynatrace. If no name is provided the enpoint url will be used by default.

**6) Endpoint authentication (Optional)**

If needed, provide endpoint authentication. 

Authentication types: AWS Authentication, Basic Authentication, Bearer (token) authentication, No Authentication.



### Visualize the metrics in the Dynatrace environment

Once the Prometheus integration is configured, the Prometheus metrics can be found under the Metrics page in Dynatrace. The Prometheus metrics will be named as prometheus.com.dt.metricName

<p align="left">
  <img size="50%" src="images/1-Prometheus runbook.png" width="100%" height="100%" /></div>
</p>

**Access to your Prometheus device  and chart the list of devices:**

In the Metric view, click to "Create chart" or go to custom charts and look for your Prometheus metric.

Split the custom chart by "Prometheus exporter", change the visualization mode to "Table" and pin the chart to your dashboard.

<p align="left">
  <img size="50%" src="images/2-Prometheus runbook.png" width="100%" height="100%" /></div>
</p>

**Prometheus device view:**

*** Save the link to avoid doing all the steps every time
<p align="left">
  <img size="50%" src="images/3-Prometheus runbook.png" width="100%" height="100%" /></div>
</p>




## Costs

Custom metrics pushed to the Dynatrace API consume DDUs:
Each data spends 0.001 DDU.

The following formula is applied to calculate the DDU consumption for a custom metric ingested once per minute:

```

1 metric data point x 60 min x 24 h x 365 days x 0.001 metric weight = 525.6 DDUs per metric/year

525.6 DDU * 0.0029 € = 1.524 € metric/year

```
