# 1. How to switch from Infrastructure to Full Stack mode
## Find Management zone config repository 
 1. Open our GitHub Channel [link ](https://github.developer.allianz.io/globalmonitoring/)
 2. Search for your Management Zone repository name:  
 
       For example, your management zone name is mz-az-tech-xxx then
        click on that repository 
        
 3. In this repository you will find a folder called `oneagent_config`
 
 ![Screen%20Shot%202020-12-11%20at%206.20.53%20PM](https://github.developer.allianz.io/ambikadeviakhil-jayendrannair/Document/blob/master/imginfra/Screen%20Shot%202020-12-11%20at%206.20.53%20PM.png)
 
 4. There, you will see you README.md and default_oneagent_config.yml.template files for your reference.
 
 5. By clicking the ADD button you can create a new file (here you can provide any name with `.yml` extension)
 
 ![Screen%20Shot%202020-12-11%20at%206.24.48%20PM](https://github.developer.allianz.io/ambikadeviakhil-jayendrannair/Document/blob/master/imginfra/Screen%20Shot%202020-12-11%20at%206.24.48%20PM.png)
 
 6. Now you can fill in the content in the file. Required attributes are `discoveredName` ,`monitoringEnabled` and `monitoringMode`
 
 Here is an example:
  
 ```
 
  hosts:
  - host:
        discoveredName: sla002211                      
        monitoringEnabled: true                             
        monitoringMode: FULL_STACK 
        
 ```
                   
   
 
7. If you have multiple servers, please add multiple entries to cover each server.

 Here is an example 
 
  ```
  
   hosts:
   - host:
         discoveredName: sla002211                      
         monitoringEnabled: true                             
         monitoringMode: FULL_STACK 
   - host:
         discoveredName: sla002212                      
         monitoringEnabled: true                             
         monitoringMode: FULL_STACK 
         
  ```

8. Then you can commit the file in the part bottom of the page.

![Screen%20Shot%202020-12-11%20at%206.38.12%20PM](https://github.developer.allianz.io/ambikadeviakhil-jayendrannair/Document/blob/master/imginfra/Screen%20Shot%202020-12-11%20at%206.38.12%20PM.png)


9. After commiting, please go to your log folder and check for errors. In case if you have an error please [report it to us](https://github.developer.allianz.io/globalmonitoring/support/issues/new).

10. In case if you are unable to find `discoveredName` you can find it in Dynatrace.

![creen%20Shot%202020-12-11%20at%207.19.45%20PM](https://github.developer.allianz.io/ambikadeviakhil-jayendrannair/Document/blob/master/imginfra/Screen%20Shot%202020-12-11%20at%207.19.45%20PM.png)


## Note:

If you are not able to complete this process, you can directly contact us to switch from Infrastructure to Full Stack mode.

1. open a new issue in  our [support channel](https://github.developer.allianz.io/globalmonitoring/support/issues/new) 
![Screen%20Shot%202020-12-11%20at%207.16.13%20PM](https://github.developer.allianz.io/ambikadeviakhil-jayendrannair/Document/blob/master/imginfra/Screen%20Shot%202020-12-11%20at%207.16.13%20PM.png).

2. Add relevent information related to your service.

3. Submit the issue.

# 2. How to switch off monitoring .

1. follow the step till `Step : 5` from the previous section .

2. Now you can fill the ,`monitoringEnabled` is false and server name as   `discoveredName` 
  
  Here is an example 
 
  ```
  
   hosts:
   - host:
         discoveredName: sla002211                      
         monitoringEnabled: false                             
   - host:
         discoveredName: sla002212                      
         monitoringEnabled: false    
         
   ```
 
3. Then you can commit the file in the part bottom of the page.
  
