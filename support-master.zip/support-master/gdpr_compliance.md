# Global Monitoring Solution compliance to GDPR
By default, Dynatrace aims to be GDPR compliant. However, as a monitoring solution, sometimes sensitive data might be captured, or Dynatrace can be configured to capture such data, even if by mistake. To avoid those cases, we have compiled here the requirements from our side to make sure that the global tenant is GDPR compliant. However, it will be up to each customer to make sure the data capture they have enabled is GDPR compliant as well.
## Real user Monitoring (RUM) and personal data
#### Global Dynatrace settings
The recording of personal data is acceptable under GDPR as long as the data collection is proportionate. A data controller must:

- Record minimal personal data and process it safely.
- Adhere to obligations that ensure rights, such as the right to information and the right to be forgotten.

When Dynatrace products capture personal data, it’s typically through the use of Real User Monitoring (RUM), also known as User Experience Monitoring (UEM).

In this case, from us at the Global Monitoring Team, we have configured the following settings:
- Mask end-user IP addresses and GPS coordinates
- Mask all IP addresses
- Mask personal data in URIs
- Mask user actions (web-application only)

These settings, together with no extra configuration from your side, will ensure that our global solution is GDPR compliant.

#### User tags
Since user tags are configurable in Dynatrace, it's important that user tags aren't built upon personal data. However, given that these are configured by each customer, it's up to the customer to make sure they are not capturing personal data in them.

#### HTTP headers
This configuration is, again, up to each customer, but we should make sure that, for each individual application, we disable the ``Ignore do not track HTTP headers``. This will allow users to not be tracked if they desire so. You can modify this setting on the ``Advanced Setup`` section of an application's setting.

#### User Notification
One last best practice when it comes to capturing RUM data is to inform the user that we are capturing their data, even if in compliance to GDPR. We recommend to collect the ways that we might be capturing their data in the form of a Privacy Notice in our web or mobile application when RUM is active.

## Log Analytics

RUM and Log Analytics may capture personal data in unplanned situations. For example, personal data may be included in a stack trace, crash dump, or error log. In such situations, personal data is collected solely to provide high-quality service and performance monitoring. We can, in any case, choose to mask specific log data as described [here](https://www.dynatrace.com/support/help/how-to-use-dynatrace/log-monitoring/configuration/mask-sensitive-information-in-log-analytics/).

## Unintended data collection
As mentioned above, through improper implementation or configuration, it's possible that a web application may perform unintended data collection. It is the responsibility of the customer to make sure their applications are correctly configured to not capture personal data, as described above.

## Extra information

From the Global Monitoring team we have followed through to ensure GDPR compliance from our side, following these [instructions](https://www.dynatrace.com/support/help/how-to-use-dynatrace/data-privacy-and-security/configuration/configure-global-privacy-settings/) considered best practices by Dynatrace.

If you want to know more about data masking in Dynarace and what you can do to configure more data masking, please read the following (Dynarace help page)[https://www.dynatrace.com/support/help/how-to-use-dynatrace/data-privacy-and-security/data-privacy/personal-data-captured-by-dynatrace/]

For more information on this, check out Dynatrace's blog, [Dynatrace compliance with General Data Protection Regulation for EU citizens](https://www.dynatrace.com/news/blog/dynatrace-compliance-general-data-protection-regulation-eu-citizens/).
