
# HTTP Parser Extension

To push metrics from an HTTP endpoint to Dynatrace and then see them in your tenant, you need the HTTP Parser Extension. 
This extension needs to be configured by the Global Monitoring team.


## Steps

### Open a Github issue requesting the integration 
Provide the following information in the ticket:

**1) HTTP Endpoint url**

**2) Variables you want to extract from the endpoint response**

Specify the keys of the values that you want to extract from the JSON file.
If further navigation in the JSON object to lower levels is needed, please indicate so.

**3) Authentication**

Provide the authentication method if needed.
 
**4) Tenant and Management zone**

Tenant (Prod or pre-prod) and Management zone where you want to see the metrics in Dynatrace.



### Visualize the metrics in the Dynatrace environment

Once the HTTP Parser extension is configured, the metrics can be found under the Metrics page in Dynatrace. This metrics will be named as custom.mz_name.metric_name


**Chart your metric and pin it to a dashboard**

In the Metric view, click to "Create chart" or go to custom charts and look for your metric.

You can pin the chart to your dashboard.
<p align="left">
  <img size="50%" src="images/1-HTTP_parser_runbook.png" width="100%" height="100%" /></div>
</p>

## Alerting

You can use these metrics to create custom events for alerting and then integrate the problem notifications with third party services such as email, SNOW and XMatters between others.
Custom events for alerting need to be created in your CaC repository under the custom_events directory.
## Costs

Custom metrics pushed to the Dynatrace API consume DDUs:
In the case of the HTTP Parser Extension, metrics are pushed every minute.
Each metric data point consumes 0.001 DDU.

The following formula is applied to calculate the DDU consumption for a custom metric ingested once per minute:

```

1 metric data point x 60 min x 24 h x 365 days x 0.001 metric weight = 525.6 DDUs per metric/year

525.6 DDU * 0.0029 € = 1.524 € metric/year

```
