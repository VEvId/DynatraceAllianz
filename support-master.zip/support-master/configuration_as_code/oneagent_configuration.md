

#### Getting the id from Dynatrace Web UI
To find the correct ID of your host based on the ones in the output ERROR message, Go to _Dynatrace > Hosts_ and find the desired host, click on the name, and in your browser where you see the URL of the Dynatrace environment look for the following pattern and copy+paste the corresponding one in the configuration file: 

![host_id](images/oneagent_host_id.JPG)  
