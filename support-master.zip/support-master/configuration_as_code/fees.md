## Additional Fees 

Due to their costs evolving from additional infrastructure requirements as well as the  individual development effort, 
some entities that can be configured by the CaC repository imply additional fees that reflect those costs.



### Sub Management Zones

Each sub management zone defined in the CaC repository is charged with a monthly fee of _10.0€_.

This fee is independent of the size of the sub management zone and charged for each calendar-month in which the zone exists.