
# Credentials Submission

This page describes the process of how to submit credentials (such as tokens, passwords) for your Dynatrace configuration in a 
secure manner.

Please *never* commit any credentials in plain, unencrypted form. Those will not be regarded in the configuration as code process!

   
  * [Workflow in a Nutshell](#workflow-in-a-nutshell)
  * [Instructions](#instructions)
     * [Preparation of Credentials and Usage in Configuration Files](#preparation-of-credentials-and-usage-in-configuration-files)
        * [Naming of Keys](#naming-of-keys)
        * [Encryption and Commit](#encryption-and-commit)
        * [Insertion into Configuration File](#insertion-into-configuration-file)
        * [Check](#check)
     * [Encryption Variant I: Using the Webservice](#encryption-variant-i-using-the-webservice)
        * [Step 1: Encryption of plain yaml content](#step-1-encryption-of-plain-yaml-content)
        * [Step 2: Commit and Push to Repository](#step-2-commit-and-push-to-repository)
     * [Encryption Variant II: Using local tools (Here: OpenSSL)](#encryption-variant-ii-using-local-tools-here-openssl)
        * [Step 1: Download and verify certificate](#step-1-download-and-verify-certificate)
        * [Step 2: Encrypt](#step-2-encrypt)
        * [Step 3: Commit and Push](#step-3-commit-and-push)


## Workflow in a Nutshell

The credentials submission can be done as follows:
- Any credentials (passwords, tokens, urls that contain tokens) are stored in one or several encrypte files in the `credentials/` subdirectory
of your configuration repository.
- On your machine, you prepare one or several files in YAML syntax that contain your credentials.
- In order to encrypt those files, a public key is provided that must be used to encrypt your plain yaml-files in a [`CMS` / `S/MIME`](https://tools.ietf.org/html/rfc5652) (details follow).
In order to simplify this, a Webservice is provided. You may as well use your own local tools if you prefer to do so, of course.
_In either way, the encryption takes place locally on your machine!_
- You may use the encrypted credentials by referring to them in your normal configuration file using their yaml keys.
- You can use any credential in arbitrarily many configurations, if necessary. Once you've pushed and not deleted a (encrypted) credentials
file, you do _not_ have to update those any time you change your configurations.

## Instructions

### Preparation of Credentials and Usage in Configuration Files

A credential file in plain form is a yaml file in simple key:value structure. You can store one or several credentials in each file.

Let us assume, for example, that there are credentials `A` with value `xyz` and `B` with value `1-2-3`. Then your prepared yaml file may look
like
````yaml
key_A: "xyz"
key_B: "1-2-3"
````

Alternatively, you may as well create two separate files (each containing one of the lines from above).


#### Encryption and Commit

With your plain file(s) prepared, you may encrypt those using one of the methods described in the following. Either way, you will an
encrypted cypher text of the form
````
-----BEGIN PKCS7-----
MIIDIQYJKoZIhvcNAQcDoIIDEjCCAw4CAQAxggK3MIICswIBADCBmjCBgTELMAkG
[...]
nKAiBCA7gC0AkfUl2feLsQex718Vpc7iu2fT0V178MiX1P+AvA==
-----END PKCS7-----
````

You may then put this cyphertext into a file (of arbitrary name und suffix), e.g., `notification_credentials.p7m`, and 
commit this file into the `credentials/` folder of your repository.

_Note_: If you have used several plain-text yaml files, you must put the cypher text of those into different files, too!

#### Insertion into Configuration File

In order to use the provided credentials in you configurations, you must reference their keys in the form
````
"{{ <KEY_NAME }}"
````
In our example, a configuration `.yml` could contain the line
````YAML
...
password: "{{ key_A }}"
...
````
Consequently, Dynatrace will receive the value `xyz` as `password`.

_Important_: The quotes surrounding the curly braces are mandatory!

#### Naming of Keys

##### Restrictions:
- The keys of the credentials must not contain any special characters (except `_` and `-`) nor white spaces. 
- Keys must be **unique among _all_** the credential files that you provide.

Other than that, keys can be chosen arbitrarily.

Also, keys may be re-used/shared among several configurations.

##### Example:
Assume you want to set up three Jira notifications,
two of which belong to the same account with "passwordA" as password,
and the third belonging to a different account with password "passwordB".

Your credentials file (before encryption!) may look like
````YAML
...
jira_password_primary: passwordA
jira_password_secondary: passwordB
...
````
(you may as well choose to put those into 2 separate files).
Now the two notification configurations corresponding to the first account both contain the line
````YAML
...
password: "{{ jira_password_primary }}"
...
````
while the third notification will contain 
````YAML
...
password: "{{ jira_password_secondary }}"
...
````




#### Check

You may check the log files in your repository (`log/`) whether the submission was successful. 
In particular, the logs reveal any
keys of credentials that have been submitted (see also example later on).

_Note:_ It is _not_ possible for you to restore the encrypted credentials fromn the encrypted files! Also, we
recommend the usage of descriptive keys that reveal which type of credentials have been stored.


### Encryption Variant I: Using the Webservice

The most-likely most convenient way in order to encrypt your plain-text credentials, is usinng our webservice.

It can be reached at
[https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz](https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz).

_Note_: Although this is a web-application, all encryption takes place on your local machine/in your browser and no credentials
are sent to any remote machine!

The workflow is as follows:


#### Step 1: Encryption of plain yaml content

Go to [https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz](https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz) (in the Allianz network!).

Here, please ensure that the connection is via `https` and your browser has verified the page's certificate as authorized by the Allianz:

![credentials_step1_1](images/credentials_step1_1.jpg)

On the page, you find at the top the input mask to fill in your plain yaml text (you may just copy the code or, alternatively, select a local file to do so):

![credentials_step1_2](images/credentials_step1_2.jpg)

After clicking `encrypt`you receive the encrypted cypher text that you can either save on your machine as a file or just directly copy to your clipboard.

![credentials_step1_3](images/credentials_step1_3.jpg)


#### Step 2: Commit and Push to Repository

You can copy the obtained cypher text into any file (except `readme.md`) into your `credentials/` folder:
![credentials_step2_1](images/credentials_step2_1.jpg)

After that, you may use the key in your configurations:
![credentials_step2_2](images/credentials_step2_2.jpg)

You may check the credentails that are available in your repository by revising the log files in your `log/` subfolder:
![credentials_step2_3](images/credentials_step2_3.jpg)



### Encryption Variant II: Using local tools (Here: OpenSSL)

If you do not want to perform the encryption in your browser, you may as well use any local tools. 

Using  `openssl`, this can be done as follows:


#### Step 1: Download and verify certificate

You can download the certificate for encryption in the Allianz network in several formats:
````
https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz/prod-globalmonitoring-cac.der
https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz/prod-globalmonitoring-cac.p7b
https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz/prod-globalmonitoring-cac_base64.cer
````

In anyway, you should verify the certificate's signature from Allianz Infrastructure CA V / Allianz Root CA III . You may do so via:
````bash
# Obtain certificate
curl -s https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz/prod-globalmonitoring-cac_base64.cer > prod-globalmonitoring-cac_base64.cer
# Obtain  Allianz root and intermediate certificates
curl -s https://rootca.allianz.com/download/rootca3_base64.cer > rootca3_base64.cer
curl -s https://rootca.allianz.com/download/infraca5V_base64.cer > infraca5V_base64.cer
# Use OpenSSL for verifiation
openssl verify -CAfile rootca3_base64.cer -untrusted infraca5V_base64.cer prod-globalmonitoring-cac_base64.cer
````



#### Step 2: Encrypt

Assuming your plain-text yaml file is `file.yml` you can then encrypt it via

````bash 
openssl smime -encrypt -in file.yml -aes256 -out file.p7m -outform pem prod-globalmonitoring-cac_base64.cer 
````

_Note_: The output file must be in `PEM` format, with the cypher text enclosed by `-----BEGIN PKCS7-----` and `-----END PKCS7-----`.


#### Step 3: Commit and Push

You may then commit the encrypted file (in the example above `file.p7m`)  as in variant I above.
