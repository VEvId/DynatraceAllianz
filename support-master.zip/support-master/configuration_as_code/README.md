# Dynatrace Configuration as Code

Each team in a single-tenant Dynatrace environments may set up their own settings via a Git repository that is created during the onboarding process.

The repository URL is
````
https://github.developer.allianz.io/globalmonitoring/<STAGE>-<ManagementZone>
````
Admin users of the team obtain writing access during the onboarding.

Currently, this repository allows the configuration of (in alphabetical order)
- Alerting Profiles
- Auto Tags
- AWS Integration Profiles
- Azure Subscription Monitoring
- External Services
- Kubernetes Cluster Monitoring
- Maintenance Windows
- Notifications
- OneAgent Lifecycle
- Remote Environment
- Synthetic Monitors

with more Dynatrace settings to follow soon.

## Basic Usage

Whenever a user pushes updated configuration files to the repository, a webhook-triggered application
will synchronize the according settings with Dynatrace.

For a more detailed description of this process, please have a look at the `README.md` file in your repository's 
root directory.

## Submission of Credentials

In order to allow for the submission of credentials, such as access tokens for third-party applications, you may provide those in
an encrypted manner.

*Very important: Please do never commit any unencrypted credentials in plain form to your configuration repository!*

In order to simplify this process, a web service that performs the encryption client-side on your machine is accessible 
at [https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz](https://cac.e2e-mon.ec1.aws.aztec.cloud.allianz). 

*Detailed usage instructions can be found [here](credentials_submission.md)!*

## Specific Documentation

- [AWS Integration](aws_integration.md)
- [Azure Integration](azure_integration.md)
- [OneAgent Configuration](oneagent_configuration.md)
- [Settings Objects](./settings_objects)
- [Synthetic Monitors](synthetic_monitors.md)

## General HowTos

- [How to give AutoTags to Kubernetes Namespaces or add the to Sub Management Zones](howtos/get_kubernetes_namespace_selectors.md)
