## Monitoring Service-Level Objects (SLO)

### Schema Id `builtin:monitoring.slo`

### Schema Definition
See [dynatrace_schemas/builtin:monitoring.slo-5.0.6.json](dynatrace_schemas/builtin:monitoring.slo-5.0.6.json).

### Allowed Scopes `environment`

**Important**: Since monitoring SLOs are defined on a tenant-wide scope (`environment`), it is *required* to provide a
valid filter expression (in form of a [Dynatrace entity selector](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/entity-v2/entity-selector/)).
The simplest such filter is a reduction to a certain entity type (e.g. `filter: type(HOST)`). Metric expressions that do 
not allow such filtering cannot be supported at this moment.

Furthermore, a valid name without any hyphens is required.

### Value Syntax:
````yaml
value:
  enabled:                     # BOOLEAN (Optional)          Default 'True'.
  name:                        # STRING                      Must not contain any hyphen.
  customDescription:           # STRING                      
  metricExpression:            # STRING (Optional)           Default ''.
  evaluationType:              # ENUM (Optional)             Must be one of ["AGGREGATE"]. Default 'AGGREGATE'.
  filter:                      # STRING                      
  targetSuccess:               # FLOAT (Optional)            Default '99.98'.
  targetWarning:               # FLOAT (Optional)            Default '99.99'.
  evaluationWindow:            # STRING (Optional)           Default '-1w'.

````

