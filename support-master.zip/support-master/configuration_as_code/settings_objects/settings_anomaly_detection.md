# Anomaly Detection

Anomaly detection settings can be put via CaC for different entity types (e.g. Service) on different levels (e.g. for a particular Service or for all Services
in a Host Group). The entity type that the setting is configured for determines the schema id, the level is then determined by the setting's scope.

Please note that the list of supported entity types will be extended gradually depending on Dynatrace updating the corresponding
API capabilities.

## Anomaly Detection for Services

### Schema Id  `builtin:anomaly-detection.services`

### Schema Definition
See [dynatrace_schemas/builtin:anomaly-detection.services-0.0.14.json](dynatrace_schemas/builtin:anomaly-detection.services-0.0.14.json).

### Allowed Scopes `SERVICE`, `SERVICE_METHOD`, `HOST_GROUP`

### Value Syntax

````yaml
value:
  responseTime:
    enabled:                                      # BOOLEAN (Optional)          Default 'True'.
    detectionMode:                                # ENUM (Optional)             Must be one of ["auto", "fixed"]. Default 'auto'. Requires enabled = 'True'.
    autoDetection:                                #                             Requires enabled = 'True' and detectionMode = 'auto'.
      responseTimeAll:                            #                             Alert if the average response time of all requests degrades beyond **both** the absolute and relative thresholds.
        degradationMilliseconds:                  # FLOAT (Optional)            Default '100.0'.
        degradationPercent:                       # FLOAT (Optional)            Default '50.0'.
      responseTimeSlowest:                        #                             Alert if the average response time of the slowest 10% of requests degrades beyond **both** the absolute and relative thresholds.
        slowestDegradationMilliseconds:           # FLOAT (Optional)            Default '1000.0'.
        slowestDegradationPercent:                # FLOAT (Optional)            Default '100.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
    fixedDetection:                               #                             Requires enabled = 'True' and detectionMode = 'fixed'.
      responseTimeAll:                            #                             Alert if the average response time of all requests degrades beyond this threshold.
        degradationMilliseconds:                  # FLOAT (Optional)            Default '100.0'.
      responseTimeSlowest:                        #                             Alert if the average response time of the slowest 10% of requests degrades beyond this threshold.
        slowestDegradationMilliseconds:           # FLOAT (Optional)            Default '1000.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
      sensitivity:                                # ENUM (Optional)             Must be one of ["low", "medium", "high"]. Default 'low'.
  failureRate:
    enabled:                                      # BOOLEAN (Optional)          Default 'True'.
    detectionMode:                                # ENUM (Optional)             Must be one of ["auto", "fixed"]. Default 'auto'. Requires enabled = 'True'.
    autoDetection:                                #                             Alert if the percentage of failing service calls increases by **both** the absolute and relative thresholds.Requires enabled = 'True' and detectionMode = 'auto'.
      absoluteIncrease:                           # FLOAT (Optional)            Default '0.0'.
      relativeIncrease:                           # FLOAT (Optional)            Default '50.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
    fixedDetection:                               #                             Alert if a given failure rate is exceeded during any 5-minute-period.Requires enabled = 'True' and detectionMode = 'fixed'.
      threshold:                                  # FLOAT (Optional)            Default '0.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
      sensitivity:                                # ENUM (Optional)             Must be one of ["low", "medium", "high"]. Default 'low'.
  loadDrops:                                      #                             Alert if the observed load is lower than the expected load by a specified margin for a specified amount of time.
    enabled:                                      # BOOLEAN (Optional)          Default 'False'.
    loadDropPercent:                              # FLOAT (Optional)            Default '50.0'. Requires enabled = 'True'.
    minutesAbnormalState:                         # INTEGER (Optional)          Default '1'. Requires enabled = 'True'.
  loadSpikes:                                     #                             Alert if the observed load exceeds the expected load by a specified margin for a specified amount of time.
    enabled:                                      # BOOLEAN (Optional)          Default 'False'.
    loadSpikePercent:                             # FLOAT (Optional)            Default '200.0'. Requires enabled = 'True'.
    minutesAbnormalState:                         # INTEGER (Optional)          Default '1'. Requires enabled = 'True'.

````

## Anomaly Detection for Databases

### Schema Id  `builtin:anomaly-detection.databases`

### Schema Definition
See [dynatrace_schemas/builtin:anomaly-detection.databases-0.0.14.json](dynatrace_schemas/builtin:anomaly-detection.databases-0.0.14.json).

### Allowed Scopes `SERVICE`, `SERVICE_METHOD`, `HOST_GROUP`

### Value Syntax

````yaml
value:
  responseTime:
    enabled:                                      # BOOLEAN (Optional)          Default 'True'.
    detectionMode:                                # ENUM (Optional)             Must be one of ["auto", "fixed"]. Default 'auto'. Requires enabled = 'True'.
    autoDetection:                                #                             Requires enabled = 'True' and detectionMode = 'auto'.
      responseTimeAll:                            #                             Alert if the average response time of all requests degrades beyond **both** the absolute and relative thresholds.
        degradationMilliseconds:                  # FLOAT (Optional)            Default '5.0'.
        degradationPercent:                       # FLOAT (Optional)            Default '50.0'.
      responseTimeSlowest:                        #                             Alert if the average response time of the slowest 10% of requests degrades beyond **both** the absolute and relative thresholds.
        slowestDegradationMilliseconds:           # FLOAT (Optional)            Default '20.0'.
        slowestDegradationPercent:                # FLOAT (Optional)            Default '100.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
    fixedDetection:                               #                             Requires enabled = 'True' and detectionMode = 'fixed'.
      responseTimeAll:                            #                             Alert if the average response time of all requests degrades beyond this threshold within an observation period of 5 minutes.
        degradationMilliseconds:                  # FLOAT (Optional)            Default '5.0'.
      responseTimeSlowest:                        #                             Alert if the average response time of the slowest 10% of requests degrades beyond this threshold within an observation period of 5 minutes.
        slowestDegradationMilliseconds:           # FLOAT (Optional)            Default '20.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
      sensitivity:                                # ENUM (Optional)             Must be one of ["low", "medium", "high"]. Default 'low'.
  failureRate:
    enabled:                                      # BOOLEAN (Optional)          Default 'True'.
    detectionMode:                                # ENUM (Optional)             Must be one of ["auto", "fixed"]. Default 'auto'. Requires enabled = 'True'.
    autoDetection:                                #                             Alert if the percentage of failing service calls increases by **both** the absolute and relative thresholds.Requires enabled = 'True' and detectionMode = 'auto'.
      absoluteIncrease:                           # FLOAT (Optional)            Default '0.0'.
      relativeIncrease:                           # FLOAT (Optional)            Default '50.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
    fixedDetection:                               #                             Alert if a given failure rate is exceeded during any 5-minute-period.Requires enabled = 'True' and detectionMode = 'fixed'.
      threshold:                                  # FLOAT (Optional)            Default '0.0'.
      overAlertingProtection:
        requestsPerMinute:                        # FLOAT (Optional)            Default '10.0'.
        minutesAbnormalState:                     # INTEGER (Optional)          Default '1'.
      sensitivity:                                # ENUM (Optional)             Must be one of ["low", "medium", "high"]. Default 'low'.
  loadDrops:                                      #                             Alert if the observed load is lower than the expected load by a specified margin for a specified amount of time.
    enabled:                                      # BOOLEAN (Optional)          Default 'False'.
    loadDropPercent:                              # FLOAT (Optional)            Default '50.0'. Requires enabled = 'True'.
    minutesAbnormalState:                         # INTEGER (Optional)          Default '1'. Requires enabled = 'True'.
  loadSpikes:                                     #                             Alert if the observed load exceeds the expected load by a specified margin for a specified amount of time.
    enabled:                                      # BOOLEAN (Optional)          Default 'False'.
    loadSpikePercent:                             # FLOAT (Optional)            Default '200.0'. Requires enabled = 'True'.
    minutesAbnormalState:                         # INTEGER (Optional)          Default '1'. Requires enabled = 'True'.
  databaseConnections:                            #                             Alert if the number of failed database connects within the specified time exceeds the specified absolute threshold.
    enabled:                                      # BOOLEAN (Optional)          Default 'True'.
    maxFailedConnects:                            # INTEGER (Optional)          Default '5'. Requires enabled = 'True'.
    timePeriod:                                   # INTEGER (Optional)          Default '5'. Requires enabled = 'True'.

````

