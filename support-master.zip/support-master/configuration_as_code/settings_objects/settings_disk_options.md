## Disk Options

### Schema Id `builtin:disk.options`

### Schema Definition
See [dynatrace_schemas/builtin:disk.options-1.2.1.json](dynatrace_schemas/builtin:disk.options-1.2.1.json).

### Allowed Scopes `HOST`, `HOST_GROUP`

### Value Syntax:
````yaml
value:
  nfsShowAll:                   # BOOLEAN
  exclusions:                   # List<Object>
    - os:                       # STRING      The OS type, must be one of "OS_TYPE_UNKNOWN", "OS_TYPE_AIX", "OS_TYPE_DARWIN", "OS_TYPE_HPUX", "OS_TYPE_LINUX", "OS_TYPE_SOLARIS", "OS_TYPE_WINDOWS", "OS_TYPE_ZOS"
      mountpoint:               # STRING      Disk or mount point name.
      filesystem:               # STRING      The file system.
````

