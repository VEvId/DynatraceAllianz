## Settings Objects

The `settings` subdirectory of a Management Zone's configuration repository enables to configure so-called `Settings Objects` in Dynatrace.
With expected growing support by Dynatrace, this allows to systematically configure various settings of entities in Dynatrace that otherwise can only be configured via the
Dynatrace UI in the respective entities' settings menus.

You can provide definitions for schema objects exactly as you would do for the [Dynatrace v2 Settings Api](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/settings/objects/post-object/), in either `json` or `yaml` format.

In general, a setting object definition is first characterized by its `scope`, which e.g. is a Host, a Service, or might be even the whole environment,
and a `schema id`, which defines the type of setting to be configured, such as a "Windows Service Monitoring Setting".

The precise schema syntax depends on the schema id as well as the schema version. Since those definitions are only accessible
via the Dynatrace API that requires tenant-wide access, the definitions of the schema ids and versions provided by our
CaC approach are provided here in [the `dynatrace_schemas` subdirectory](./dynatrace_schemas).


## File Structure of the `settings` Configuration Directory
Since settings of entities can be categorized in various ways (e.g. by scope, by schema id, ...), there are almost no
constraints on the file structure inside the `/settings` directory in the Management Zone configuration repository.
Thus,
- Every file ending with `.yml` or `.json` (for Yaml or Json format, respectively) will be considered a configuration file.
- Every file can contain either a single settings object payload or a list of settings object payloads, which can be of arbitrary composition (e.g. mixing schema ids or scopes is allowed).
- A subfolder structure is allowed (except for hidden folders starting with `.`), i.e. you may categorize your settings in an arbitrary subfolder structure.


## Generic Syntax Schema

As specified by the  [Dynatrace v2 Settings Api](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/settings/objects/post-object/),
every settings object must at least provide the following attributes:
```yaml
schemaId:     # STRING  The schemaID, i.e. the type of setting to be specified. See below for supported schema IDs.
scope:        # STRING  The scope the setting is intended for; this must be either the entity id of the entity of interest or "environment"
value:        # OBJECT  Payload of the schema-id-specific setting configuration. Cf. the Dynatrace documentation as well as the templates for details.
```

## Scope Restrictions

Of course, you may only configure settings that affect (directly or indirectly) entities of your Management Zone. Specifying a
setting for an entity not in your Management Zone will consequently be rejected.

If in the future, settings in the "environment" scope are allowed, their payload will be checked and possibly adapted to the  resulting
configuration that only affects your Management Zone.

Finally, if an entity is contained in multiple Management Zones (e.g. in both Team and OE level), only _one_ Management Zone repository
of the containing Management Zones may specify settings for this entity. If you try to configure settings for an entity that already
has settings from another Management Zone, you will be notified by an error. The responsible Management Zone can furthermore be seen
by the value of the `cac_settings_mz` tag of the concerned entity.

## Templates
Of course, we provide templates for each supported schema id. You find those in the `settings/templates/` subdirectory
in your Management Zone's configuration repository.

## Currently Supported Schema IDs:

Be aware that the settings objects API of Dynatrace is still an early adopter feature. We will extend and update
the list of the supported schema ids successively.

- [Anomaly Detection](settings_anomaly_detection.md)
- [Disk Options](settings_disk_options.md)
- [Monitoring SLO](settings_monitoring_slo.md)
- [Windows Monitoring Services](settings_windows_monitoring_services.md)



<!--- end mz config readme -->
