## Windows Monitoring Services

### Schema Id `builtin:os.services.monitoring`

### Schema Definition
See [dynatrace_schemas/builtin:os.services.monitoring-0.0.8.json](dynatrace_schemas/builtin:os.services.monitoring-0.0.8.json).

### Allowed Scopes `HOST`, `HOST_GROUP`  

### Value syntax:

````yaml
value:
  enabled:              # BOOLEAN   Whether the setting is enabled.
  serviceName:          # STRING   Name of the service in Windows.
  displayName:          # STRING   Name of the service to be displayed in Dynatrace.
````

