# HowTo: Get K8s Namespace Selectors

This document describes how entity selectors can be used to work with Kubernetes Namespaces. 

## Use Cases
- Tag entities of a certain Kubernetes Namespace.
- Create Management Zone rules based on entity selectors (for entities that cannot be tagged).
- Create Sub Management Zones to provide access restricted to a K8s namespace.


## Entity Selector

### Requirements
You need the following information:
- The `Kubernetes Cluster Name`  or the `Kubernetes Cluster Id`
- The `Namespace Name` (as in Kubernetes).


### Selector

Selectors for kubernetes namespaces and workloads/Pods can be built in a hierarchical manner 
starting with selectors for their underlying K8s clusters. The selector for the namespace then uses the cluster selector, while
a selector for workloads uses the namespace selector.

Hence, in the following we build the selectors one after another, using placeholders in a shell-variable style `$PLACEHOLDER`
whenever a previous selector is uses (of course, this is only for the sake of clarity in this documentation - in you configurations, you _cannot_ use 
those placeholders must inject the actual values!)

#### Kubernetes Cluster Selector

First, you will need a selector for the Kubernetes cluster containing the namespace. This can be done either via the cluster's
name as shown in Dynatrace:

```
type("KUBERNETES_CLUSTER"),entityName("k8s-mz-az-tech-team-my_eks-cluster")
```

or 

```
entityId("KUBERNETES_CLUSTER-C000000000000001")
```

(injecting the correct name or id, respectively, of course).

#### Namespace Selector

Next, we get a selector for the actual namespace:

```
type(CLOUD_APPLICATION_NAMESPACE),toRelationships.isClusterOfNamespace($K8S_CLUSTER_SELECTOR),entityName("the-namespace-name")
```

(Replace `"the-namespace-name"`with the desired namespace's name!)

### Kubernetes Workload

The following then yields a selector for any workload (`Deployment`/`StatefulSet`) in this namespace:

```
type(CLOUD_APPLICATION),toRelationships.isNamespaceofCa($K8S_NAMESPACE_SELECTOR)
```

### Kubernetes Pods
Finally, the following then yields a selector for any `pod` in this namespace:
```
type("CLOUD_APPLICATION_INSTANCE"),toRelationships.isNamespaceOfCai($K8S_NAMESPACE_SELECTOR)
```
#### Remarks
The latter cannot be used for `AutoTag` rules, but only in `Management Zone` rules.
Depending on the actual use case, one can alternatively use the selector
```
type("CLOUD_APPLICATION_INSTANCE"),toRelationships.isClusterOfCai($K8S_CLUSTER_SELECTOR)
```
which of course is not suited for limiting visibility to a certain `namespace`.
Depending on the refresh rate of `clusters` and `namespaces`, the latter `entitySelector` might yield better performance (measured in speed of visibility propagation).

## Examples

### Example I) Create a SubManagementZone for a Namespace and its Pods

Assume your management zone is `mz-az-tech-team` and includes a Kubernetes cluster with name `k8s-mz-az-tech-team-my_eks_cluster`.
In there, you have namespace called `namespace42` that is of special interest.

A sub management zone configuration (to be put into the sub management zones folder of your CaC repository) then may look like:

````yaml

name: namespace42
entitySelectorBasedRules:
 - enabled: True
   entitySelector: >-
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                      type("KUBERNETES_CLUSTER"),
                      entityName("k8s-mz-az-tech-team-my_eks_cluster")
                   ),
                   entityName("namespace42")
   
 - enabled: True
   entitySelector: >- 
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                       type(CLOUD_APPLICATION_NAMESPACE),
                       toRelationships.isClusterOfNamespace(
                          type("KUBERNETES_CLUSTER"),
                          entityName("k8s-mz-az-tech-team-my_eks_cluster")
                       ),
                       entityName("namespace42")
                   )
````

This will create a sub management zone `smz-mz-az-tech-team-namespace42`, which contains the namespace and all workloads in it.
In particular, members of this sub management zone will see the workloads listed in the `Workloads` page that is accessible from the left main menu in the Dynatrace UI.

### Example II) Create an AutoTag for a Namespace and its Pods

In the same setting as before, we can actually use the same configuration for an autotag, i.e.
we can put the following into the auto tags directory:

````yaml

label: namespace42
entitySelectorBasedRules:
 - enabled: True
   entitySelector: >-
                   type(CLOUD_APPLICATION_NAMESPACE),
                   toRelationships.isClusterOfNamespace(
                      type("KUBERNETES_CLUSTER"),
                      entityName("k8s-mz-az-tech-team-my_eks_cluster")
                   ),
                   entityName("namespace42")
   
 - enabled: True
   entitySelector: >- 
                   type(CLOUD_APPLICATION),
                   toRelationships.isNamespaceofCa(
                       type(CLOUD_APPLICATION_NAMESPACE),
                       toRelationships.isClusterOfNamespace(
                          type("KUBERNETES_CLUSTER"),
                          entityName("k8s-mz-az-tech-team-my_eks_cluster")
                       ),
                       entityName("namespace42")
                   )
````


This will create the auto tag `mz-az-tech-team@namespace42`.
