# AWS Integration

This documentation contains some complementing information for the configuration of AWS accounts via your
Configuration as Code repository.

For basic instructions, see the `aws/` subdirectory in your configuration repository.

## AWS supporting services

AWS supporting service metrics can be added in the `supportingServicesToMonitor` entry in 
an AWS credentials configuration yaml file.

This must contain a list of objects [following the `AwsSupportingServiceConfig` schema as
given by Dynatrace for the AWS Credentials API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/aws-credentials-api/post-new-credentials/#awscredentials-post-parameter-awssupportingserviceconfig).


According to that, each entry must contain the name of the supporting service as well as a list of metrics to be 
monitored.

AWS' official service names are mapped to internal names by Dynatrace according to the table below. 

For further details, we refer to the [Dynatrace documentation on supporting services](https://www.dynatrace.com/support/help/how-to-use-dynatrace/infrastructure-monitoring/cloud-platform-monitoring/amazon-web-services-monitoring/aws-supporting-service-metrics/).

In particular, this documentation contains the metrics available for each service.

### Example

Let's assume we would like to add the `Amazon Route 53` service.

The table below yields the service name `route53`

From the Dynatrace documentation as linked above, we can go to [Amazon Route 53](https://www.dynatrace.com/support/help/how-to-use-dynatrace/infrastructure-monitoring/cloud-platform-monitoring/amazon-web-services-monitoring/aws-supporting-service-metrics/route-53/).

This page contains in particular [the  metrics available for this service](https://www.dynatrace.com/support/help/shortlink/route-53#available-metrics)
as well as the required details. In this example, we choose the `DNSQueries` metric, which has the dimensions `HostedZoneId`
and available statistics "Multi" or "Sum". For the latter, please note the available statistic operators as
given in the [Dynatrace API specification](https://www.dynatrace.com/support/help/shortlink/api-config-aws-credentials-post-new#body-format)..
Consequently, if we choose "Multi", we can use the value `AVG_MIN_MAX` in the configuration.

In summary, we obtain the following configuration:
````yaml
supportingServices:
- name: route53
  monitoredMetrics: 
  - name: DNSQueries
    statistic: AVG_MIN_MAX
    dimensions:
    - HostedZoneId
````

## Default Service Metrics

Dynatrace offers a "default selection" of metrics to be included for the supporting services. In order to use those defaults
as well as to offer you a starting point for your individual configuration, we provide you with the configuration yaml-snippets
for those.

In order to use, simply copy a snippet into your AWS account configuration yaml file. Note: If you'd like to use multiple snippets,
you must concatenate the lists given in the `supportingServicesToMonitor` (only a single `supportingServicesToMonitor`is allowed, of course!).

The snippets are stored in the [aws_supporting_services_default_metrics](aws_supporting_services_default_metrics/) folder, here is the list:
- [APIGateway](aws_supporting_services_default_metrics/APIGateway.yml)
- [AWS API Usage](aws_supporting_services_default_metrics/AWS%20API%20Usage.yml)
- [AWS App Runner](aws_supporting_services_default_metrics/AWS%20App%20Runner.yml)
- [AWS AppSync](aws_supporting_services_default_metrics/AWS%20AppSync.yml)
- [AWS Billing](aws_supporting_services_default_metrics/AWS%20Billing.yml)
- [AWS Certificate Manager Private Certificate Authority](aws_supporting_services_default_metrics/AWS%20Certificate%20Manager%20Private%20Certificate%20Authority.yml)
- [AWS Chatbot](aws_supporting_services_default_metrics/AWS%20Chatbot.yml)
- [AWS CloudHSM](aws_supporting_services_default_metrics/AWS%20CloudHSM.yml)
- [AWS CodeBuild](aws_supporting_services_default_metrics/AWS%20CodeBuild.yml)
- [AWS DataSync](aws_supporting_services_default_metrics/AWS%20DataSync.yml)
- [AWS Direct Connect](aws_supporting_services_default_metrics/AWS%20Direct%20Connect.yml)
- [AWS Elastic Beanstalk](aws_supporting_services_default_metrics/AWS%20Elastic%20Beanstalk.yml)
- [AWS Elemental MediaConnect](aws_supporting_services_default_metrics/AWS%20Elemental%20MediaConnect.yml)
- [AWS Glue](aws_supporting_services_default_metrics/AWS%20Glue.yml)
- [AWS Internet of Things (IoT)](aws_supporting_services_default_metrics/AWS%20Internet%20of%20Things%20%28IoT%29.yml)
- [AWS IoT Analytics](aws_supporting_services_default_metrics/AWS%20IoT%20Analytics.yml)
- [AWS IoT Things Graph](aws_supporting_services_default_metrics/AWS%20IoT%20Things%20Graph.yml)
- [AWS OpsWorks](aws_supporting_services_default_metrics/AWS%20OpsWorks.yml)
- [AWS RoboMaker](aws_supporting_services_default_metrics/AWS%20RoboMaker.yml)
- [AWS Service Catalog](aws_supporting_services_default_metrics/AWS%20Service%20Catalog.yml)
- [AWS Site-to-Site VPN](aws_supporting_services_default_metrics/AWS%20Site-to-Site%20VPN.yml)
- [AWS Step Functions](aws_supporting_services_default_metrics/AWS%20Step%20Functions.yml)
- [AWS Storage Gateway](aws_supporting_services_default_metrics/AWS%20Storage%20Gateway.yml)
- [AWS Systems Manager - Run Command](aws_supporting_services_default_metrics/AWS%20Systems%20Manager%20-%20Run%20Command.yml)
- [AWS Transit Gateway](aws_supporting_services_default_metrics/AWS%20Transit%20Gateway.yml)
- [AWS Trusted Advisor](aws_supporting_services_default_metrics/AWS%20Trusted%20Advisor.yml)
- [Amazon AppStream](aws_supporting_services_default_metrics/Amazon%20AppStream.yml)
- [Amazon Athena](aws_supporting_services_default_metrics/Amazon%20Athena.yml)
- [Amazon Aurora](aws_supporting_services_default_metrics/Amazon%20Aurora.yml)
- [Amazon CloudFront](aws_supporting_services_default_metrics/Amazon%20CloudFront.yml)
- [Amazon CloudSearch](aws_supporting_services_default_metrics/Amazon%20CloudSearch.yml)
- [Amazon CloudWatch Logs](aws_supporting_services_default_metrics/Amazon%20CloudWatch%20Logs.yml)
- [Amazon Cognito](aws_supporting_services_default_metrics/Amazon%20Cognito.yml)
- [Amazon Connect](aws_supporting_services_default_metrics/Amazon%20Connect.yml)
- [Amazon Database Migration Service](aws_supporting_services_default_metrics/Amazon%20Database%20Migration%20Service.yml)
- [Amazon DocumentDB](aws_supporting_services_default_metrics/Amazon%20DocumentDB.yml)
- [Amazon DynamoDB Accelerator (DAX)](aws_supporting_services_default_metrics/Amazon%20DynamoDB%20Accelerator%20%28DAX%29.yml)
- [Amazon EC2 API](aws_supporting_services_default_metrics/Amazon%20EC2%20API.yml)
- [Amazon EC2 Auto Scaling](aws_supporting_services_default_metrics/Amazon%20EC2%20Auto%20Scaling.yml)
- [Amazon EC2 Spot Fleet](aws_supporting_services_default_metrics/Amazon%20EC2%20Spot%20Fleet.yml)
- [Amazon ECS ContainerInsights](aws_supporting_services_default_metrics/Amazon%20ECS%20ContainerInsights.yml)
- [Amazon Elastic Container Service (ECS)](aws_supporting_services_default_metrics/Amazon%20Elastic%20Container%20Service%20%28ECS%29.yml)
- [Amazon Elastic File System (EFS)](aws_supporting_services_default_metrics/Amazon%20Elastic%20File%20System%20%28EFS%29.yml)
- [Amazon Elastic Inference](aws_supporting_services_default_metrics/Amazon%20Elastic%20Inference.yml)
- [Amazon Elastic Kubernetes Service (EKS)](aws_supporting_services_default_metrics/Amazon%20Elastic%20Kubernetes%20Service%20%28EKS%29.yml)
- [Amazon Elastic Map Reduce (EMR)](aws_supporting_services_default_metrics/Amazon%20Elastic%20Map%20Reduce%20%28EMR%29.yml)
- [Amazon Elastic Transcoder](aws_supporting_services_default_metrics/Amazon%20Elastic%20Transcoder.yml)
- [Amazon Elasticsearch Service (ES)](aws_supporting_services_default_metrics/Amazon%20Elasticsearch%20Service%20%28ES%29.yml)
- [Amazon EventBridge](aws_supporting_services_default_metrics/Amazon%20EventBridge.yml)
- [Amazon FSx](aws_supporting_services_default_metrics/Amazon%20FSx.yml)
- [Amazon GameLift](aws_supporting_services_default_metrics/Amazon%20GameLift.yml)
- [Amazon Inspector](aws_supporting_services_default_metrics/Amazon%20Inspector.yml)
- [Amazon Keyspaces](aws_supporting_services_default_metrics/Amazon%20Keyspaces.yml)
- [Amazon Kinesis Data Analytics](aws_supporting_services_default_metrics/Amazon%20Kinesis%20Data%20Analytics.yml)
- [Amazon Lex](aws_supporting_services_default_metrics/Amazon%20Lex.yml)
- [Amazon MQ](aws_supporting_services_default_metrics/Amazon%20MQ.yml)
- [Amazon MediaConvert](aws_supporting_services_default_metrics/Amazon%20MediaConvert.yml)
- [Amazon MediaPackage Live](aws_supporting_services_default_metrics/Amazon%20MediaPackage%20Live.yml)
- [Amazon MediaPackage Video on Demand](aws_supporting_services_default_metrics/Amazon%20MediaPackage%20Video%20on%20Demand.yml)
- [Amazon MediaTailor](aws_supporting_services_default_metrics/Amazon%20MediaTailor.yml)
- [Amazon Neptune](aws_supporting_services_default_metrics/Amazon%20Neptune.yml)
- [Amazon Polly](aws_supporting_services_default_metrics/Amazon%20Polly.yml)
- [Amazon QLDB](aws_supporting_services_default_metrics/Amazon%20QLDB.yml)
- [Amazon Redshift](aws_supporting_services_default_metrics/Amazon%20Redshift.yml)
- [Amazon Rekognition](aws_supporting_services_default_metrics/Amazon%20Rekognition.yml)
- [Amazon Route 53](aws_supporting_services_default_metrics/Amazon%20Route%2053.yml)
- [Amazon Route 53 Resolver](aws_supporting_services_default_metrics/Amazon%20Route%2053%20Resolver.yml)
- [Amazon S3](aws_supporting_services_default_metrics/Amazon%20S3.yml)
- [Amazon SWF](aws_supporting_services_default_metrics/Amazon%20SWF.yml)
- [Amazon Simple Email Service (SES)](aws_supporting_services_default_metrics/Amazon%20Simple%20Email%20Service%20%28SES%29.yml)
- [Amazon Simple Notification Service (SNS)](aws_supporting_services_default_metrics/Amazon%20Simple%20Notification%20Service%20%28SNS%29.yml)
- [Amazon Simple Queue Service (SQS)](aws_supporting_services_default_metrics/Amazon%20Simple%20Queue%20Service%20%28SQS%29.yml)
- [Amazon Textract](aws_supporting_services_default_metrics/Amazon%20Textract.yml)
- [Amazon Transfer Family](aws_supporting_services_default_metrics/Amazon%20Transfer%20Family.yml)
- [Amazon Translate](aws_supporting_services_default_metrics/Amazon%20Translate.yml)
- [Amazon VPC NAT Gateways](aws_supporting_services_default_metrics/Amazon%20VPC%20NAT%20Gateways.yml)
- [Amazon WAF](aws_supporting_services_default_metrics/Amazon%20WAF.yml)
- [Amazon WAF Classic](aws_supporting_services_default_metrics/Amazon%20WAF%20Classic.yml)
- [Amazon WorkMail](aws_supporting_services_default_metrics/Amazon%20WorkMail.yml)
- [Amazon WorkSpaces](aws_supporting_services_default_metrics/Amazon%20WorkSpaces.yml)
- [ElastiCache](aws_supporting_services_default_metrics/ElastiCache.yml)
- [KinesisDataStreams](aws_supporting_services_default_metrics/KinesisDataStreams.yml)
- [KinesisFirehose](aws_supporting_services_default_metrics/KinesisFirehose.yml)
- [KinesisVideoStreams](aws_supporting_services_default_metrics/KinesisVideoStreams.yml)
- [SageMakerBatchTransformJobs](aws_supporting_services_default_metrics/SageMakerBatchTransformJobs.yml)
- [SageMakerEndpointInstances](aws_supporting_services_default_metrics/SageMakerEndpointInstances.yml)
- [SageMakerEndpoints](aws_supporting_services_default_metrics/SageMakerEndpoints.yml)
- [SageMakerGroundTruth](aws_supporting_services_default_metrics/SageMakerGroundTruth.yml)
- [SageMakerProcessingJobs](aws_supporting_services_default_metrics/SageMakerProcessingJobs.yml)
- [SageMakerTrainingJobs](aws_supporting_services_default_metrics/SageMakerTrainingJobs.yml)
- [kafka](aws_supporting_services_default_metrics/kafka.yml)


## List of Configuration Names
Service|Dynatrace Configuration Name |
--- | --- |
AWS Certificate Manager Private Certificate Authority | acmprivateca |
Amazon MQ | amazonmq |
Amazon API Gateway | APIGateway |
AWS App Runner | apprunner |
Amazon AppStream | appstream |
AWS AppSync | appsync |
Amazon Athena | athena |
Amazon Aurora | Aurora |
Amazon EC2 Auto Scaling | autoscaling |
AWS Billing | billing |
Amazon Keyspaces | cassandra |
AWS Chatbot | chatbot |
Amazon CloudFront | CloudFront |
AWS CloudHSM | cloudhsm |
Amazon CloudSearch | cloudsearch |
AWS CodeBuild | codebuild |
Amazon Cognito | Cognito |
Amazon Connect | connect |
AWS DataSync | datasync |
Amazon DynamoDB Accelerator (DAX) | dax |
Amazon Database Migration Service | dms |
Amazon DocumentDB | docdb |
AWS Direct Connect | dx |
Amazon EC2 API | ec2api |
Amazon EC2 Spot Fleet | EC2Spot |
Amazon Elastic Container Service (ECS) | ECS |
Amazon ECS ContainerInsights | ecscontainerinsights |
Amazon Elastic File System (EFS) | EFS |
Amazon Elastic Kubernetes Service (EKS) | eks |
Amazon ElastiCache (EC) | ElastiCache |
AWS Elastic Beanstalk | elasticbeanstalk |
Amazon Elastic Inference | elasticinference |
Amazon Elastic Transcoder | elastictranscoder |
Amazon Elastic Map Reduce (EMR) | EMR |
Amazon Elasticsearch Service (ES) | ES |
Amazon EventBridge | events |
Amazon FSx | fsx |
Amazon GameLift | gamelift |
AWS Glue | Glue |
Amazon Inspector | inspector |
AWS Internet of Things (IoT) | IoT |
AWS IoT Analytics | iotanalytics |
AWS IoT Things Graph | iotthingsgraph |
Amazon Managed Streaming for Kafka | kafka |
Amazon Kinesis Data Analytics | KinesisAnalytics |
Amazon Kinesis Data Streams | KinesisDataStreams |
Amazon Kinesis Data Firehose | KinesisFirehose |
Amazon Kinesis Video Streams | KinesisVideoStreams |
Amazon Lex | lex |
Amazon CloudWatch Logs | logs |
AWS Elemental MediaConnect | mediaconnect |
Amazon MediaConvert | mediaconvert |
Amazon MediaPackage Live | mediapackagelive |
Amazon MediaPackage Video on Demand | mediapackagevod |
Amazon MediaTailor | mediatailor |
Amazon VPC NAT Gateways | NATGateway |
Amazon Neptune | neptune |
AWS OpsWorks | opsworks |
Amazon Polly | polly |
Amazon QLDB | qldb |
Amazon Redshift | Redshift |
Amazon Rekognition | rekognition |
AWS RoboMaker | robomaker |
Amazon Route 53 | route53 |
Amazon Route 53 Resolver | route53resolver |
Amazon S3 | S3 |
Amazon SageMaker Batch Transform Jobs | SageMakerBatchTransformJobs |
Amazon SageMaker Endpoint Instances | SageMakerEndpointInstances |
Amazon SageMaker Endpoints | SageMakerEndpoints |
Amazon SageMaker Ground Truth | SageMakerGroundTruth |
Amazon SageMaker Processing Jobs | SageMakerProcessingJobs |
Amazon SageMaker Training Jobs | SageMakerTrainingJobs |
AWS Service Catalog | servicecatalog |
Amazon Simple Email Service (SES) | SES |
Amazon Simple Notification Service (SNS) | SNS |
Amazon Simple Queue Service (SQS) | SQS |
AWS Systems Manager - Run Command | ssm-runcommand |
AWS Step Functions | states |
AWS Storage Gateway | storagegateway |
Amazon SWF | swf |
Amazon Textract | textract |
Amazon Transfer Family | transfer |
AWS Transit Gateway | transitgateway |
Amazon Translate | translate |
AWS Trusted Advisor | trustedadvisor |
AWS API Usage | usage |
AWS Site-to-Site VPN | vpn |
Amazon WAF Classic | waf |
Amazon WAF | wafv2 |
Amazon WorkMail | workmail |
Amazon WorkSpaces | workspaces |
