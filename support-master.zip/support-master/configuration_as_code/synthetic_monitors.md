<!--- begin mz config readme -->
<!--  Please do not change content inside this `mz config readme` block. Changes might be overwritten automatically! -->
# Synthetic Monitoring Configuration


## Required Data

Attributes:
 - `name` (_string_): You may give an arbitrary (but among your configured synthetic monitors unique) name for the configuration.  
 - `frequencyMin` (_integer_): The frequency of the monitor, in minutes. You can use one of the following values: 1, 2, 5, 10, 15, 30, and 60.  
 - `enabled` (_bool_): The monitor is enabled (true) or disabled (false).  
 - `type` (_string_): Defines the actual set of fields depending on the value. Currently only **HTTP** type is supported.
 - `script` (_string_): The script of a browser or HTTP monitor. 
    One way to provide the entire _script_ section is to open one of your existing Synthetic Monitors from [preprod](https://ily59392.live.dynatrace.com/#monitors;gf=all;gtf=-2h) or [prod](https://grz73876.live.dynatrace.com/#monitors;gtf=-2h;gf=all) and click **Edit** from the drop-down menu. By choosing **Http Requests** from the menu on the left and selecting **Script** instead of **UI Configuration**, you can copy the entire json into a yaml converter [Example](https://www.json2yaml.com/) and insert it in the configuration file. See also the [Dynatrace documentation](https://www.dynatrace.com/support/help/shortlink/http-monitor-script-mode#script-structure).  
    Note that adaptions are necessary in case of the usage of credentials. See also the example below.
 - `locations` (_list[string]_): A list of locations from which the monitor is executed. To specify a location, use its entity ID.  
 - `tags` (_list[string]_): A set of tags assigned to the monitor. See also the [Dynatrace documentation](https://www.dynatrace.com/support/help/shortlink/api-synthetic-monitors-post-monitor#syntheticmonitors-post-parameter-tagwithsourceinfo)
 - `manuallyAssignedApps` (_list[string]_): A set of manually assigned applications. 

 
 
 ### Examplary of `script`-Attribute:
 Assume you have gained a HTTP Monitor script from Dynatrace as follows:
````json
{
"version": "1.0",
"requests": [
    {
        "description": "example.offline",
        "url": "http://example.offline?token={CREDENTIALS_VAULT-6798U613AC9024B|token}",
        "method": "GET",
        "authentication": {
            "type": "BASIC_AUTHENTICATION",
            "credentials": "CREDENTIALS_VAULT-055ZU613AC9024B"
        },
        "validation": {
            "rules": [
                {
                    "value": ">=400",
                    "passIfFound": false,
                    "type": "httpStatusesList"
                }
            ],
            "rulesChaining": "or"
        },
        "configuration": {
            "acceptAnyCertificate": true,
            "followRedirects": true
        }
    }
]
}
````
This translates into the following `script` attribute in your the Synthetic Monitor configuration file:
```yaml
version: '1.0'
requests:
- description: example.offline
  url: http://example.offline?token={{ my_token_credential }|token}
  method: GET
  authentication:
    type: BASIC_AUTHENTICATION
    credentials: {{ my_credential_reference }}
  validation:
    rules:
    - value: '>=400'
      passIfFound: false
      type: httpStatusesList
    rulesChaining: 'or'
  configuration:
    acceptAnyCertificate: true
    followRedirects: true
````

Here, note that the reference to the Dynatrace credentials `{CREDENTIALS_VAULT-6798U613AC9024B|token}`and `CREDENTIALS_VAULT-055ZU613AC9024B` 
have been replaced by
references `{{ my_token_credential }|token}` and `{{ my_credential_reference }}`, respectively. Those credentials  must be provided 
in the `/credentials` folder of the configuration repository in an encrypted way. Please see the following section for more 
details on the detailed syntax.


## Credentials in Synthetic Monitors

### Providing credentials for Synthetic Monitors

Within each synthetic monitors that you define, you have the option of referencing some credentials if they are required. 
However, instead of referencing the Dynatrace Credentials Vault, you will have to reference the credentials in the
`/credentials` folder. Here, the credentials must be stored following the Syntax of the
 [Dynatrace Credentials Vault Api](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/credential-vault/).
Note that for technical reasons that except for tenant-wide visible credentials, it is not possible to reference any 
Dynatrace vault credential by its Dynatrace credential vault id!

Before referencing a credential ID in the Synthetic Monitor configuration file, add into the `/credentials` folder in encrypted form and 
obeying the schema as follows.
 _Please see [our documentation of how to submit credentials](https://github.developer.allianz.io/globalmonitoring/support/blob/master/configuration_as_code/credentials_submission.md)
to your configuration repository!_

### General Schema

In general, you may provide a credential (in its own or some common) encrypted file in `/credentials`. Assume you want 
to create a credential with reference name `my_credential`, this file then needs to contain an attribute
````yaml
my_credential:
   type: <TYPE OF THE CREDENTIAL>
   [...] # further attributes of the credential depending on its type.
````

### Credential types
The allowed types and attributes of credentials can be looked up in the according Dynatrace API documentation, see
https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/credential-vault/.

Supported types are: `USERNAME_PASSWORD`, `CERTIFICATE` , `TOKEN`

#### Example for USERNAME_PASSWORD credential
````yaml
my_credential:
    type: USERNAME_PASSWORD
    user: john.doe
    password: clear_text_password
````

#### Example for TOKEN credential
````yaml
my_credential:
    type: TOKEN
    token: ABC#1234
````

#### Example for CERTIFICATE credential
````yaml
my_credential:
    type: CERTIFICATE
    certificateFormat: PEM
    password: ""
    certificate: "Bag Attributes
                localKeyID: BE 2B 0D 9C 7D 26 A8 1E C3 DF D6 G1 B3 7E F2 34 72 C2 74 E2 
                subject=/C=DE/ST=BY/L=Munich/O=GlobalMonitoring/OU=A Test Unit/CN=localhost
                issuer=/C=DE/ST=Germany/O=GlobalMonitoring/OU=MyName/CN=GmTestCA
                -----BEGIN CERTIFICATE-----
                MIIEnDCCAoSgAwIBAgIJAPEdUTydkkxYMA0GCSqGSIb3DQEBBQUAMGMxCzAJBgNV
                [...]
                D5ux7uHapHKEmwhBLCvy1/ILIOWPddJbfI13azdHULQ=
                -----END CERTIFICATE-----
                Bag Attributes
                    localKeyID: BD 2B 0D 9C 7D 56 A8 1E C2 DE D6 E1 B2 9E F0 46 72 C2 74 E2 
                Key Attributes: <No Attributes>
                -----BEGIN PRIVATE KEY-----
                MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDP7qx+7YPKPgS6
                [...]
                DzdkSXWWHDMcjP7lf5LRPiue
                -----END PRIVATE KEY-----"
````

### Referencing credentials in Synthetic Monitors

Instead of referring to the credential by its Dynatrace, you may use the reference using double curly brackets (surrounded by mandatory double quotes!),
for example:
 ````yaml
    authentication:
      type: BASIC_AUTHENTICATION
      credentials: "{{ my_credential }}"
````

In case for references to credentials in the  `url` or header-`value` the Dynatrace reference schema
`{CREDENTIALS_VAULT-<ID_REMAINDER>|<PROPERTY>}` can be replaced by 
`{{ my_credential }|<PROPERTY>}` can be replaced by 

For Example:
 ````yaml
    url: http://example.offline?token={{ my_token_credential }|token}
````

Here, a credential of type `TOKEN` with name `my_token_credential` must be provided as described above.



## Synthetic Monitor Locations

Please consult the table from the main **Synthetic Monitors** page (previous page that brought you here) for the required Location ID that needs to be added in the configuration file. Be aware that some locations have multiple entries depending on the cloud platform.  
Example:  
 ```
    locations:
    - GEOLOCATION-191EF52906549983
```


### Synthetic Monitor Example
You may use for guidance the following provided example to have a better understanding of how a configuration file can look like, for an **HTTP** type Synthetic Monitor.  
 ```
name: Example-Synthetic
frequencyMin: 1
enabled: true
type: HTTP
script:
  version: '1.0'
  requests:
  - description: EXAMPLE.offline
    url: http://EXAMPLE.offline
    method: GET
    validation:
      rules:
      - value: ">=400"
        passIfFound: false
        type: httpStatusesList
      rulesChaining: or
    configuration:
      acceptAnyCertificate: true
      followRedirects: true
locations:
- GEOLOCATION-191EF52906549983
anomalyDetection:
  outageHandling:
    globalOutage: true
    localOutage: false
    localOutagePolicy:
      affectedLocations: 1
      consecutiveRuns: 3
  loadingTimeThresholds:
    enabled: false
    thresholds:
    - type: TOTAL
      valueMs: 0
tags: []
managementZones: []
automaticallyAssignedApps: []
manuallyAssignedApps: []
```

<!--- end mz config readme -->
