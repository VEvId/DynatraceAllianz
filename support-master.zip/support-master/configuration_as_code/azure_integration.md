# Azure Integration

This documentation contains some complementing information for the configuration of Azure accounts via your
Configuration as Code repository.

For basic instructions, see the `azure/` subdirectory in your configuration repository.

## Azure supporting services

Azure supporting service metrics can be added in the `supportingServices` entry in 
an Azure credentials configuration yaml file.

This must contain a list of objects [following the `AzureSupportingService` schema as
given by Dynatrace for the Azure Credentials API](https://www.dynatrace.com/support/help/dynatrace-api/configuration-api/azure-credentials-api/post-new-credentials#definition--AzureSupportingService).


According to that, each entry must contain the name of the supporting service as well as a list of metrics to be 
monitored.

Azure's official service names are mapped to internal names by Dynatrace according to the [table below](#list-of-configuration-names). 

For further details, we refer to the [Dynatrace documentation on supporting services](https://www.dynatrace.com/support/help/how-to-use-dynatrace/infrastructure-monitoring/cloud-platform-monitoring/microsoft-azure-services-monitoring/azure-metrics).

In particular, this documentation contains the metrics available for each service.

### Example

Let's assume we would like to add the `Azure App Configuration` service.

The table below yields the service name `cloud:azure:appconfiguration:configurationstores`

From the Dynatrace documentation as linked above, we can go to [Azure App Configuration](https://www.dynatrace.com/support/help/how-to-use-dynatrace/infrastructure-monitoring/cloud-platform-monitoring/microsoft-azure-services-monitoring/azure-supporting-services-monitoring/monitor-azure-app-configuration).

This page contains in particular [the metrics available for this service](https://www.dynatrace.com/support/help/how-to-use-dynatrace/infrastructure-monitoring/cloud-platform-monitoring/microsoft-azure-services-monitoring/azure-supporting-services-monitoring/monitor-azure-app-configuration#available-metrics)
as well as the required details. **Please note that the recommended metrics are always required to be selected!**

In this example, we have to choose the `HttpIncomingRequestCount` metric, which has the dimensions `StatusCode` and `Authentication`, along with the `ThrottledHttpRequestCount` metric which has no dimension.

In summary, we obtain the following configuration:
````yaml
supportingServices:
  name: cloud:azure:appconfiguration:configurationstores
  monitoredMetrics:
  - name: HttpIncomingRequestCount
    dimensions:
    - StatusCode
    - Authentication
  - name: ThrottledHttpRequestCount
    dimensions: []
````

## Default Service Metrics

Dynatrace offers a "default selection" of metrics to be included for the supporting services. In order to use those defaults
as well as to offer you a starting point for your individual configuration, we provide the configuration yaml-snippets
for those.

In order to use them, simply copy a snippet into your Azure account configuration yaml file. Note: If you'd like to use multiple snippets,
you must concatenate the lists given in the `supportingServicesToMonitor` (only a single list `supportingServices` is allowed in your configuration file, of course!).

The snippets are stored in the [azure_supporting_services_default_metrics](azure_supporting_services_default_metrics/) folder, here is the list:
- [Azure Anomaly Detector](azure_supporting_services_default_metrics/Azure%20Anomaly%20Detector.yml)
- [Azure Apache Spark Pool](azure_supporting_services_default_metrics/Azure%20Apache%20Spark%20Pool.yml)
- [Azure App Configuration](azure_supporting_services_default_metrics/Azure%20App%20Configuration.yml)
- [Azure App Service Plan](azure_supporting_services_default_metrics/Azure%20App%20Service%20Plan.yml)
- [Azure Application Insights](azure_supporting_services_default_metrics/Azure%20Application%20Insights.yml)
- [Azure Automation Account](azure_supporting_services_default_metrics/Azure%20Automation%20Account.yml)
- [Azure Batch Account](azure_supporting_services_default_metrics/Azure%20Batch%20Account.yml)
- [Azure Bing Autosuggest](azure_supporting_services_default_metrics/Azure%20Bing%20Autosuggest.yml)
- [Azure Bing Custom Search](azure_supporting_services_default_metrics/Azure%20Bing%20Custom%20Search.yml)
- [Azure Bing Entity Search](azure_supporting_services_default_metrics/Azure%20Bing%20Entity%20Search.yml)
- [Azure Bing Search](azure_supporting_services_default_metrics/Azure%20Bing%20Search.yml)
- [Azure Bing Spell Check](azure_supporting_services_default_metrics/Azure%20Bing%20Spell%20Check.yml)
- [Azure Blockchain Service](azure_supporting_services_default_metrics/Azure%20Blockchain%20Service.yml)
- [Azure CDN WAF Policy](azure_supporting_services_default_metrics/Azure%20CDN%20WAF%20Policy.yml)
- [Azure Cognitive Services - All in One](azure_supporting_services_default_metrics/Azure%20Cognitive%20Services%20-%20All%20in%20One.yml)
- [Azure Computer Vision](azure_supporting_services_default_metrics/Azure%20Computer%20Vision.yml)
- [Azure Connection Monitors Preview](azure_supporting_services_default_metrics/Azure%20Connection%20Monitors%20Preview.yml)
- [Azure Container Instance](azure_supporting_services_default_metrics/Azure%20Container%20Instance.yml)
- [Azure Container Registry](azure_supporting_services_default_metrics/Azure%20Container%20Registry.yml)
- [Azure Content Moderator](azure_supporting_services_default_metrics/Azure%20Content%20Moderator.yml)
- [Azure Custom Vision Prediction](azure_supporting_services_default_metrics/Azure%20Custom%20Vision%20Prediction.yml)
- [Azure Custom Vision Training](azure_supporting_services_default_metrics/Azure%20Custom%20Vision%20Training.yml)
- [Azure DB for MariaDB](azure_supporting_services_default_metrics/Azure%20DB%20for%20MariaDB.yml)
- [Azure DB for MySQL](azure_supporting_services_default_metrics/Azure%20DB%20for%20MySQL.yml)
- [Azure DB for PostgreSQL - Flexible Server](azure_supporting_services_default_metrics/Azure%20DB%20for%20PostgreSQL%20-%20Flexible%20Server.yml)
- [Azure DB for PostgreSQL - Hyperscale](azure_supporting_services_default_metrics/Azure%20DB%20for%20PostgreSQL%20-%20Hyperscale.yml)
- [Azure DB for PostgreSQL - Server](azure_supporting_services_default_metrics/Azure%20DB%20for%20PostgreSQL%20-%20Server.yml)
- [Azure DNS Zone](azure_supporting_services_default_metrics/Azure%20DNS%20Zone.yml)
- [Azure Data Explorer Cluster](azure_supporting_services_default_metrics/Azure%20Data%20Explorer%20Cluster.yml)
- [Azure Data Factory v1](azure_supporting_services_default_metrics/Azure%20Data%20Factory%20v1.yml)
- [Azure Data Factory v2](azure_supporting_services_default_metrics/Azure%20Data%20Factory%20v2.yml)
- [Azure Data Lake Analytics](azure_supporting_services_default_metrics/Azure%20Data%20Lake%20Analytics.yml)
- [Azure Data Lake Storage Gen1](azure_supporting_services_default_metrics/Azure%20Data%20Lake%20Storage%20Gen1.yml)
- [Azure Data Share](azure_supporting_services_default_metrics/Azure%20Data%20Share.yml)
- [Azure Device Provisioning Service](azure_supporting_services_default_metrics/Azure%20Device%20Provisioning%20Service.yml)
- [Azure Event Grid Domain](azure_supporting_services_default_metrics/Azure%20Event%20Grid%20Domain.yml)
- [Azure Event Grid System Topic](azure_supporting_services_default_metrics/Azure%20Event%20Grid%20System%20Topic.yml)
- [Azure Event Grid Topic](azure_supporting_services_default_metrics/Azure%20Event%20Grid%20Topic.yml)
- [Azure Event Hubs Cluster](azure_supporting_services_default_metrics/Azure%20Event%20Hubs%20Cluster.yml)
- [Azure ExpressRoute Circuit](azure_supporting_services_default_metrics/Azure%20ExpressRoute%20Circuit.yml)
- [Azure Face](azure_supporting_services_default_metrics/Azure%20Face.yml)
- [Azure Firewall](azure_supporting_services_default_metrics/Azure%20Firewall.yml)
- [Azure Front Door](azure_supporting_services_default_metrics/Azure%20Front%20Door.yml)
- [Azure Function App Deployment Slot](azure_supporting_services_default_metrics/Azure%20Function%20App%20Deployment%20Slot.yml)
- [Azure HDInsight Cluster](azure_supporting_services_default_metrics/Azure%20HDInsight%20Cluster.yml)
- [Azure Immersive Reader](azure_supporting_services_default_metrics/Azure%20Immersive%20Reader.yml)
- [Azure Ink Recognizer](azure_supporting_services_default_metrics/Azure%20Ink%20Recognizer.yml)
- [Azure Integration Service Environment](azure_supporting_services_default_metrics/Azure%20Integration%20Service%20Environment.yml)
- [Azure IoT Central Application](azure_supporting_services_default_metrics/Azure%20IoT%20Central%20Application.yml)
- [Azure Key Vault](azure_supporting_services_default_metrics/Azure%20Key%20Vault.yml)
- [Azure Kubernetes Service (AKS)](azure_supporting_services_default_metrics/Azure%20Kubernetes%20Service%20%28AKS%29.yml)
- [Azure Language Understanding (LUIS)](azure_supporting_services_default_metrics/Azure%20Language%20Understanding%20%28LUIS%29.yml)
- [Azure Language Understanding Authoring (LUIS)](azure_supporting_services_default_metrics/Azure%20Language%20Understanding%20Authoring%20%28LUIS%29.yml)
- [Azure Logic Apps](azure_supporting_services_default_metrics/Azure%20Logic%20Apps.yml)
- [Azure Machine Learning Workspace](azure_supporting_services_default_metrics/Azure%20Machine%20Learning%20Workspace.yml)
- [Azure Maps Account](azure_supporting_services_default_metrics/Azure%20Maps%20Account.yml)
- [Azure Media Service](azure_supporting_services_default_metrics/Azure%20Media%20Service.yml)
- [Azure Mesh Application](azure_supporting_services_default_metrics/Azure%20Mesh%20Application.yml)
- [Azure NetApp Capacity Pool](azure_supporting_services_default_metrics/Azure%20NetApp%20Capacity%20Pool.yml)
- [Azure NetApp Volume](azure_supporting_services_default_metrics/Azure%20NetApp%20Volume.yml)
- [Azure Network Interface](azure_supporting_services_default_metrics/Azure%20Network%20Interface.yml)
- [Azure Notification Hub](azure_supporting_services_default_metrics/Azure%20Notification%20Hub.yml)
- [Azure Personalizer](azure_supporting_services_default_metrics/Azure%20Personalizer.yml)
- [Azure Power BI Embedded](azure_supporting_services_default_metrics/Azure%20Power%20BI%20Embedded.yml)
- [Azure Private DNS Zone](azure_supporting_services_default_metrics/Azure%20Private%20DNS%20Zone.yml)
- [Azure Public IP Address](azure_supporting_services_default_metrics/Azure%20Public%20IP%20Address.yml)
- [Azure QnA Maker](azure_supporting_services_default_metrics/Azure%20QnA%20Maker.yml)
- [Azure Relay](azure_supporting_services_default_metrics/Azure%20Relay.yml)
- [Azure SQL Data Warehouse (legacy)](azure_supporting_services_default_metrics/Azure%20SQL%20Data%20Warehouse%20%28legacy%29.yml)
- [Azure SQL Database - Hyperscale](azure_supporting_services_default_metrics/Azure%20SQL%20Database%20-%20Hyperscale.yml)
- [Azure SQL Managed Instance](azure_supporting_services_default_metrics/Azure%20SQL%20Managed%20Instance.yml)
- [Azure SQL Pool](azure_supporting_services_default_metrics/Azure%20SQL%20Pool.yml)
- [Azure Search Service](azure_supporting_services_default_metrics/Azure%20Search%20Service.yml)
- [Azure SignalR](azure_supporting_services_default_metrics/Azure%20SignalR.yml)
- [Azure Speech](azure_supporting_services_default_metrics/Azure%20Speech.yml)
- [Azure Spring Cloud](azure_supporting_services_default_metrics/Azure%20Spring%20Cloud.yml)
- [Azure Storage Account (classic)](azure_supporting_services_default_metrics/Azure%20Storage%20Account%20%28classic%29.yml)
- [Azure Storage Blob Services (classic)](azure_supporting_services_default_metrics/Azure%20Storage%20Blob%20Services%20%28classic%29.yml)
- [Azure Storage File Services (classic)](azure_supporting_services_default_metrics/Azure%20Storage%20File%20Services%20%28classic%29.yml)
- [Azure Storage Queue Services (classic)](azure_supporting_services_default_metrics/Azure%20Storage%20Queue%20Services%20%28classic%29.yml)
- [Azure Storage Sync Service](azure_supporting_services_default_metrics/Azure%20Storage%20Sync%20Service.yml)
- [Azure Storage Table Services (classic)](azure_supporting_services_default_metrics/Azure%20Storage%20Table%20Services%20%28classic%29.yml)
- [Azure Stream Analytics Job](azure_supporting_services_default_metrics/Azure%20Stream%20Analytics%20Job.yml)
- [Azure Streaming Endpoint](azure_supporting_services_default_metrics/Azure%20Streaming%20Endpoint.yml)
- [Azure Synapse Workspace](azure_supporting_services_default_metrics/Azure%20Synapse%20Workspace.yml)
- [Azure Text Analytics](azure_supporting_services_default_metrics/Azure%20Text%20Analytics.yml)
- [Azure Time Series Insights Environment](azure_supporting_services_default_metrics/Azure%20Time%20Series%20Insights%20Environment.yml)
- [Azure Time Series Insights Event Source](azure_supporting_services_default_metrics/Azure%20Time%20Series%20Insights%20Event%20Source.yml)
- [Azure Traffic Manager Profile](azure_supporting_services_default_metrics/Azure%20Traffic%20Manager%20Profile.yml)
- [Azure Translator](azure_supporting_services_default_metrics/Azure%20Translator.yml)
- [Azure Virtual Machine (classic)](azure_supporting_services_default_metrics/Azure%20Virtual%20Machine%20%28classic%29.yml)
- [Azure Virtual Network Gateway](azure_supporting_services_default_metrics/Azure%20Virtual%20Network%20Gateway.yml)
- [Azure Web App Deployment Slot](azure_supporting_services_default_metrics/Azure%20Web%20App%20Deployment%20Slot.yml)


## List of Configuration Names
Service|Dynatrace Configuration Name |
--- | --- |
Azure Anomaly Detector | cloud:azure:cognitiveservices:anomalydetector |
Azure Apache Spark Pool | cloud:azure:synapse:workspaces:bigdatapools |
Azure App Configuration | cloud:azure:appconfiguration:configurationstores |
Azure App Service Plan | cloud:azure:web:serverfarms |
Azure Application Insights | cloud:azure:insights:components |
Azure Automation Account | cloud:azure:automation:automationaccounts |
Azure Batch Account | cloud:azure:batch:account |
Azure Bing Autosuggest | cloud:azure:cognitiveservices:bingautosuggest |
Azure Bing Custom Search | cloud:azure:cognitiveservices:bingcustomsearch |
Azure Bing Entity Search | cloud:azure:cognitiveservices:bingentitysearch |
Azure Bing Search | cloud:azure:cognitiveservices:bingsearch |
Azure Bing Spell Check | cloud:azure:cognitiveservices:bingspellcheck |
Azure Blockchain Service | cloud:azure:blockchain:blockchainmembers |
Azure CDN WAF Policy | cloud:azure:cdn:cdnwebapplicationfirewallpolicies |
Azure Cognitive Services - All in One | cloud:azure:cognitiveservices:allinone |
Azure Computer Vision | cloud:azure:cognitiveservices:computervision |
Azure Connection Monitors Preview | cloud:azure:network:networkwatchers:connectionmonitors:preview |
Azure Container Instance | cloud:azure:containerinstance:containergroup |
Azure Container Registry | cloud:azure:containerregistry:registries |
Azure Content Moderator | cloud:azure:cognitiveservices:contentmoderator |
Azure Custom Vision Prediction | cloud:azure:cognitiveservices:customvisionprediction |
Azure Custom Vision Training | cloud:azure:cognitiveservices:customvisiontraining |
Azure DB for MariaDB | cloud:azure:mariadb:server |
Azure DB for MySQL | cloud:azure:mysql:server |
Azure DB for PostgreSQL - Flexible Server | cloud:azure:postgresql:flexibleservers |
Azure DB for PostgreSQL - Hyperscale | cloud:azure:postgresql:serverv2 |
Azure DB for PostgreSQL - Server | cloud:azure:postgresql:server |
Azure DNS Zone | cloud:azure:network:dnszones |
Azure Data Explorer Cluster | cloud:azure:kusto:clusters |
Azure Data Factory v1 | cloud:azure:datafactory:v1 |
Azure Data Factory v2 | cloud:azure:datafactory:v2 |
Azure Data Lake Analytics | cloud:azure:datalakeanalytics:accounts |
Azure Data Lake Storage Gen1 | cloud:azure:datalakestore:accounts |
Azure Data Share | cloud:azure:datashare:accounts |
Azure Device Provisioning Service | cloud:azure:devices:provisioningservices |
Azure Event Grid Domain | cloud:azure:eventgrid:domains |
Azure Event Grid System Topic | cloud:azure:eventgrid:systemtopics |
Azure Event Grid Topic | cloud:azure:eventgrid:topics |
Azure Event Hubs Cluster | cloud:azure:eventhub:clusters |
Azure ExpressRoute Circuit | cloud:azure:network:expressroutecircuits |
Azure Face | cloud:azure:cognitiveservices:face |
Azure Firewall | cloud:azure:network:azurefirewalls |
Azure Front Door | cloud:azure:frontdoor |
Azure Function App Deployment Slot | cloud:azure:web:functionslots |
Azure HDInsight Cluster | cloud:azure:hdinsight:cluster |
Azure Immersive Reader | cloud:azure:cognitiveservices:immersivereader |
Azure Ink Recognizer | cloud:azure:cognitiveservices:inkrecognizer |
Azure Integration Service Environment | cloud:azure:logic:integrationserviceenvironments |
Azure IoT Central Application | cloud:azure:iotcentral:iotapps |
Azure Key Vault | cloud:azure:keyvault:vaults |
Azure Kubernetes Service (AKS) | cloud:azure:containerservice:managedcluster |
Azure Language Understanding (LUIS) | cloud:azure:cognitiveservices:luis |
Azure Language Understanding Authoring (LUIS) | cloud:azure:cognitiveservices:luisauthoring |
Azure Logic Apps | cloud:azure:logic:workflows |
Azure Machine Learning Workspace | cloud:azure:machinelearningservices:workspaces |
Azure Maps Account | cloud:azure:maps:accounts |
Azure Media Service | cloud:azure:media:mediaservices |
Azure Mesh Application | cloud:azure:servicefabricmesh:applications |
Azure NetApp Capacity Pool | cloud:azure:netapp:netappaccounts:capacitypools |
Azure NetApp Volume | cloud:azure:netapp:netappaccounts:capacitypools:volumes |
Azure Network Interface | cloud:azure:network:networkinterfaces |
Azure Notification Hub | cloud:azure:notificationhubs:namespaces:notificationhubs |
Azure Personalizer | cloud:azure:cognitiveservices:personalizer |
Azure Power BI Embedded | cloud:azure:powerbidedicated:capacities |
Azure Private DNS Zone | cloud:azure:network:privatednszones |
Azure Public IP Address | cloud:azure:network:publicipaddresses |
Azure QnA Maker | cloud:azure:cognitiveservices:qnamaker |
Azure Relay | cloud:azure:relay:namespaces |
Azure SQL Data Warehouse (legacy) | cloud:azure:sql:servers:databases:datawarehouse |
Azure SQL Database - Hyperscale | cloud:azure:sql:servers:databases:hyperscale |
Azure SQL Managed Instance | cloud:azure:sql:managed |
Azure SQL Pool | cloud:azure:synapse:workspaces:sqlpools |
Azure Search Service | cloud:azure:search:searchservices |
Azure SignalR | cloud:azure:signalrservice:signalr |
Azure Speech | cloud:azure:cognitiveservices:speech |
Azure Spring Cloud | cloud:azure:appplatform:spring |
Azure Storage Account (classic) | cloud:azure:classic_storage_account |
Azure Storage Blob Services (classic) | cloud:azure:classic_storage_account:blob |
Azure Storage File Services (classic) | cloud:azure:classic_storage_account:file |
Azure Storage Queue Services (classic) | cloud:azure:classic_storage_account:queue |
Azure Storage Sync Service | cloud:azure:storagesync:storagesyncservices |
Azure Storage Table Services (classic) | cloud:azure:classic_storage_account:table |
Azure Stream Analytics Job | cloud:azure:streamanalytics:streamingjobs |
Azure Streaming Endpoint | cloud:azure:media:mediaservices:streamingendpoints |
Azure Synapse Workspace | cloud:azure:synapse:workspaces |
Azure Text Analytics | cloud:azure:cognitiveservices:textanalytics |
Azure Time Series Insights Environment | cloud:azure:timeseriesinsights:environments |
Azure Time Series Insights Event Source | cloud:azure:timeseriesinsights:eventsources |
Azure Traffic Manager Profile | cloud:azure:traffic_manager_profile |
Azure Translator | cloud:azure:cognitiveservices:translator |
Azure Virtual Machine (classic) | cloud:azure:classic_virtual_machine |
Azure Virtual Network Gateway | cloud:azure:virtual_network_gateway |
Azure Web App Deployment Slot | cloud:azure:web:appslots |
