FIXED: Check the Consumption dashboard 

## How to calculate Host Unit consumption for a defined period of time:

#### 1) Left side bar menu -> Observe and explore -> Explore data

<p align="left">
  <img size="50%" src="images/1-calculate HU.png" width="40%" height="40%" /></div>
</p>

#### 2) In the Data Explorer feature, click in the “code” option
<p align="left">
  <img size="50%" src="images/2-calculate HU.png" width="40%" height="40%" /></div>
</p>

#### 3)	Select the time frame window for which you want to calculate your HU consumption and select apply.
<p align="left">
  <img size="50%" src="images/3-calculate HU.png" width="40%" height="40%" /></div>
</p>

#### 4)	Under visualization select “single value”
<p align="left">
  <img size="50%" src="images/4-calculate HU.png" width="40%" height="40%" /></div>
</p>

#### 5)	Paste de following expression in the “code “ blank box of the data explorer.

*(hostUnitConsumption:splitBy():sum:auto:sort(value(sum,descending)):limit(10))/**(TotalMinutes)***

Replace **TotalMinutes** for the seconds of the period of time selected in the timeframe (step 3)

   * Example: Minutes month of October -> 31days * 24hours * 60minutes = 44640 minutes *

<p align="left">
  <img size="50%" src="images/5-calculate HU.png" width="40%" height="40%" /></div>
</p>

#### 6)	Multiply de result shown *(example = 81,8)* for the price of the host unit.
