# How to exclude certain ActiveGates from Dynatrace Round-Robin loadbalancing

##### OpenShift only!

By default, Dynatrace sends a list of _public_ and _customer_ ActiveGates automatically to their OneAgents.
Loadbalancing is done between _all_ reachable ActiveGates of that list.

If for some reason the connection from one of the ActiveGates to the Dynatrace tenant is failing from time to time (resulting in gaps in the monitoring data),
one can _exclude_ certain ActiveGates from the Round-Robin loadbalancing.

To this end, add the affected IPs to the `EgressNetworkPolicy` and deny the connection.

## Get a temporal API Token
Follow the instructions from the [ADPHub documentation](https://github.developer.allianz.io/AgileDeliveryPlatform/ADPHub/blob/master/docs/api-usage.md#getting-api-authentication-token) to retrieve a token for your OpenShift namespace.

## Get your current `EgressNetworkPolicy`
Navigate to the [ADBHub API](https://adp-hub.apps.adp.allianz/api-docs/index.html) and select **Egress Network Policies**.
Authenticate against the API using the previously generated `Token`.
Use `Try it out` from the `GET` endpoint, provide your OpenShift namespace and the datacenter and download the `yml` file for your `Network Egress Policy`.

## Edit the `NetworkEgressPolicy`
Decide which ActiveGates you want to exclude from Round-Robin loadbalancing and [look up the affected IPs](https://github.developer.allianz.io/globalmonitoring/support/blob/master/oneagent_installation/install_oneagent_linux_server.md).
Then edit the downloaded `yml` file and
- change the entry
  ```yaml
  - to:
      cidrSelector: 0.0.0.0/0
    type: Deny
  ```
  to
  ```yaml
  - to:
      cidrSelector: 0.0.0.0/0
    type: Allow
  ```
- add an entry of `type: Deny` for each IP you want to block:
  ```yaml
  - to:
      cidrSelector: <ActiveGate IP>
    type: Deny
  ```
 
#### Example
If your OpenShift project resides on `AWS ASE1` and you want to block _all_ ActiveGates hosted by AGM team,
your `EgressNetworkPolicy` should look like this:
```yaml
apiVersion: network.openshift.io/v1
kind: EgressNetworkPolicy
metadata:
  name: default
  namespace: <your OpenShift namespace>
  resourceVersion: <current resource version string>
spec:
  egress:
  - to:
      dnsName: proxy.ase1.aws.aztec.cloud.allianz
    type: Allow
  - to:
      dnsName: router.apps.crp.ase1.aws.aztec.cloud.allianz
    type: Allow
  - to:
      dnsName: console.crp.ase1.aws.aztec.cloud.allianz
    type: Allow
  - to:
      cidrSelector: 10.16.77.220/32
    type: Deny
  - to:
      cidrSelector: 10.16.77.221/32
    type: Deny
  - to:
      cidrSelector: 10.16.77.192/28
    type: Deny
  - to:
      cidrSelector: 44.160.240.64/32
    type: Deny
  - to:
      cidrSelector: 44.168.240.56/32
    type: Deny
  - to:
      cidrSelector: 44.130.167.140/32
    type: Deny
  - to:
      cidrSelector: 44.130.167.168/32
    type: Deny
  - to:
      cidrSelector: 44.130.167.205/32
    type: Deny
  - to:
      cidrSelector: 44.133.140.28/32
    type: Deny
  - to:
      cidrSelector: 44.133.140.37/32
    type: Deny
  - to:
      cidrSelector: 44.133.140.69/32
    type: Deny
  - to:
      cidrSelector: 10.186.32.64/32
    type: Deny
  - to:
      cidrSelector: 10.186.32.71/32
    type: Deny
  - to:
      cidrSelector: 0.0.0.0/0
    type: Allow
```

## Update `EgressNetworkPolicy` from file
Select `Try it out` from the `POST` endpoint, specify your OpenShift namespace and datacenter and select the previously edited `yml` file.

You should receive a response that the `EgressNetworkPolicy` has been updated successfully.

With this new `EgressNetworkPolicy`, the OneAgent shouldn't be able to connect to any of the excluded ActiveGates anymore,
hence the Round-Robin loadbalancer will only take place between the _public_ ActiveGates provided by Dynatrace.


## Cleanup
You should `revoke` your temporary token for security reasons.
