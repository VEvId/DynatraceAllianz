# Requesting a Management Zone renaming

If your Management Zone has to be renamed, you can open an according issue in this support channel.

However, please be aware that renaming a Management Zone might require adaptions/assurances from your side as explained 
in the following. 

### Adaptions of OneAgent Configurations

By renaming a Management Zones, its entity detection rules changes. In particular, this affects all rules base on
naming conventions. 

Thus, as soon as the Management Zone is renamed, you will need to adapt all host group names of your OneAgents according to
the new host group name prefix.

### Adaption of your CaC-Repository

When your Management Zone has been renamed, you receive a _new_ associated CaC-repository in Github.

In order to transfer your configurations, please proceed as follows:
1. Back-up all your existing configuration files from your _old_ configuration repository (e.g. by cloning it locally).
2. Delete all configurations from your old configuration repository and commit the changes.
3. Commit all backed-up configuration files (no changes necessary) to your _new_ configuration repository.
4. Ping us in the support ticket about the finished transfer so we can delete your old configuration repository.

_Important_: Please follow the steps above and in particular avoid having duplicated configurations in the two repositories
at the same time. This can create conflicts in Dynatrace. Also, if you have configured entities resulting in usage costs,
please be aware that also entities configured in the old repository will produce costs as long as they are not deleted!

If you did _not_ configure anything in your old configuration repository, you can skip steps 1-3, of course.

### Loss of Entity History

Please be aware that certain Dynatrace entities will have to be re-created instead of renamed (in particular, this affects
your CaC-configured entities). This will imply that those entities will lose their data up to change.
