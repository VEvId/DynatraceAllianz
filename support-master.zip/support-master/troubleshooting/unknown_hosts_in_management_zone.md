#  Unknown Hosts in Management Zone

## Issue

There are hosts in my management zone that to do not belong to me.

## Explanation

If OneAgents are not properly configured, they may be not assigned to a Management Zone the first place. In this case,
an automation analyzes the existing relations of this host to existing entities in Dynatrace and assigns the host to
the according Management Zones. This assignment is then verified on a regular basis.

## Resolution

If your Management Zone contains such an auto-assigned host that you would like to remove, you may follow the following steps:

1) If the host has the tag `auto_mz_assigned` remove this tag. If not, directly continue with step 2.
2) Remove the `@mz-<your management zone>` tag from the host (where, of course, `<your management zone>` is the placeholder for your management zone).

Note that it might take a little time (< 1 hour) until the host will disappear from your Management Zone.
