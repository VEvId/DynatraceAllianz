# **SIM User Guide for Dynatrace ordering**

The purpose of this document is to provide an instruction how to raise a
Service Request for Dynatrace

### Contents

[Ordering Dynatrace Service Requests in ServiceNow](#ordering-dynatrace-service-requests-in-servicenow)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Order New Service Request Dynatrace](#order-new-service-request-dynatrace)

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[Decommission a Dynatrace Service ](#decommission-a-dynatrace-service)


### Ordering Dynatrace Service Requests in ServiceNow

To create a service request for *ordering Dynatrace* via ServiceNow,
please go to the service catalog \> [SIM Services](https://aztech.service-now.com/) \> Dynatrace

![](images/sim_0rder1.jpg)

![](images/sim_0rder2.jpg)

![](images/sim_0rder3.jpg)

#### Order New Service Request Dynatrace

Click on New Service Request Dynatrace to start the request.

![](images/sim_0rder4.jpg)

The following form will open and you need to fill all mandatory fields.

![](images/sim_0rder5.jpg)

As soon as you have filled all information you can click on order now.

***Note:*** the Organization Entity, Debtor and Cost Center that you
choose will be used for charging purposes.

![](images/sim_0rder6.jpg)

You will receive a summary and can check out.

![](images/sim_0rder7.jpg)

Once you have checked out you see that the request is created. You will
receive a information via mail as well. The request will be send to the
respective team for fulfillment.

![](images/sim_0rder8.jpg)

The request can be accessed via my requests as well.

![](images/sim_0rder9.jpg)

#### Decommission a Dynatrace Service

Click on Decommission a Dynatrace Service.

![](images/sim_0rder10.jpg)

Select the respective SI you want to decommission. You can see only the
SIs belonging to you (ordered for you/ by you).

![](images/sim_0rder11.jpg)
![](images/sim_0rder12.jpg)

As soon as you have selected the SI to be decommissioned click on order
now.

![](images/sim_0rder13.jpg)

You will receive the summary and can check out.
![](images/sim_0rder14.jpg)

The request is created and is send for fulfillment to the respective
team. You will receive a notification via mail as well.

![](images/sim_0rder15.jpg)

***Note:*** In case if you require any help please contact us [here](https://github.developer.allianz.io/globalmonitoring/support/issues)
